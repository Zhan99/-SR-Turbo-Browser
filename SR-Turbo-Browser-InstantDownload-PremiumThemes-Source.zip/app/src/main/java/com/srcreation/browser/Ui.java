package com.srcreation.browser;
import android.content.Context;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.graphics.drawable.RippleDrawable;import android.content.res.ColorStateList;import android.view.*;import android.widget.*;
final class Ui {
    static final int NAV=0xff101c30, TEAL=0xff087f85, MINT=0xff57e4d4, PAPER=0xfff1f5f9, INK=0xff132238, MUTED=0xff506477;
    static int dp(Context c,float n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable bg(int c,int radius,Context ctx){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(ctx,radius));return g;}
    static GradientDrawable surface(Context c,int fill,int radius,int border){GradientDrawable g=bg(fill,radius,c);g.setStroke(dp(c,1),border);return g;}
    static GradientDrawable gradient(Context c,int start,int end,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{start,end});g.setCornerRadius(dp(c,radius));return g;}
    static void ripple(View v,Context c,int fill,int radius,int border){v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x2280aabf),surface(c,fill,radius,border),null));}
    static TextView text(Context c,String s,int size,int color,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    static TextView button(Context c,String s,int fg,int bg,Runnable click){TextView b=text(c,s,14,fg,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(c,12),dp(c,9),dp(c,12),dp(c,9));b.setMinHeight(dp(c,44));ripple(b,c,bg,12,bg);b.setClickable(true);b.setFocusable(true);b.setOnClickListener(v->click.run());return b;}
    static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    static void pad(View v,Context c,int n){int d=dp(c,n);v.setPadding(d,d,d,d);}
}
