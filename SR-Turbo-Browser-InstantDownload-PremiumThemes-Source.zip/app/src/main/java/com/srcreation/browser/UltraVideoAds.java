package com.srcreation.browser;

/** Document-local controller. Only uses visible site-provided skip controls. */
final class UltraVideoAds {
    static String script(boolean banners, boolean skip, boolean mute) {
        return "(function(banners,skip,mute){" + BODY + "})("+banners+","+skip+","+mute+")";
    }
    private static final String BODY = """
        if (!/(^|[.])youtube[.]com$/i.test(location.hostname)) return [0,false,false];
        const key='__srTurboUltraV1', styleId='sr-turbo-ad-style';
        let s=window[key];
        if (!s) {
          s={count:0,ad:false,mutedVideo:null,wasMuted:false,clicked:new WeakMap(),stall:false,lastTime:-1,lastMove:Date.now(),lastVideo:null,wasAd:false,watchUntil:0};
          window[key]=s;
          const playerSelector='#movie_player,#player-container-id,.html5-video-player,ytm-player';
          const buttonSelector='.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button,.videoAdUiSkipButton,button[aria-label],button';
          const knownSkip='.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button,.videoAdUiSkipButton';
          const adSelector='.ytp-ad-player-overlay,.ytp-ad-preview-container,.ytp-ad-text,.ytp-ad-simple-ad-badge,.ytp-ad-skip-button-container';
          const css='ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,ytd-in-feed-ad-layout-renderer,ytd-action-companion-ad-renderer,ytd-companion-slot-renderer,ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,ytm-in-feed-ad-layout-renderer,ytm-display-ad-renderer{display:none!important}';
          function visible(el) {
            if(!el||!el.isConnected||!el.getClientRects().length)return false;
            const r=el.getBoundingClientRect(), c=getComputedStyle(el);
            return r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth&&c.visibility!=='hidden'&&c.visibility!=='collapse'&&c.display!=='none'&&Number(c.opacity)>0;
          }
          function restore(){if(s.mutedVideo){if(s.mutedVideo.muted)s.mutedVideo.muted=s.wasMuted;s.mutedVideo=null;}}
          function run(){
            const now=Date.now();
            let style=document.getElementById(styleId);
            if(s.banners&&document.head){if(!style){style=document.createElement('style');style.id=styleId;document.head.appendChild(style);}if(style.textContent!==css)style.textContent=css;}
            else if(style)style.remove();
            const player=document.querySelector('ytm-player')||document.querySelector('#player-container-id')||document.querySelector(playerSelector);
            const marked=player&&(player.matches('.ad-showing,.ad-interrupting')||!!player.querySelector('.ad-showing,.ad-interrupting'));
            const video=player&&player.querySelector('video');
            let button=null;
            if(player&&(s.skip||s.mute))for(const el of player.querySelectorAll(buttonSelector)){
              const text=(el.getAttribute('aria-label')||el.textContent||'').trim().replace(/\\s+/g,' ');
              if(!el.matches(knownSkip)&&!/^(skip(?: ad(?:s|vertisement)?)?|বিজ্ঞাপন এড়িয়ে যান|বিজ্ঞাপন এড়িয়ে যান|স্কিপ)$/i.test(text))continue;
              if(!visible(el)||el.disabled||el.getAttribute('aria-disabled')==='true')continue;
              // Text-only fallback must be in a player with explicit ad evidence.
              if(!el.matches(knownSkip)&&!marked&&!Array.from(player.querySelectorAll(adSelector)).some(visible))continue;
              button=el;break;
            }
            s.ad=!!(player&&(marked||Array.from(player.querySelectorAll(adSelector)).some(visible)||button));
            if(s.mutedVideo&&(!s.mute||!s.ad||video!==s.mutedVideo))restore();
            if(s.mute&&s.ad&&video&&!s.mutedVideo){s.mutedVideo=video;s.wasMuted=video.muted;video.muted=true;}
            if(s.skip&&s.ad&&button&&(!s.clicked.has(button)||now-s.clicked.get(button)>1500)){s.clicked.set(button,now);button.click();s.count++;}
            if(s.wasAd&&!s.ad){s.watchUntil=now+20000;s.lastMove=now;}
            s.wasAd=s.ad;
            if(video!==s.lastVideo||!video||video.currentTime!==s.lastTime||video.paused||s.ad){s.lastMove=now;s.lastVideo=video;s.lastTime=video?video.currentTime:-1;}
            s.stall=!!(!s.ad&&video&&now<s.watchUntil&&(video.error||(!video.paused&&!video.ended&&now-s.lastMove>8000)));
          }
          s.run=run;
          s.stop=function(){restore();if(s.timer)clearInterval(s.timer);if(s.observer)s.observer.disconnect();if(s.pending)clearTimeout(s.pending);s.timer=null;s.observer=null;s.pending=null;};
          s.start=function(){if(s.timer)return;s.timer=setInterval(run,300);if(document.documentElement&&typeof MutationObserver!=='undefined'){s.observer=new MutationObserver(()=>{if(!s.pending)s.pending=setTimeout(()=>{s.pending=null;run();},60);});s.observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','disabled','aria-disabled','style']});}};
        }
        s.banners=banners;s.skip=skip;s.mute=mute;
        s.run();
        if(banners||skip||mute)s.start();else s.stop();
        return [s.count,s.ad,s.stall];
        """;
}
