package com.srcreation.browser;
import android.os.Bundle;import android.webkit.WebView;
public class PrivateActivity extends BrowserActivity {
    private static boolean configured=false;
    @Override public void onCreate(Bundle b){if(!configured){WebView.setDataDirectorySuffix("private");configured=true;}super.onCreate(b);}
    @Override boolean privateMode(){return true;}
}
