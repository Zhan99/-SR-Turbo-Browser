package com.srcreation.browser;
import java.net.URI;
import java.util.Locale;
/** Mobile layout compatibility, not an authentication or security workaround. */
final class FacebookMobile {
    static final String HOME="https://m.facebook.com/";
    static boolean isSite(String value){
        try{URI u=URI.create(value);if(!"https".equalsIgnoreCase(u.getScheme())||u.getRawUserInfo()!=null||(u.getPort()!=-1&&u.getPort()!=443))return false;
            String host=u.getHost();if(host==null)return false;
            switch(host.toLowerCase(Locale.ROOT)){case "facebook.com":case "www.facebook.com":case "m.facebook.com":case "web.facebook.com":return true;default:return false;}
        }catch(RuntimeException e){return false;}
    }
    static String entry(String url,boolean mobile){
        if(!mobile||!isSite(url))return url;URI u=URI.create(url);
        if((u.getRawPath()==null||u.getRawPath().isEmpty()||u.getRawPath().equals("/"))&&u.getRawQuery()==null&&u.getRawFragment()==null)return HOME;
        return url;
    }
    static String agent(String actual,boolean compatible){
        if(!compatible||actual==null||!actual.contains("Android")||!actual.matches("(?s).*\\bChrome/[0-9]+(?:\\.[0-9]+){0,3}\\b.*"))return actual;
        String result=actual.replaceAll(";\\s*wv(?=\\))","").replaceAll("\\s+Version/4\\.0(?=\\s)","");
        if(!result.contains("Mobile Safari/")&&result.contains(" Safari/"))result=result.replace(" Safari/"," Mobile Safari/");
        return result;
    }
    private FacebookMobile(){}
}
