package com.srcreation.browser;

import java.util.Locale;

/** Presentation only: never replace the stored navigation URL with a title. */
final class HistoryTitles {
    static boolean usable(String title, String url) {
        if (title == null) return false;
        String text = title.trim();
        if (text.isEmpty() || (url != null && text.equals(url.trim()))) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        return !lower.startsWith("http://") && !lower.startsWith("https://")
                && !lower.startsWith("about:") && !lower.startsWith("www.");
    }

    static String display(String title, String url) {
        return usable(title, url) ? title.trim() : "Untitled page";
    }
}
