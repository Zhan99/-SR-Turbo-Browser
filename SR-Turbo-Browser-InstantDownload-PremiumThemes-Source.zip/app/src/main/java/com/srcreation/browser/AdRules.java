package com.srcreation.browser;

import java.net.URI;
import java.util.*;

/** Conservative host-based filtering; never blocks a top-level navigation. */
final class AdRules {
    static final Set<String> ADS=set("doubleclick.net","googlesyndication.com","googleadservices.com","adnxs.com","adsrvr.org","taboola.com","outbrain.com","rubiconproject.com","pubmatic.com");
    static final Set<String> TRACKERS=set("google-analytics.com","scorecardresearch.com","hotjar.com","quantserve.com","demdex.net","analytics.tiktok.com");
    static Set<String> set(String... values){return Collections.unmodifiableSet(new HashSet<>(Arrays.asList(values)));}
    static String host(String url){try{URI u=URI.create(url);String h=u.getHost();return h!=null&&("https".equalsIgnoreCase(u.getScheme())||"http".equalsIgnoreCase(u.getScheme()))?h.toLowerCase(Locale.ROOT):"";}catch(RuntimeException e){return "";}}
    static boolean matches(String h,String domain){return h.equals(domain)||h.endsWith("."+domain);}
    static boolean contains(Set<String> domains,String host){for(String h=host;!h.isEmpty();){if(domains.contains(h))return true;int dot=h.indexOf('.');if(dot<0)break;h=h.substring(dot+1);}return false;}
    static boolean youtube(String h){return matches(h,"youtube.com");}
    static boolean exempt(String h){return h.equals("accounts.google.com")||h.equals("myaccount.google.com")||h.equals("mail.google.com");}
    static boolean enabled(String page,Set<String> allow){String h=host(page);return !h.isEmpty()&&!exempt(h)&&!allow.contains(h);}
    static boolean block(String page,String resource,boolean main,boolean ads,boolean yt,boolean tracking,Set<String> allow,Set<String> extra){
        if(main||!enabled(page,allow))return false;
        String p=host(page),r=host(resource);
        if(r.isEmpty()||matches(r,p)||matches(p,r)||exempt(r))return false;
        if(youtube(p)){
            if(matches(r,"googlevideo.com")||matches(r,"ytimg.com")||matches(r,"youtube.com")||matches(r,"googleapis.com"))return false;
            return (yt&&contains(ADS,r))||(tracking&&contains(TRACKERS,r));
        }
        return (ads&&(contains(ADS,r)||contains(extra,r)))||(tracking&&contains(TRACKERS,r));
    }
    static Set<String> parseHosts(String text){Set<String> out=new HashSet<>();for(String line:text.split("\\r?\\n")){String[] cols=line.split("#",2)[0].trim().split("\\s+");if(cols.length<2||!(cols[0].equals("127.0.0.1")||cols[0].equals("0.0.0.0")||cols[0].equals("::1")))continue;for(int i=1;i<cols.length;i++){String h=cols[i].toLowerCase(Locale.ROOT);if(h.length()<=253&&h.matches("[a-z0-9]([a-z0-9.-]*[a-z0-9])?\\.[a-z][a-z0-9-]*")&&!h.contains("..")&&!h.equals("localhost.localdomain")){out.add(h);if(out.size()>50000)throw new IllegalArgumentException("Too many filter entries");}}}return Collections.unmodifiableSet(out);}
    static String cosmetic(boolean on){return "(function(){if(!/(^|\\.)youtube\\.com$/.test(location.hostname))return;var id='sr-turbo-ad-style',e=document.getElementById(id);if(!"+on+"){if(e)e.remove();return;}if(e||!document.head)return;e=document.createElement('style');e.id=id;e.textContent='ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,ytd-in-feed-ad-layout-renderer{display:none!important}';document.head.appendChild(e);})()";}
    // Only click the site's own visible Skip button; never seek, alter playback speed or fake ad completion.
    static final String SKIP="(function(){if(!/(^|\\.)youtube\\.com$/.test(location.hostname))return false;var q=document.querySelectorAll('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,button.ytp-ad-skip-button-container');for(var b of q){var r=b.getBoundingClientRect(),s=getComputedStyle(b);if(r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&s.opacity!=='0'&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'&&b.getClientRects().length){b.click();return true;}}return false;})()";
}
