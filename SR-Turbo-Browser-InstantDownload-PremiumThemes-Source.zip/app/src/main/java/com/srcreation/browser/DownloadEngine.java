package com.srcreation.browser;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.*;

/** Pure Java transfer core. The UI never trusts Accept-Ranges without an actual 206 probe. */
final class DownloadEngine {
    static final int BUFFER=256*1024, MAX_CONNECTIONS=32, MAX_PARTS=512;
    static final long TARGET_RATE=1024L*1024;
    // More pieces than workers keep fast workers occupied when other pieces finish early.
    // Fixed, bounded layout remains safe to resume and avoids excessive tiny requests.
    static int partCount(long length,int connections){
        if(length<2L*1024*1024)return 1;
        if(!priority(connections))return (int)Math.min(connections,length/(1024L*1024));
        long desired=Math.max(connections*4L,1+(length-1)/(2L*1024*1024));
        return (int)Math.max(1,Math.min(MAX_PARTS,Math.min(desired,length/(256L*1024))));
    }
    static int restoreConnections(int value,boolean migrated){return !migrated&&value==16?MAX_CONNECTIONS:Math.max(1,Math.min(MAX_CONNECTIONS,value));}
    static boolean priority(int connections){return connections>8;}
    static final Pattern RANGE=Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+)",Pattern.CASE_INSENSITIVE);
    static final class Stop extends IOException { Stop(){super("Transfer stopped");} }
    static final class ServerBusy extends IOException { ServerBusy(int status,String retry){super("HTTP "+status+" — server busy; resume later"+(retry==null?"":" (Retry-After: "+retry+")"));} }
    static final class RangeFailure extends IOException { RangeFailure(String s){super(s);} }
    static final class Control {
        final AtomicBoolean stopped=new AtomicBoolean();
        final Set<HttpURLConnection> active=ConcurrentHashMap.newKeySet();
        void check() throws Stop { if(stopped.get()||Thread.currentThread().isInterrupted())throw new Stop(); }
        void stop(){stopped.set(true); for(HttpURLConnection c:active)c.disconnect();}
    }
    static final class Meta {
        long length=-1; String validator=""; int parts=1; boolean ranged=false;
        Meta(){}
        Meta(long l,String v,int p,boolean r){length=l;validator=v;parts=p;ranged=r;}
        boolean matches(Meta m){return ranged&&m.ranged&&!validator.isEmpty()&&length==m.length&&parts==m.parts&&validator.equals(m.validator);}
    }
    interface Listener {void metadata(Meta m) throws IOException; void progress(long bytes,long total); default void connections(int active,int limit){} }
    final String url,agent,cookie; final File dir; final int threads; final Control control; final Listener listener;
    DownloadEngine(String u,String a,String c,File d,int t,Control ctl,Listener l){url=u;agent=a;cookie=c;dir=d;threads=Math.max(1,Math.min(MAX_CONNECTIONS,t));control=ctl;listener=l;}
    static boolean sameOrigin(URL a,URL b){return a.getProtocol().equalsIgnoreCase(b.getProtocol())&&a.getHost().equalsIgnoreCase(b.getHost())&&port(a)==port(b);}
    static int port(URL u){return u.getPort()==-1?u.getDefaultPort():u.getPort();}
    HttpURLConnection connect(String range,String validator) throws IOException {
        URL original=new URL(url), current=original;
        for(int n=0;n<10;n++){
            control.check(); String scheme=current.getProtocol();
            if(!scheme.equals("http")&&!scheme.equals("https"))throw new IOException("Unsupported protocol");
            HttpURLConnection c=(HttpURLConnection)current.openConnection(); c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(20000);
            c.setRequestProperty("Accept-Encoding","identity");c.setRequestProperty("User-Agent",agent==null||agent.isEmpty()?"SR Turbo Browser":agent);
            if(cookie!=null&&!cookie.isEmpty()&&sameOrigin(original,current))c.setRequestProperty("Cookie",cookie);
            if(range!=null)c.setRequestProperty("Range",range);
            if(validator!=null&&!validator.isEmpty())c.setRequestProperty("If-Range",validator);
            control.active.add(c);
            try{
                control.check();int status=c.getResponseCode();
                if(status==429||status==503)throw new ServerBusy(status,c.getHeaderField("Retry-After"));
                if(status==301||status==302||status==303||status==307||status==308){String loc=c.getHeaderField("Location"); if(loc==null)throw new IOException("Missing redirect URL"); URL next=new URL(current,loc); if(current.getProtocol().equals("https")&&next.getProtocol().equals("http"))throw new IOException("Unsafe HTTPS downgrade"); close(c);current=next;continue;}
                return c;
            }catch(IOException|RuntimeException e){close(c);throw e;}
        }throw new IOException("Too many redirects");
    }
    void close(HttpURLConnection c){control.active.remove(c);c.disconnect();}
    static boolean identity(HttpURLConnection c){String enc=c.getHeaderField("Content-Encoding");return enc==null||enc.equalsIgnoreCase("identity");}
    static String validator(HttpURLConnection c){String et=c.getHeaderField("ETag"); if(et!=null&&!et.startsWith("W/")&&et.startsWith("\""))return et;String lm=c.getHeaderField("Last-Modified");return lm==null?"":lm;}
    static long length(HttpURLConnection c){return c.getContentLengthLong();}
    Meta probe() throws IOException {
        HttpURLConnection c=connect("bytes=0-0",null);
        try{int s=c.getResponseCode();if(s==206&&identity(c)){Matcher m=RANGE.matcher(Objects.toString(c.getHeaderField("Content-Range"),""));if(m.matches()&&m.group(1).equals("0")&&m.group(2).equals("0")){long total=Long.parseLong(m.group(3));String v=validator(c);if(total>0&&!v.isEmpty()){int count=partCount(total,threads);return new Meta(total,v,count,true);}return new Meta(total,"",1,false);}}
            if(s==200)return new Meta(identity(c)?length(c):-1,"",1,false);
            if(s==400||s==403||s==405||s==416||s==501)return new Meta(-1,"",1,false);
            if(s==206)return new Meta(-1,"",1,false);
            throw new IOException("HTTP "+s);
        }finally{close(c);}
    }
    File part(int i){return new File(dir,"part-"+i);}
    void clear() throws IOException {File[] files=dir.listFiles();if(files!=null)for(File f:files)if(f.getName().startsWith("part-")&&!f.delete())throw new IOException("Cannot reset temporary data");}
    long sum(int n){long x=0;for(int i=0;i<n;i++)x+=part(i).length();return x;}
    final AtomicLong received=new AtomicLong(),lastReport=new AtomicLong();
    final ThreadLocal<byte[]> buffers=ThreadLocal.withInitial(()->new byte[BUFFER]);
    void report(Meta m){long now=System.nanoTime(),last=lastReport.get();if(now-last>=200_000_000L&&lastReport.compareAndSet(last,now))reportNow(m);}
    synchronized void reportNow(Meta m){listener.progress(received.get(),m.length);}
    Meta run(Meta previous) throws IOException {
        if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Cannot create download folder");
        Meta m=probe();control.check();
        // Preserve previously validated partial files even when the connection preference changes.
        if(m.ranged&&previous.ranged&&previous.parts>=1&&previous.parts<=MAX_PARTS&&m.length==previous.length&&m.validator.equals(previous.validator)&&!m.validator.isEmpty())m.parts=previous.parts;
        if(!m.matches(previous))clear();received.set(sum(m.parts));listener.metadata(m);reportNow(m);
        if(m.ranged){try{parallel(m);return m;}catch(RangeFailure e){control.check();clear();received.set(0);m=new Meta(-1,"",1,false);listener.metadata(m);reportNow(m);}}
        listener.connections(1,1);try{single(m);return m;}finally{listener.connections(0,1);}
    }
    void parallel(Meta m) throws IOException {
        int ceiling=Math.min(threads,m.parts);
        // Start all available workers immediately; queue remaining pieces for reuse.
        ThreadPoolExecutor pool=new ThreadPoolExecutor(ceiling,ceiling,0L,TimeUnit.MILLISECONDS,new LinkedBlockingQueue<>());
        CompletionService<Void> completed=new ExecutorCompletionService<>(pool);List<Future<Void>> futures=new ArrayList<>();
        IOException error=null;long sampleTime=System.nanoTime();
        try{
            long q=m.length/m.parts;
            List<Integer> pending=new ArrayList<>();
            for(int i=0;i<m.parts;i++){
                long expected=i==m.parts-1?m.length-q*i:q;
                if(part(i).length()>expected&&!part(i).delete())throw new IOException("Invalid part");
                if(part(i).length()<expected)pending.add(i);
            }
            received.set(sum(m.parts));
            // On resume, finish the largest remaining pieces first to reduce a slow tail.
            pending.sort((a,b)->Long.compare((b==m.parts-1?m.length-q*b:q)-part(b).length(),(a==m.parts-1?m.length-q*a:q)-part(a).length()));
            for(int k:pending){futures.add(completed.submit(()->{long start=q*k,end=k==m.parts-1?m.length-1:q*(k+1)-1;rangePart(m,k,start,end);return null;}));}
            int finished=0;
            while(finished<pending.size()){
                control.check();listener.connections(pool.getActiveCount(),ceiling);
                try{Future<Void> f=completed.poll(200,TimeUnit.MILLISECONDS);if(f!=null){f.get();finished++;}}
                catch(ExecutionException e){Throwable cause=e.getCause();error=cause instanceof IOException?(IOException)cause:new IOException(cause);break;}
                catch(InterruptedException e){Thread.currentThread().interrupt();error=new Stop();break;}
                long now=System.nanoTime();
                if(now-sampleTime>=750_000_000L){sampleTime=now;reportNow(m);}
            }
        }catch(IOException e){error=e;}
        finally{if(error!=null){for(Future<?> f:futures)f.cancel(true);for(HttpURLConnection c:control.active)c.disconnect();}pool.shutdownNow();boolean interrupted=false;while(!pool.isTerminated()){try{pool.awaitTermination(1,TimeUnit.SECONDS);}catch(InterruptedException e){interrupted=true;}}if(interrupted)Thread.currentThread().interrupt();listener.connections(0,ceiling);}
        if(error!=null)throw error;control.check();if(sum(m.parts)!=m.length)throw new IOException("Incomplete segmented download");reportNow(m);
    }
    void rangePart(Meta m,int i,long start,long end) throws IOException {
        File f=part(i);long expected=end-start+1;if(f.length()>expected){if(!f.delete())throw new IOException("Invalid part");}
        for(int attempt=0;attempt<3;attempt++){
            control.check();long have=f.length();if(have==expected)return;
            HttpURLConnection c=null;boolean reusable=false;
            try{long from=start+have;c=connect("bytes="+from+"-"+end,m.validator);int status=c.getResponseCode();if(status==200||status==412||status==416)throw new RangeFailure("Server changed or rejected range");if(status!=206)throw new IOException("HTTP "+status);
                Matcher r=RANGE.matcher(Objects.toString(c.getHeaderField("Content-Range"),""));String v=validator(c);
                if(!identity(c)||!r.matches()||Long.parseLong(r.group(1))!=from||Long.parseLong(r.group(2))!=end||Long.parseLong(r.group(3))!=m.length||(!v.isEmpty()&&!v.equals(m.validator)))throw new RangeFailure("Invalid range response");
                try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(f,true)){byte[] b=buffers.get();long left=expected-have;while(left>0){control.check();int n=in.read(b,0,(int)Math.min(b.length,left));if(n<0)throw new EOFException("Incomplete range");if(n==0)continue;out.write(b,0,n);left-=n;received.addAndGet(n);report(m);}out.flush();}reusable=true;report(m);return;
            }catch(RangeFailure|ServerBusy e){throw e;}catch(IOException e){control.check();if(attempt==2)throw e;try{Thread.sleep(300L*(attempt+1));}catch(InterruptedException ex){Thread.currentThread().interrupt();throw new Stop();}}finally{if(c!=null){if(reusable)control.active.remove(c);else close(c);}}
        }
    }
    void single(Meta m) throws IOException {
        HttpURLConnection c=connect(null,null);
        try{int status=c.getResponseCode();if(status!=200)throw new IOException("HTTP "+status);if(!identity(c))throw new IOException("Unsupported content encoding");m.length=length(c);received.set(0);listener.metadata(m);long count=0;
            try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(part(0),false)){byte[] b=new byte[BUFFER];int n;while((n=in.read(b))!=-1){control.check();if(n==0)continue;out.write(b,0,n);count+=n;received.addAndGet(n);report(m);}out.flush();}control.check();if(m.length>=0&&count!=m.length)throw new IOException("Incomplete download");m.length=count;listener.metadata(m);reportNow(m);
        }finally{close(c);}
    }
    void assemble(Meta m,OutputStream out) throws IOException {long count=0;byte[] buf=new byte[BUFFER];for(int i=0;i<m.parts;i++){try(InputStream in=new FileInputStream(part(i))){int n;while((n=in.read(buf))!=-1){control.check();out.write(buf,0,n);count+=n;}}}if(m.length>=0&&count!=m.length)throw new IOException("File size mismatch");control.check();}
}
