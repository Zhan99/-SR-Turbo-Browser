package com.srcreation.browser;

import java.net.URI;
import java.util.Locale;

/** Direct downloadable video files only; never resolve manifests, blobs or DRM streams. */
final class VideoLinks {
    static final int MAX = 40;
    static final String SCAN = """
        (() => {
          const out = [], seen = new Set();
          const extensions = /\\.(mp4|m4v|webm|mov|mkv|avi|3gp|ogv|mpeg|mpg)$/i;
          const add = (raw, type, fromVideo) => {
            if (!raw || out.length >= 40) return;
            try {
              const u = new URL(raw, document.baseURI);
              if (!/^https?:$/.test(u.protocol) || u.username || u.password) return;
              if (/\\.(m3u8|mpd|m4s|ts|cmfv|cmfa|ism|isml)(\\/manifest)?$/i.test(u.pathname)) return;
              const mime = (type || '').split(';')[0].trim().toLowerCase();
              if (/mpegurl|dash\\+xml|mp2t|cmaf/.test(mime)) return;
              if (!fromVideo && !extensions.test(u.pathname)) return;
              u.hash = '';
              if (seen.has(u.href)) return;
              seen.add(u.href); out.push({url:u.href, mime:mime, fromVideo:fromVideo});
            } catch (_) {}
          };
          for (const v of document.querySelectorAll('video')) {
            if (v.mediaKeys || v.srcObject) continue;
            add(v.currentSrc || v.getAttribute('src'), v.getAttribute('type'), true);
            for (const s of v.querySelectorAll('source[src]')) add(s.getAttribute('src'), s.getAttribute('type'), true);
          }
          for (const a of document.querySelectorAll('a[href]')) add(a.getAttribute('href'), '', false);
          return out;
        })()
        """;

    static String mime(String raw, String declared, boolean fromVideo) {
        try {
            if (raw == null || raw.length() > 8192) return null;
            URI u = new URI(raw);
            if (!("http".equals(u.getScheme()) || "https".equals(u.getScheme())) || u.getHost() == null || u.getRawUserInfo() != null) return null;
            String path = u.getPath().toLowerCase(Locale.ROOT);
            String m = declared == null ? "" : declared.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
            if (path.matches(".*\\.(m3u8|mpd|m4s|ts|cmfv|cmfa|ism|isml)(/manifest)?$") || m.matches(".*(mpegurl|dash\\+xml|mp2t|cmaf).*")) return null;
            if (path.endsWith(".mp4") || path.endsWith(".m4v")) return "video/mp4";
            if (path.endsWith(".webm")) return "video/webm";
            if (path.endsWith(".mov")) return "video/quicktime";
            if (path.endsWith(".mkv")) return "video/x-matroska";
            if (path.endsWith(".avi")) return "video/x-msvideo";
            if (path.endsWith(".3gp")) return "video/3gpp";
            if (path.endsWith(".ogv")) return "video/ogg";
            if (path.endsWith(".mpeg") || path.endsWith(".mpg")) return "video/mpeg";
            if (!fromVideo) return null;
            if (m.startsWith("video/") && m.matches("video/[a-z0-9.+-]+")) return m;
            if (m.isEmpty() || m.equals("application/octet-stream")) return "application/octet-stream";
            return null;
        } catch (Exception e) { return null; }
    }
}
