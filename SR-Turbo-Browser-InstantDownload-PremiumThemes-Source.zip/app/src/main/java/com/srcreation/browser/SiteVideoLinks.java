package com.srcreation.browser;
import java.net.URI;
import java.util.Locale;
final class SiteVideoLinks {
    static String canonical(String raw) {
        String yt=YouTubeLinks.canonical(raw);
        if(yt!=null)return yt;
        if(raw==null||raw.length()>8192)return null;
        try {
            URI u=new URI(raw.trim()); String host=u.getHost();
            if(!"https".equalsIgnoreCase(u.getScheme())||host==null||u.getRawUserInfo()!=null||u.getPort()!=-1)return null;
            host=host.toLowerCase(Locale.ROOT);
            if(host.equals("localhost")||host.endsWith(".local")||host.endsWith(".localhost")||!host.contains(".")||host.matches("[0-9.]+"))return null;
            if(host.equals("youtube.com")||host.endsWith(".youtube.com")||host.equals("youtu.be"))return null;
            return u.toASCIIString();
        }catch(Exception e){return null;}
    }
    static boolean facebook(String raw){try{String host=new URI(raw).getHost().toLowerCase(Locale.ROOT);return host.equals("facebook.com")||host.endsWith(".facebook.com")||host.equals("fb.watch");}catch(Exception e){return false;}}
    static String folder(String url){return "Download/SR Turbo/"+(YouTubeLinks.canonical(url)!=null?"YouTube":facebook(url)?"Facebook":"Videos");}
    static String format(String url,int quality){if(YouTubeLinks.canonical(url)!=null)return YouTubeLinks.format(quality);String cap="[height<=?"+YouTubeLinks.quality(quality)+"]";return "bv*[ext=mp4]"+cap+"+ba[ext=m4a]/b[ext=mp4]"+cap;}
    static String error(String url,String text){if(YouTubeLinks.canonical(url)!=null)return VideoEnginePolicy.error(text);if(VideoEnginePolicy.forbidden(text))return "The video server refused the request (HTTP 403). Use the site's authorized download option.";return text;}
}
