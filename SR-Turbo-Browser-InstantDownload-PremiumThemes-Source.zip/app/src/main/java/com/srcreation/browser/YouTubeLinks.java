package com.srcreation.browser;

import java.net.URI;
import java.util.Locale;

/** Accepts a single public YouTube video, not arbitrary URLs or playlists. */
final class YouTubeLinks {
    private YouTubeLinks() {}
    static String canonical(String raw) {
        if (raw == null || raw.length() > 8192) return null;
        try {
            URI u = new URI(raw.trim());
            if (!"https".equalsIgnoreCase(u.getScheme()) && !"http".equalsIgnoreCase(u.getScheme())) return null;
            if (u.getRawUserInfo() != null || u.getHost() == null || u.getPort() != -1) return null;
            String host = u.getHost().toLowerCase(Locale.ROOT), path = u.getRawPath(), id = null;
            if (host.equals("youtu.be")) {
                if (path.matches("/[A-Za-z0-9_-]{11}/?")) id = path.substring(1, 12);
            } else if (host.equals("youtube.com") || host.equals("www.youtube.com") || host.equals("m.youtube.com") || host.equals("music.youtube.com")) {
                if (path.equals("/watch") && u.getRawQuery() != null) {
                    for (String part : u.getRawQuery().split("&")) if (part.startsWith("v=")) {
                        if (id != null) return null;
                        id = part.substring(2);
                    }
                } else if (path.matches("/(shorts|live|embed|v)/[A-Za-z0-9_-]{11}/?")) id = path.split("/")[2];
            }
            return id != null && id.matches("[A-Za-z0-9_-]{11}") ? "https://www.youtube.com/watch?v=" + id : null;
        } catch (Exception e) { return null; }
    }
    static int quality(int height) { return height == 360 || height == 480 || height == 1080 ? height : 720; }
    static String format(int height) {
        String cap = "[height<=" + quality(height) + "]";
        return "bv*[ext=mp4][vcodec^=avc1]"+cap+"+ba[ext=m4a]/b[ext=mp4][vcodec^=avc1]"+cap+"/bv*[ext=mp4]"+cap+"+ba[ext=m4a]/b[ext=mp4]"+cap;
    }
    static final String PROGRESS = "download:SRPROGRESS|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s";
    static long number(String s) {
        try { double n = Double.parseDouble(s); return Double.isFinite(n) && n >= 0 && n < Long.MAX_VALUE ? (long)n : -1; }
        catch (Exception e) { return -1; }
    }
    static long[] progress(String line) {
        if (line == null || !line.startsWith("SRPROGRESS|")) return null;
        String[] p = line.trim().split("\\|",-1);
        if (p.length != 6) return null;
        long bytes=number(p[1]), total=number(p[2]);
        if (total <= 0) total=number(p[3]);
        return new long[]{bytes,total,number(p[4]),number(p[5])};
    }
}
