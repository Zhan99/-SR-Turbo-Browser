package com.srcreation.browser;
import java.net.URI;
import java.util.Locale;
final class GoogleLinks {
    static final String GMAIL="https://mail.google.com/mail/";
    static final String CHOOSE="https://accounts.google.com/AccountChooser?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F";
    static final String ADD="https://accounts.google.com/AddSession?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F";
    static final String MANAGE="https://myaccount.google.com/";
    static boolean isAccountSite(String value){try{URI uri=URI.create(value);String host=uri.getHost();if(host==null||!"https".equalsIgnoreCase(uri.getScheme())||uri.getRawUserInfo()!=null)return false;switch(host.toLowerCase(Locale.ROOT)){case "accounts.google.com":case "mail.google.com":case "myaccount.google.com":return true;default:return false;}}catch(RuntimeException e){return false;}}
    static boolean isSignInPage(String value){return isAccountSite(value)&&"accounts.google.com".equalsIgnoreCase(URI.create(value).getHost());}
    static boolean isOAuth(String value){if(!isAccountSite(value))return false;URI uri=URI.create(value);if(!"accounts.google.com".equalsIgnoreCase(uri.getHost()))return false;String path=uri.getPath(),query=uri.getRawQuery();return (path!=null&&(path.toLowerCase(Locale.ROOT).contains("oauth")))||(query!=null&&(query.contains("client_id=")||query.contains("redirect_uri=")));}
}
