package com.srcreation.browser;

import java.util.Locale;

/** A transient estimate based on recently measured transfer throughput. */
final class TransferEta {
    private double smoothed;
    void reset() { smoothed = 0; }
    void sample(long bytesPerSecond) {
        if (bytesPerSecond <= 0) { reset(); return; }
        smoothed = smoothed <= 0 ? bytesPerSecond : 0.45 * bytesPerSecond + 0.55 * smoothed;
    }
    long seconds(long bytes, long total, long liveRate) {
        if (total <= 0 || bytes < 0) return -1;
        if (bytes >= total) return 0;
        if (liveRate <= 0 || smoothed <= 0) return -1;
        return Math.max(1L, (long)Math.ceil((total - bytes) / smoothed));
    }
    static String duration(long seconds) {
        if (seconds < 0) return "Calculating…";
        long days=seconds/86400, hours=(seconds/3600)%24, minutes=(seconds/60)%60, secs=seconds%60;
        if (days>0) return String.format(Locale.US,"%d d %02d h %02d m",days,hours,minutes);
        if (hours>0) return String.format(Locale.US,"%d h %02d m %02d s",hours,minutes,secs);
        if (minutes>0) return String.format(Locale.US,"%d m %02d s",minutes,secs);
        return secs+" s";
    }
    static String label(String state, long bytes, long total, long rate, long seconds) {
        switch (state) {
            case "Running":
                if (total <= 0) return "Unknown file size";
                if (bytes >= total) return "Finishing…";
                if (rate <= 0 || seconds < 0) return "Calculating…";
                return "~ " + duration(seconds);
            case "Saving": return "Saving file…";
            case "Paused": return "Paused";
            case "Queued": return "Waiting in queue";
            case "Stopping": return "Stopping…";
            case "Completed": return "Completed";
            default: return "—";
        }
    }
}
