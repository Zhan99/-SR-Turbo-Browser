package com.srcreation.browser;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.function.Predicate;

/** Collect both Android picker result shapes without losing multi-selection. */
final class UploadSelection {
    static <T> List<T> collect(boolean success, boolean multiple, List<T> clips, T single,
                               Predicate<T> allowed) {
        List<T> result = new ArrayList<>();
        if (!success) return result;
        LinkedHashSet<T> unique = new LinkedHashSet<>();
        if (clips != null) for (T item : clips) if (item != null) unique.add(item);
        if (single != null) unique.add(single);
        for (T item : unique) {
            if (!allowed.test(item)) continue;
            result.add(item);
            if (!multiple) break;
        }
        return result;
    }
}
