package com.srcreation.browser;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import android.os.Process;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

/** Activity-scoped, read-only upload picker. No broad storage permission required. */
final class UploadPicker {
    private final Activity activity;
    private WebView owner;
    private ValueCallback<Uri[]> callback;
    private boolean multiple;
    private int request = -1;
    private int nextRequest = 0x4000;

    UploadPicker(Activity activity) { this.activity = activity; }

    boolean open(WebView web, ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams params) {
        // Only one outstanding chooser. Never deliver an old result to a new page.
        if (callback != null) {
            cb.onReceiveValue(null);
            return true;
        }
        int mode = params.getMode();
        if (mode != WebChromeClient.FileChooserParams.MODE_OPEN &&
                mode != WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            cb.onReceiveValue(null);
            message("Only file uploads are supported here");
            return true;
        }
        owner = web;
        callback = cb;
        multiple = mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE;
        request = nextRequest++;
        if (nextRequest > 0x7ffe) nextRequest = 0x4000;
        // Keep the website's MIME filters, but make multiple selection explicit.
        try {
            Intent intent = params.createIntent();
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivityForResult(intent, request);
        } catch (RuntimeException unavailable) {
            try {
                Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                fallback.addCategory(Intent.CATEGORY_OPENABLE);
                fallback.setType("*/*");
                String[] types = params.getAcceptTypes();
                ArrayList<String> mime = new ArrayList<>();
                if (types != null) for (String type : types) {
                    if (type != null && type.contains("/")) mime.add(type);
                }
                if (mime.size() == 1) fallback.setType(mime.get(0));
                else if (!mime.isEmpty()) fallback.putExtra(Intent.EXTRA_MIME_TYPES, mime.toArray(new String[0]));
                fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivityForResult(fallback, request);
            } catch (RuntimeException failed) {
                finish(null);
                message("File picker unavailable. Please try again.");
            }
        }
        return true;
    }

    boolean result(int req, int resultCode, Intent data) {
        if (req != request || callback == null) return false;
        if (resultCode != Activity.RESULT_OK) { finish(null); return true; }
        List<Uri> clips = new ArrayList<>();
        Uri single = null;
        try {
            if (data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) {
                    clips.add(clip.getItemAt(i).getUri());
                }
                single = data.getData();
            }
            List<Uri> selected = UploadSelection.collect(true, multiple, clips, single, this::allowed);
            // Fail closed if the picker returns no readable content URI.
            if (selected.isEmpty()) {
                finish(null);
                message("No readable file returned. Try Files or another photo.");
            } else {
                boolean partial = multiple && selected.size() < new java.util.HashSet<>(clips).size();
                finish(selected.toArray(new Uri[0]));
                if (partial)
                    message("Some selected files could not be accessed");
            }
        } catch (RuntimeException invalid) {
            finish(null);
            message("File selection could not be read. Please try again.");
        }
        return true;
    }

    private boolean allowed(Uri uri) {
        if (!"content".equals(uri.getScheme()) || uri.getAuthority() == null) return false;
        try {
            // Require a URI grant, not merely access through an app-wide permission.
            if (activity.checkUriPermission(uri, Process.myPid(), Process.myUid(),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED) return false;
            ProviderInfo provider = activity.getPackageManager().resolveContentProvider(uri.getAuthority(), 0);
            return provider == null || !activity.getPackageName().equals(provider.packageName);
        } catch (RuntimeException denied) { return false; }
    }

    void cancel(WebView web) { if (owner == web) finish(null); }
    void cancelAll() { finish(null); }

    private void finish(Uri[] uris) {
        ValueCallback<Uri[]> cb = callback;
        // Reset before invoking WebView: callback is one-shot and may re-enter.
        callback = null;
        owner = null;
        request = -1;
        multiple = false;
        if (cb != null) cb.onReceiveValue(uris);
    }
    private void message(String text) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }
}
