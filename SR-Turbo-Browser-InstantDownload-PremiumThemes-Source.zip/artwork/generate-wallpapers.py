from PIL import Image, ImageDraw, ImageFilter
import math, random, pathlib
out=pathlib.Path(__file__).resolve().parents[1] / 'app/src/main/res/drawable-nodpi'
out.mkdir(parents=True,exist_ok=True)
W,H=720,1200

def sky(top,bottom):
 im=Image.new('RGB',(W,H)); d=ImageDraw.Draw(im)
 for y in range(H):
  t=y/(H-1); d.line((0,y,W,y),fill=tuple(round(a+(b-a)*t) for a,b in zip(top,bottom)))
 return im

def glow(im,x,y,r,col):
 layer=Image.new('RGBA',im.size); d=ImageDraw.Draw(layer);d.ellipse((x-r,y-r,x+r,y+r),fill=(*col,155)); layer=layer.filter(ImageFilter.GaussianBlur(r*.48)); im.paste(layer,(0,0),layer)

def poly(d,pts,c): d.polygon([(int(x),int(y)) for x,y in pts],fill=c)
def ridge(d,seed,y,amp,c,step=55):
 rng=random.Random(seed); pts=[(x,y+rng.uniform(-amp,amp)) for x in range(-step,W+step*2,step)];poly(d,pts+[(W+step,H),(-step,H)],c)
def pines(d,seed,base,lo,hi,c,count):
 rng=random.Random(seed)
 for _ in range(count):
  x=rng.randrange(-30,W+30); h=rng.randrange(lo,hi); y=base+rng.randrange(-25,30); w=h*.25
  d.rectangle((x-2,y-h*.9,x+2,y),fill=c)
  for k in range(4):
   yy=y-h+k*h*.2; ww=w*(.4+k*.2);poly(d,[(x,yy),(x-ww,yy+h*.37),(x+ww,yy+h*.37)],c)
def save(im,name): im.save(out/f'theme_{name}.webp','WEBP',quality=86,method=6)
# Alpine
im=sky((47,83,139),(224,188,150));glow(im,540,350,110,(255,218,165));d=ImageDraw.Draw(im);d.ellipse((507,317,573,383),fill=(255,227,185));
poly(d,[(0,705),(0,605),(100,455),(178,512),(305,320),(420,505),(505,420),(720,620),(720,780)],(103,130,155))
poly(d,[(155,553),(305,320),(420,505),(370,465),(347,481),(305,423),(277,471),(249,455)],(225,236,237))
poly(d,[(0,710),(110,570),(215,646),(330,532),(444,665),(560,535),(720,695),(720,780),(0,780)],(55,85,109));
d.rectangle((0,750,W,H),fill=(41,82,104)); rng=random.Random(10)
for i in range(130):
 y=rng.randrange(755,H);x=rng.randrange(W);l=rng.randrange(12,110);d.line((x,y,min(W,x+l),y),fill=rng.choice([(62,103,121),(85,122,136),(107,142,150)]),width=1)
pines(d,5,780,60,140,(25,54,64),27);pines(d,6,1220,100,260,(19,40,49),19);save(im,'alpine')
# Forest
im=sky((26,66,65),(158,191,158));glow(im,460,425,140,(214,224,167));d=ImageDraw.Draw(im)
for k,(y,c) in enumerate([(675,(96,142,122)),(800,(57,111,92)),(940,(34,82,68)),(1220,(15,49,43))]):
 ridge(d,20+k,y,45,c);pines(d,30+k,y+50,100+k*27,230+k*50,c,45)
save(im,'forest')
# Ocean
im=sky((38,102,150),(200,239,220));glow(im,550,430,110,(255,245,187));d=ImageDraw.Draw(im);d.ellipse((517,397,583,463),fill=(255,241,195));d.rectangle((0,680,W,H),fill=(34,132,150));
rng=random.Random(4)
for y in range(680,H):
 t=(y-680)/(H-680);d.line((0,y,W,y),fill=(round(29+41*t),round(111+71*t),round(145+25*t)))
for i in range(160):
 y=rng.randrange(682,H);x=rng.randrange(W);d.line((x,y,x+rng.randrange(12,94),y),fill=rng.choice([(80,184,185),(113,205,198),(170,225,208)]),width=1)
poly(d,[(0,980),(130,1030),(320,1050),(520,1130),(720,1150),(720,H),(0,H)],(225,201,150));poly(d,[(0,960),(150,1020),(320,1040),(530,1117),(720,1140),(720,1153),(520,1134),(320,1054),(130,1034),(0,984)],(225,247,227));
# silhouette palms
for x,y,h in [(65,1080,315),(695,1160,245)]:
 d.line((x,y,x+35,y-h),fill=(22,65,64),width=14)
 xx=x+35;yy=y-h
 for a in [-3,-2.5,-2,-1.2,-.5,.15,.6]:
  ex=xx+math.cos(a)*110;ey=yy+math.sin(a)*70;poly(d,[(xx,yy),(xx+(ex-xx)*.55,yy+(ey-yy)*.55-16),(ex,ey+30),(xx+(ex-xx)*.5,yy+(ey-yy)*.5+13)],(22,65,64))
save(im,'ocean')
# Sunset
im=sky((73,53,111),(251,154,99));glow(im,500,550,180,(255,184,105));d=ImageDraw.Draw(im);d.ellipse((420,470,580,630),fill=(255,213,147))
for k,(y,c) in enumerate([(700,(167,91,104)),(815,(135,70,91)),(955,(100,55,76)),(1090,(68,39,64))]):
 pts=[(x,y+math.sin(x/150+k*1.4)*65+math.sin(x/240+k)*25) for x in range(-10,W+12,8)];poly(d,pts+[(W,H),(0,H)],c)
save(im,'sunset')
# Aurora
im=sky((11,20,56),(66,91,129));rng=random.Random(15);d=ImageDraw.Draw(im)
for _ in range(210):
 x,y=rng.randrange(W),rng.randrange(0,730);r=rng.choice([1,1,1,2]);d.ellipse((x,y,x+r,y+r),fill=rng.choice([(159,182,212),(220,235,251),(129,158,191)]))
lay=Image.new('RGBA',im.size);ld=ImageDraw.Draw(lay)
for k in range(7):
 pts=[(x,340+math.sin(x/150+k*.16)*95+math.sin(x/75)*27+k*14) for x in range(-20,W+30,5)];ld.line(pts,fill=(68,230,163,110-k*10),width=30+k*6)
lay=lay.filter(ImageFilter.GaussianBlur(17));im.paste(lay,(0,0),lay);d=ImageDraw.Draw(im)
ridge(d,3,820,130,(35,48,83),80);ridge(d,9,965,100,(22,32,62),90);pines(d,19,1220,120,270,(13,22,45),33);save(im,'aurora')
# Blossom
im=sky((137,121,171),(255,212,211));glow(im,520,470,140,(255,223,201));d=ImageDraw.Draw(im);d.ellipse((463,413,577,527),fill=(255,232,214));ridge(d,19,740,70,(169,136,171),80);ridge(d,6,865,60,(124,111,147),90);ridge(d,7,1070,70,(82,86,118),90)
rng=random.Random(35)
for side in [0,1]:
 x=0 if side==0 else W; direction=1 if side==0 else -1
 for i in range(8):
  yy=170+i*85; ex=x+direction*rng.randrange(100,245);ey=yy-rng.randrange(30,100);d.line((x,yy,ex,ey),fill=(91,60,87),width=6)
  for j in range(35):
   t=rng.random();px=x+(ex-x)*t+rng.gauss(0,29);py=yy+(ey-yy)*t+rng.gauss(0,25);r=rng.randrange(4,13);d.ellipse((px-r,py-r,px+r,py+r),fill=rng.choice([(244,166,190),(255,197,210),(255,222,228),(216,132,170)]))
for i in range(45):
 x,y=rng.randrange(W),rng.randrange(450,H);d.ellipse((x,y,x+5,y+8),fill=(236,176,202))
save(im,'blossom')
