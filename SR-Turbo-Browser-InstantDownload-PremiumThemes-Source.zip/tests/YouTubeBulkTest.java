package com.srcreation.browser;
import java.util.*;
public class YouTubeBulkTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        if(args.length>0){System.out.println(YouTubeBulk.SCAN);return;}
        String a="https://www.youtube.com/watch?v=abcdefghijk", b="https://www.youtube.com/watch?v=ABCDEFGHIJK";
        check(YouTubeBulk.watchPage(a+"&list=RD123"));
        check(!YouTubeBulk.watchPage("https://youtube.com.evil.test/watch?v=abcdefghijk"));
        check(!YouTubeBulk.watchPage("https://www.youtube.com/shorts/abcdefghijk"));
        check(YouTubeBulk.normalize(Arrays.asList(a,a+"&list=RD123","https://youtu.be/abcdefghijk",null,"https://example.com/watch?v=abcdefghijk",b)).equals(Arrays.asList(a,b)));
        ArrayList<String> many=new ArrayList<>();for(int i=0;i<600;i++)many.add("https://youtu.be/"+String.format(Locale.ROOT,"%011d",i));
        check(YouTubeBulk.normalize(many).size()==500);
        check(YouTubeBulk.folder("test").equals("Download/SR Turbo/YouTube/Batch-test"));
        System.out.println("YouTube batch URL, deduplication, limit and folder tests passed");
    }
}
