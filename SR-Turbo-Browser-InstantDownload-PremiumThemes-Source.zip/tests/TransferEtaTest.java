package com.srcreation.browser;
public class TransferEtaTest {
    static void eq(Object actual,Object expected){if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        TransferEta eta=new TransferEta();
        eq(eta.seconds(0,1000,0),-1L);
        eta.sample(1000);
        eq(eta.seconds(1000,61000,1000),60L);
        eq(eta.seconds(1000,-1,1000),-1L);
        eq(eta.seconds(61000,61000,1000),0L);
        eq(eta.seconds(60999,61000,1000),1L);
        eta.sample(2000);
        eq(eta.seconds(1000,61000,2000),42L);
        eq(eta.seconds(1000,61000,0),-1L);
        eta.reset();eq(eta.seconds(1000,61000,1000),-1L);
        eta.sample(500);eq(eta.seconds(1000,61000,500),120L);
        eta.sample(0);eq(eta.seconds(1000,61000,500),-1L);
        eq(TransferEta.duration(125),"2 m 05 s");
        eq(TransferEta.duration(3661),"1 h 01 m 01 s");
        eq(TransferEta.duration(90061),"1 d 01 h 01 m");
        eq(TransferEta.label("Running",1,-1,1,10),"Unknown file size");
        eq(TransferEta.label("Running",1,100,0,-1),"Calculating…");
        eq(TransferEta.label("Running",1,100,1,99),"~ 1 m 39 s");
        eq(TransferEta.label("Paused",1,100,0,-1),"Paused");
        eq(TransferEta.label("Queued",1,100,0,-1),"Waiting in queue");
        eq(TransferEta.label("Saving",100,100,0,0),"Saving file…");
        eq(TransferEta.label("Completed",100,100,0,0),"Completed");
        System.out.println("ETA tests passed");
    }
}
