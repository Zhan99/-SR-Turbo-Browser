package com.srcreation.browser;
import java.util.*;
public class SessionRulesTest {
    static int checks;
    static void eq(Object expected,Object actual){checks++;if(!Objects.equals(expected,actual))throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        eq("https://example.com/path?q=1",SessionRules.safeUrl("https://example.com/path?q=1"));
        for(String bad:Arrays.asList(null,"about:blank","file:///sdcard/test","javascript:alert(1)","https://user:pw@example.com","https://accounts.google.com/signin","https:///nohost"))eq(SessionRules.HOME,SessionRules.safeUrl(bad));
        eq(2,SessionRules.index(2,4));eq(3,SessionRules.index(8,4));eq(0,SessionRules.index(-1,4));eq(-1,SessionRules.index(0,0));
        eq(0,SessionRules.percent(-3));eq(57,SessionRules.percent(57));eq(100,SessionRules.percent(101));
        eq("Example",SessionRules.title("Example","https://example.com"));eq("example.com",SessionRules.title("New tab","https://example.com"));
        List<String> a=new ArrayList<>(Arrays.asList("Google","YouTube","Facebook","Gmail"));eq(true,SessionRules.move(a,0,2));eq(Arrays.asList("YouTube","Facebook","Google","Gmail"),a);eq(true,SessionRules.move(a,3,0));eq(Arrays.asList("Gmail","YouTube","Facebook","Google"),a);eq(false,SessionRules.move(a,0,0));eq(false,SessionRules.move(a,1,4));eq(false,SessionRules.move(a,-1,0));
        System.out.println("Session and shortcut ordering checks passed: "+checks);
    }
}
