package com.srcreation.browser;
public class SiteVideoLinksTest {
    static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] a){
        String yt="https://youtu.be/abcdefghijk",fb="https://www.facebook.com/reel/123456",web="https://example.org/video/123?quality=hd";
        check(SiteVideoLinks.canonical(yt).equals("https://www.youtube.com/watch?v=abcdefghijk"));
        check(SiteVideoLinks.canonical(fb).equals(fb));check(SiteVideoLinks.canonical(web).equals(web));
        check(SiteVideoLinks.facebook("https://fb.watch/abcd/"));check(!SiteVideoLinks.facebook("https://facebook.com.example.org/"));
        check(SiteVideoLinks.canonical("https://youtube.com/playlist?list=123")==null);
        check(SiteVideoLinks.canonical("file:///etc/passwd")==null);check(SiteVideoLinks.canonical("https://user:pass@example.org/")==null);
        check(SiteVideoLinks.canonical("https://127.0.0.1/")==null);check(SiteVideoLinks.canonical("https://localhost/")==null);
        check(SiteVideoLinks.folder(fb).endsWith("/Facebook"));check(SiteVideoLinks.folder(web).endsWith("/Videos"));check(SiteVideoLinks.folder(yt).endsWith("/YouTube"));
        check(SiteVideoLinks.format(yt,720).equals(YouTubeLinks.format(720)));check(SiteVideoLinks.format(fb,480).contains("height<=?480"));
        check(SiteVideoLinks.error(fb,"HTTP Error 403: Forbidden").contains("server refused"));
        System.out.println("SiteVideoLinks: 16 checks passed");
    }
}
