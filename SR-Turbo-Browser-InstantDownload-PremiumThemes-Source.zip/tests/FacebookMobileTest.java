package com.srcreation.browser;
public final class FacebookMobileTest {
    static void check(boolean b,String label){if(!b)throw new AssertionError(label);}
    public static void main(String[] args){
        String ua="Mozilla/5.0 (Linux; Android 15; Device; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/140.0.7339.51 Mobile Safari/537.36";
        check(FacebookMobile.isSite("https://m.facebook.com/?_rdc=2&_rdr"),"mobile redirect host");
        check(FacebookMobile.isSite("https://WWW.FACEBOOK.COM/"),"www host case");
        for(String bad:new String[]{null,"https://m.facebook.com.evil.com/","https://facebook.com@evil.com/","https://user@facebook.com/","http://facebook.com/","https://facebook.com:8443/","https://accounts.google.com/","https://l.facebook.com/"})check(!FacebookMobile.isSite(bad),"reject "+bad);
        check(FacebookMobile.entry("https://www.facebook.com",true).equals(FacebookMobile.HOME),"mobile homepage");
        check(FacebookMobile.entry("https://www.facebook.com/",false).equals("https://www.facebook.com/"),"desktop unchanged");
        for(String url:new String[]{"https://www.facebook.com/login/","https://www.facebook.com/?next=abc","https://www.facebook.com/#feed","https://www.facebook.com/reel/123","https://example.com/"})check(FacebookMobile.entry(url,true).equals(url),"preserve "+url);
        String mobile=FacebookMobile.agent(ua,true);
        check(mobile.contains("Chrome/140.0.7339.51"),"actual version");check(mobile.contains("Mobile Safari/"),"mobile identity");
        check(!mobile.contains("; wv")&&!mobile.contains("Version/4.0"),"layout UA");
        check(FacebookMobile.agent(ua,false).equals(ua),"disabled unchanged");check(FacebookMobile.agent("other engine",true).equals("other engine"),"unknown engine unchanged");
        check(FacebookMobile.agent(ua.replace("Mobile Safari/","Safari/"),true).contains("Mobile Safari/"),"tablet mobile layout");
        System.out.println("FacebookMobileTest: all checks passed");
    }
}
