package com.srcreation.browser;
public class YouTubeLinksTest {
    static void require(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args){String id="AbCdEf123_-", expected="https://www.youtube.com/watch?v="+id;
        for(String url:new String[]{expected,"https://m.youtube.com/watch?x=1&v="+id+"&list=abc","https://youtu.be/"+id+"?si=x","https://www.youtube.com/shorts/"+id,"https://youtube.com/live/"+id,"https://youtube.com/embed/"+id})require(expected.equals(YouTubeLinks.canonical(url)));
        for(String url:new String[]{null,"https://youtube.com.evil.test/watch?v="+id,"https://youtube.com@evil.test/watch?v="+id,"https://evil.test/"+id,"https://youtube.com/playlist?list=x","https://youtu.be/short","https://youtube.com/watch?v="+id+"&v="+id,"file:///a","https://youtube.com:444/watch?v="+id})require(YouTubeLinks.canonical(url)==null);
        require(YouTubeLinks.format(1080).contains("height<=1080"));require(YouTubeLinks.format(999).contains("height<=720"));
        long[] p=YouTubeLinks.progress("SRPROGRESS|100|NA|200|10.5|10");require(p[0]==100&&p[1]==200&&p[2]==10&&p[3]==10);require(YouTubeLinks.progress("unrelated")==null);require(YouTubeLinks.number("NaN")==-1);require(YouTubeLinks.number("-1")==-1);System.out.println("YouTube URL, quality and stream progress tests passed");}
}
