package com.srcreation.browser;
import java.util.*;
public final class UploadSelectionTest {
    static int count;
    static void check(boolean ok) { if (!ok) throw new AssertionError("case " + (count+1)); count++; }
    static List<String> select(boolean success, boolean multiple, List<String> clips, String single) {
        return UploadSelection.collect(success,multiple,clips,single,s->s.startsWith("content://"));
    }
    public static void main(String[] args) {
        String a="content://photos/a", b="content://photos/b", c="content://files/c";
        check(select(true,true,List.of(a,b),null).equals(List.of(a,b)));
        check(select(true,false,null,a).equals(List.of(a)));
        check(select(true,true,List.of(a,b),c).equals(List.of(a,b,c)));
        check(select(true,true,List.of(a,b),a).equals(List.of(a,b)));
        check(select(false,true,List.of(a,b),a).isEmpty());
        check(select(true,true,null,null).isEmpty());
        check(select(true,false,List.of(a,b),null).equals(List.of(a)));
        check(select(true,true,Arrays.asList(null,a,a,"file:///private"),b).equals(List.of(a,b)));
        check(select(true,true,List.of("file:///private"),"https://example.org").isEmpty());
        check(select(true,false,List.of("file:///private",b),a).equals(List.of(b)));
        System.out.println("Upload selection: "+count+" tests passed");
    }
}
