const fs=require('fs'), vm=require('vm'), assert=require('assert');
const script=fs.readFileSync(process.argv[2],'utf8');
const location=new URL('https://www.youtube.com/watch?v=abcdefghijk');
function link(href,{hidden=false,ad=false,card=true,title='Video'}={}) {return {href,getClientRects:()=>hidden?[]:[{}],closest:s=>s.startsWith('[hidden]')?(ad?{}:null):(card?{querySelector:()=>({getAttribute:()=>title,textContent:title})}:null),getAttribute:()=>null};}
const rows=[link('https://www.youtube.com/watch?v=abcdefghijk&list=RDxx'),link('https://www.youtube.com/watch?v=abcdefghijk'),link('https://www.youtube.com/shorts/ABCDEFGHIJK'),link('https://www.youtube.com/watch?v=00000000000',{ad:true}),link('https://www.youtube.com/watch?v=11111111111',{hidden:true}),link('https://www.youtube.com/watch?v=22222222222',{card:false}),link('https://evil.test/watch?v=33333333333'),link('https://www.youtube.com/playlist?list=PL123')];
const document={querySelector:s=>{assert.equal(s,'ytd-watch-flexy #secondary');return {querySelectorAll:()=>rows}}};
const result=vm.runInNewContext(script,{document,location,URL});
assert.equal(result.length,2);assert.equal(result[0].url,'https://www.youtube.com/watch?v=abcdefghijk');assert.equal(result[1].url,'https://www.youtube.com/watch?v=ABCDEFGHIJK');
assert.equal(vm.runInNewContext(script,{document,location:new URL('https://evil.test/watch?v=abcdefghijk'),URL}).length,0);
assert.equal(vm.runInNewContext(script,{document:{querySelector:()=>null},location,URL}).length,0);
console.log('Right rail scan fixture: deduplication, Shorts, ad/hidden/unrelated links and origin tests passed');
