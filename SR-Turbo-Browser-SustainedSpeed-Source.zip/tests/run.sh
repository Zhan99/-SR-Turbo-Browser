#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
javac --add-modules jdk.httpserver -d "$tmp" app/src/main/java/com/srcreation/browser/DownloadEngine.java app/src/main/java/com/srcreation/browser/TransferEta.java tests/EngineTest.java tests/TransferEtaTest.java
java --add-modules jdk.httpserver -cp "$tmp" com.srcreation.browser.EngineTest
java -cp "$tmp" com.srcreation.browser.TransferEtaTest
