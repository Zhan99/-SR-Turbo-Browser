# SR Turbo Browser — Android source
Developer: Shahriar Rahman | SR Creation Farm | v1.4

Native Java Android WebView browser. Android 10+ (API 29), target 34, compile SDK 35, Gradle 8.7, AGP 8.6.1, JDK 17. Requires internet for web browsing and downloads. No API keys, paid SDKs, or external application libraries.

## Build using GitHub Actions
Option A: upload the single `SR-Turbo-Browser-SustainedSpeed-Source.zip` to your repository root. Add the separately provided `build-apk.yml` at `.github/workflows/build-apk.yml` (not the repository root). Open Actions → Build SR Turbo Browser APK → Run workflow. Download `SR-Turbo-Browser-APK` from the successful run's Artifacts, extract and install the APK.
Option B: extract the source ZIP, upload the project contents including `.github/workflows/build-apk.yml` to the repository, then use Actions as above. Do not upload multiple source copies. The workflow uses a standard debug signing key; subsequent builds on new runners may have a different signing key. Use your own stable signing keystore for install-over updates and production distribution.

## Features and limitations
- 20 tabs, bookmarks/history, desktop UA, find, share, file chooser, fullscreen WebView media, HTTPS certificate-error cancellation, WebView Safe Browsing, 4 search engines, light/dark app chrome, private process with separate WebView storage, cookies disabled and best-effort cleanup. Private browsing is not anonymity, and downloaded files/logs remain. Dark theme does not recolor all websites. Some websites may not support Android WebView login, media, uploads or other functionality.
- Default Turbo Boost: maximum 16 connections per file, adjustable 1–16 in Settings. Modes 9–16 prioritize a single download (no other browser download runs alongside it); modes 1–8 allow up to two jobs. For sufficiently large range-enabled files Turbo starts up to the full selected worker ceiling immediately, using a bounded queue of smaller pieces so workers can fetch another piece as soon as one completes. The 1 MiB/s (1,048,576 bytes/s) target is a goal, not a minimum or cap. Actual connections depend on file size and stable range/validator support; partially downloaded files keep their validated layout on resume. 429/503 responses stop the job with the server Retry-After hint if present, instead of repeatedly reconnecting. There is no artificial bandwidth cap, no OS-wide bandwidth reservation, and no bypass of ISP or server limits. The existing foreground service and wake lock support active screen-off downloads subject to OS policy. Turbo mode may consume more data radio power, battery and server connections; select Standard when needed. A range probe and stable validator prevent unsafe reuse; unsupported servers use a single stream. Incomplete single-stream downloads restart. Range parts are retried up to 3 attempts. HTTP and HTTPS direct GET downloads supported; blob/data URLs, DRM, POST-only downloads, cross-origin authenticated redirects and protected streaming downloads are not supported. Login cookies are held in memory only and passed to the original download origin; after a process restart, authenticated downloads may require a fresh download from the website. Download URLs and names are stored locally, including private-mode downloads after explicit confirmation. Downloads go to Download/SR Turbo via MediaStore; staging temporarily needs additional disk space.
- Foreground service with progress notification, pause/resume/cancel, file open/share, queue. If the OS kills the process or the phone restarts, reopen Downloads and manually resume; background operation depends on Android/OEM policies. Grant notification permission for visible notifications on Android 13+. No hidden background execution. Debug APK is for testing, not Play Store submission.

## Verification
`bash tests/run.sh` compiles and runs the pure Java download engine with a local HTTP server and byte-for-byte comparisons. Covers segmented transfer, no-range fallback, rejected ranges, missing validator, redirects, sustained Turbo full worker scheduling, server throttling, and pause/resume across changed connection settings. Android SDK/device were not available in the creation environment; GitHub Actions performs the first actual Android compile. UI, permissions, device compatibility, throughput, and private-mode behavior require on-device testing.

## SDK workflow repair — 2026-11-26
The obsolete SDK package `tools` is no longer published. This workflow avoids `android-actions/setup-android@v3` and uses the preinstalled SDK command-line tools on `ubuntu-24.04`. It checks required packages, installs only missing `platforms;android-35`, `build-tools;34.0.0`, and `platform-tools`, checks SDK licenses, and verifies the built APK signature. Keep only one source ZIP in the repository. The SDK repair is retained unchanged. For Turbo Boost replace the source ZIP as well. Start a new workflow run after committing the replacement; rerunning a failed job may reuse the old workflow revision.

## Premium interface update (1.2)
- Three-dot Control Center uses current state, ON/OFF labels, switches, highlighted cards and a toolbar count of active modes.
- Turbo Boost toggles between 16 and 8 maximum connections for new downloads; existing transfers are not reconfigured. The connection limit selector still supports 1–16.
- Desktop mode is per tab. Private session is a separate activity, not a global switch. Dark theme applies to browser chrome, home, control center and download manager (not website content).
- Bookmark status is based on the current URL; a saved bookmark can be removed from the menu.
- Download dashboard shows measured aggregate transfer speed, counts and color-coded transfer states.
- The previous download engine and SDK workflow are unchanged. UI is not device-tested in this environment.

## Live estimated remaining time (1.3)
- Every download card displays estimated time left, based on remaining bytes and a smoothed recent transfer rate. The UI refreshes every 700 ms; notification refreshes every second and includes ETA when one transfer is active. Multiple transfers retain individual estimates on their cards.
- Unknown length or unavailable speed never produces a fabricated ETA; paused, queued, saving and completed transfers show their respective states. Estimates exclude final disk assembly and may vary with network speed.
- Pure Java ETA tests run alongside existing engine tests. At 1.3 the Turbo engine and SDK workflow were unchanged.

## Sustained speed (1.4)
- Turbo starts up to 16 workers immediately rather than ramping from 8. Files with stable byte ranges are divided into up to 512 pieces (typically at least 256 KiB), with a bounded worker pool. Workers reuse queued pieces; on resume, larger remaining pieces are scheduled first. Older partial layouts remain readable.
- This reduces idle workers and the slow final stretch; it cannot keep all connections active once fewer pieces remain, guarantee constant throughput or exceed actual network/server/storage capacity. Speed display remains measured, and ETA remains responsive to real conditions. Server 429/503 handling, queue priority, fallback and validation remain intact. No fake speed, no throttling to match the initial speed.
- The SDK workflow is unchanged. Android build and real-world throughput remain to be tested.
