/* Retain a bounded Blob reference in its creator frame. Native may request that
 * exact URL after an explicit download, even when the click was in another frame.
 * No file contents are sent merely because a Blob was created. */
(() => {
  'use strict';
  const bridge=window.SrGeneratedFiles;
  if(!bridge || window.__srGeneratedBlob) return;
  const MAX=128*1024*1024, CHUNK=64*1024;
  const blobs=new Map(), jobs=new Map(), pendingReads=new Map(); let retainedBytes=0;
  const send=v=>{try{bridge.postMessage(JSON.stringify(v));}catch(_){}};
  const drop=u=>{const b=blobs.get(u);if(b){retainedBytes-=b.size;blobs.delete(u);send({op:'forget',url:u});}};
  const create=URL.createObjectURL, revoke=URL.revokeObjectURL;
  const nativeClick=HTMLAnchorElement.prototype.click;
  const originalFetch=window.fetch.bind(window);
  const newId=()=>globalThis.crypto&&crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2);
  URL.createObjectURL=function(obj){
    const u=create.call(this,obj);
    if(obj instanceof Blob&&obj.size<=MAX){
      blobs.set(u,obj);retainedBytes+=obj.size;
      send({op:'register',url:u});
      while(blobs.size>64||retainedBytes>MAX)drop(blobs.keys().next().value);
    }
    return u;
  };
  URL.revokeObjectURL=function(u){
    const key=String(u);if(blobs.has(key))setTimeout(()=>drop(key),120000);
    return revoke.call(this,u);
  };
  Object.defineProperty(window,'__srGeneratedBlob',{value:u=>blobs.get(u),configurable:false});
  async function read(u){
    const saved=blobs.get(u);if(saved)return saved;
    const early=pendingReads.get(u);if(early){pendingReads.delete(u);const b=await early;if(b)return b;}
    try{const r=await originalFetch(u);if(!r.ok)throw Error('File unavailable');return await r.blob();}
    catch(_){return new Promise((resolve,reject)=>{try{const x=new XMLHttpRequest();x.open('GET',u);x.responseType='blob';x.onload=()=>x.status>=200&&x.status<300&&x.response?resolve(x.response):reject(Error('File unavailable'));x.onerror=()=>reject(Error('File unavailable'));x.timeout=15000;x.ontimeout=x.onerror;x.send();}catch(e){reject(e);}});}
  }
  async function start(u,name,id=newId()){
    if(jobs.size>=2){send({op:'notice',id,name,error:'Another generated file is being saved.'});return;}
    const job={blob:null,offset:0,busy:false};jobs.set(id,job);
    try{
      const b=await read(u);
      if(b.size>MAX)throw Error('Generated file exceeds 128 MB');
      if(!jobs.has(id))return;
      job.blob=b;send({op:'begin',id,name,mime:b.type,size:b.size});
    }catch(e){jobs.delete(id);send({op:'notice',id,name,error:String(e).includes('128 MB')?'Generated file exceeds 128 MB':'Generated file unavailable. Export again on the original page.'});}
  }
  function handles(a){return a instanceof HTMLAnchorElement&&a.hasAttribute('download')&&/^(blob:|data:)/i.test(a.href);}
  function request(a){
    const u=a.href,name=(a.getAttribute('download')||'').slice(0,200);
    // If created in another frame, ask native to route to that frame. Never
    // attempt to read another frame's DOM or relax browser origin restrictions.
    if(u.startsWith('blob:')&&!blobs.has(u)){
      // Start reading before the website can revoke a worker-created URL.
      if(!pendingReads.has(u)&&pendingReads.size<2){
        const early=originalFetch(u).then(r=>r.ok?r.blob():null).catch(()=>null);
        pendingReads.set(u,early);setTimeout(()=>{if(pendingReads.get(u)===early)pendingReads.delete(u);},30000);
      }
      send({op:'resolve',id:newId(),url:u,name});
    }
    else start(u,name);
  }
  HTMLAnchorElement.prototype.click=function(){if(handles(this)){request(this);return;}return nativeClick.apply(this,arguments);};
  document.addEventListener('click',e=>{if(e.defaultPrevented||e.button!==0)return;const a=e.composedPath().find(handles);if(a){e.preventDefault();request(a);}},true);
  bridge.onmessage=async e=>{
    let q;try{q=JSON.parse(e.data);}catch(_){return;}
    if(q.op==='capture'&&typeof q.url==='string'&&q.url.startsWith('blob:')){start(q.url,String(q.name||'').slice(0,200),q.id);return;}
    const j=jobs.get(q.id);if(!j)return;
    if(q.op==='end'){jobs.delete(q.id);return;}
    if(q.op!=='next'||!j.blob||j.busy||q.offset!==j.offset)return;
    j.busy=true;
    try{const end=Math.min(j.blob.size,j.offset+CHUNK);const bytes=new Uint8Array(await j.blob.slice(j.offset,end).arrayBuffer());let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));const offset=j.offset;j.offset=end;j.busy=false;send({op:'chunk',id:q.id,offset,data:btoa(raw)});}
    catch(_){jobs.delete(q.id);send({op:'abort',id:q.id});}
  };
})();
