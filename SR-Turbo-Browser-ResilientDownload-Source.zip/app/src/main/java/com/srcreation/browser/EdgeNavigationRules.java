package com.srcreation.browser;

/** Pure rules for the optional swipe-out browser navigation controls. */
final class EdgeNavigationRules {
    static final int PINNED=0, LEFT=1, RIGHT=2;
    static int mode(int value){return value==LEFT||value==RIGHT?value:PINNED;}
    static boolean enabled(int value){return mode(value)!=PINNED;}
    static int delay(int seconds){return seconds==0||seconds==3||seconds==5||seconds==10?seconds:3;}
    static int direction(int value){return mode(value)==RIGHT?1:-1;}
    static boolean inward(int mode,float dx,float dy,float threshold){
        return enabled(mode)&&-direction(mode)*dx>=threshold&&Math.abs(dx)>Math.abs(dy)*1.25f;
    }
    static boolean tap(float maxDistance,float slop,long duration,boolean multiple){
        return !multiple&&maxDistance<=slop&&duration>=0&&duration<=350;
    }
    static int contentMargin(boolean floating,int mode){return floating||enabled(mode)?0:DisplaySpace.DOCK_HEIGHT;}
}
