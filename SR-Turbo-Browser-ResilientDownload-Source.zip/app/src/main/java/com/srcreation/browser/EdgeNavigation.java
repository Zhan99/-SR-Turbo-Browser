package com.srcreation.browser;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Keeps navigation outside WebView: gestures never intercept a website's scroll or zoom. */
final class EdgeNavigation {
    private final BrowserActivity host;
    private final FrameLayout viewport;
    private final View bar;
    private final TextView handle;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable timeout=()->hide(true);
    private int mode=EdgeNavigationRules.PINNED, seconds=3;
    private boolean outside=true, shown=true, suspended=false, tracking=false, pageStart=false, multi=false;
    private float startX,startY,maxDistance,handleX,handleY;
    private long startTime,handleTime;
    private float handleDistance;
    private boolean handleMulti;
    private int generation=0;
    EdgeNavigation(BrowserActivity activity,FrameLayout parent,View controls){
        host=activity;viewport=parent;bar=controls;
        handle=Ui.text(host,"›",22,Color.WHITE,true);
        handle.setGravity(Gravity.CENTER);handle.setShadowLayer(dp(2),0,0,Color.BLACK);
        handle.setBackgroundColor(Color.TRANSPARENT);handle.setClickable(true);handle.setFocusable(true);
        handle.setOnClickListener(v->{if(shown)hide(true);else reveal(true);});
        handle.setOnTouchListener((v,event)->handleTouch(event));
        viewport.addView(handle,new FrameLayout.LayoutParams(dp(44),dp(48)));
        handle.setVisibility(View.GONE);
    }
    private int dp(float value){return Ui.dp(host,value);}
    boolean enabled(){return EdgeNavigationRules.enabled(mode);}
    void configure(int selected,int delay,boolean tapOutside){
        int next=EdgeNavigationRules.mode(selected);boolean changed=next!=mode;
        mode=next;seconds=EdgeNavigationRules.delay(delay);outside=tapOutside;
        FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)handle.getLayoutParams();
        p.gravity=Gravity.BOTTOM|(mode==EdgeNavigationRules.RIGHT?Gravity.RIGHT:Gravity.LEFT);
        p.leftMargin=dp(12);p.rightMargin=dp(12);p.bottomMargin=dp(DisplaySpace.DOCK_HEIGHT+6);
        handle.setLayoutParams(p);
        if(!enabled()){cancelTimer();generation++;bar.animate().cancel();bar.setTranslationX(0);bar.setAlpha(1);bar.setVisibility(View.VISIBLE);shown=true;handle.setVisibility(View.GONE);}
        else if(changed||suspended){hide(false);}else{updateHandle();schedule();}
    }
    private void updateHandle(){
        handle.setVisibility(enabled()&&!suspended?View.VISIBLE:View.GONE);
        boolean left=mode==EdgeNavigationRules.LEFT;
        handle.setText((left!=shown)?"›":"‹");
        handle.setContentDescription(shown?"Hide browser navigation":"Swipe inward or tap to show browser navigation");
        handle.bringToFront();
    }
    private float offset(){return EdgeNavigationRules.direction(mode)*Math.max(viewport.getWidth(),dp(360));}
    private void cancelTimer(){handler.removeCallbacks(timeout);}
    private void schedule(){cancelTimer();if(enabled()&&shown&&!suspended&&!tracking&&seconds>0)handler.postDelayed(timeout,seconds*1000L);}
    void reveal(boolean animate){
        if(!enabled()||suspended)return;
        generation++;bar.animate().cancel();boolean wasHidden=bar.getVisibility()!=View.VISIBLE;shown=true;
        if(wasHidden){bar.setTranslationX(offset());bar.setAlpha(.3f);}
        bar.setVisibility(View.VISIBLE);updateHandle();
        if(animate&&host.controlAnimations)bar.animate().translationX(0).alpha(1).setDuration(220).start();else{bar.setTranslationX(0);bar.setAlpha(1);}
        schedule();
    }
    void hide(boolean animate){
        cancelTimer();if(!enabled())return;
        int token=++generation;bar.animate().cancel();shown=false;updateHandle();
        if(animate&&host.controlAnimations&&!suspended&&bar.getVisibility()==View.VISIBLE){
            bar.animate().translationX(offset()).alpha(.15f).setDuration(180).withEndAction(()->{if(token==generation&&!shown){bar.setVisibility(View.GONE);bar.setTranslationX(0);bar.setAlpha(1);}}).start();
        }else{bar.setVisibility(View.GONE);bar.setTranslationX(0);bar.setAlpha(1);}
    }
    void suspend(){suspended=true;tracking=false;cancelTimer();if(enabled())hide(false);handle.setVisibility(View.GONE);}
    void resume(){suspended=false;tracking=false;if(enabled()){updateHandle();schedule();}}
    void close(){cancelTimer();generation++;bar.animate().cancel();}
    private boolean handleTouch(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:handleX=e.getRawX();handleY=e.getRawY();handleTime=e.getEventTime();handleDistance=0;handleMulti=false;handle.setPressed(true);return true;
            case MotionEvent.ACTION_POINTER_DOWN:handleMulti=true;return true;
            case MotionEvent.ACTION_MOVE:handleDistance=Math.max(handleDistance,(float)Math.hypot(e.getRawX()-handleX,e.getRawY()-handleY));return true;
            case MotionEvent.ACTION_UP:
                handle.setPressed(false);float dx=e.getRawX()-handleX,dy=e.getRawY()-handleY;
                handleDistance=Math.max(handleDistance,(float)Math.hypot(dx,dy));
                if(!handleMulti&&EdgeNavigationRules.inward(mode,dx,dy,dp(18))){reveal(true);}
                else if(!handleMulti&&shown&&EdgeNavigationRules.inward(mode,-dx,dy,dp(18))){hide(true);}
                else if(EdgeNavigationRules.tap(handleDistance,ViewConfiguration.get(host).getScaledTouchSlop(),e.getEventTime()-handleTime,handleMulti))handle.performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:handle.setPressed(false);return true;
            default:return true;
        }
    }
    private boolean contains(View view,float x,float y){
        if(view.getVisibility()!=View.VISIBLE)return false;
        int[] loc=new int[2];view.getLocationOnScreen(loc);
        return x>=loc[0]&&x<loc[0]+view.getWidth()&&y>=loc[1]&&y<loc[1]+view.getHeight();
    }
    // Observe activity events but let the page receive the original input unchanged.
    boolean observe(MotionEvent event){
        if(!enabled()||suspended)return false;
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                tracking=true;cancelTimer();startX=event.getRawX();startY=event.getRawY();startTime=event.getEventTime();maxDistance=0;multi=false;
                pageStart=shown&&contains(viewport,startX,startY)&&!contains(bar,startX,startY)&&!contains(handle,startX,startY);break;
            case MotionEvent.ACTION_POINTER_DOWN:multi=true;break;
            case MotionEvent.ACTION_MOVE:if(tracking)maxDistance=Math.max(maxDistance,(float)Math.hypot(event.getRawX()-startX,event.getRawY()-startY));break;
            case MotionEvent.ACTION_UP:
                maxDistance=Math.max(maxDistance,(float)Math.hypot(event.getRawX()-startX,event.getRawY()-startY));
                boolean dismiss=tracking&&shown&&outside&&pageStart&&EdgeNavigationRules.tap(maxDistance,ViewConfiguration.get(host).getScaledTouchSlop(),event.getEventTime()-startTime,multi);
                tracking=false;schedule();return dismiss;
            case MotionEvent.ACTION_CANCEL:tracking=false;schedule();break;
            default:break;
        }
        return false;
    }
}
