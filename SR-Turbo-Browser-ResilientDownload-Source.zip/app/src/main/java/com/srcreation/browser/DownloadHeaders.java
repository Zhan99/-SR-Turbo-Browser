package com.srcreation.browser;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.*;

/** Header handling independent of the Android UI. No credentials are added to another origin. */
final class DownloadHeaders {
    private static final Pattern PARAM=Pattern.compile("(?:^|;)\\s*(filename\\*?)\\s*=\\s*(?:\"((?:\\\\.|[^\"\\\\])*)\"|([^;]*))",Pattern.CASE_INSENSITIVE);
    static String origin(String value){
        try{URI u=URI.create(value);if(u.getHost()==null||u.getUserInfo()!=null||!web(u.getScheme()))return "";return u.getScheme()+"://"+u.getRawAuthority()+"/";}catch(Exception e){return "";}
    }
    static boolean web(String s){return "http".equalsIgnoreCase(s)||"https".equalsIgnoreCase(s);}
    static String referrer(String page,URL target){
        try{URI u=URI.create(page);String base=origin(page);if(base.isEmpty()||!web(target.getProtocol())||("https".equalsIgnoreCase(u.getScheme())&&"http".equalsIgnoreCase(target.getProtocol())))return "";
            if(!DownloadEngine.sameOrigin(u.toURL(),target))return base;
            String path=u.getRawPath();String q=u.getRawQuery();return base.substring(0,base.length()-1)+(path==null||path.isEmpty()?"/":path)+(q==null?"":"?"+q);
        }catch(Exception e){return "";}
    }
    static String filename(String disposition,String fallback){
        if(disposition==null)return fallback;String plain=null,extended=null;Matcher m=PARAM.matcher(disposition);
        while(m.find()){String key=m.group(1).toLowerCase(Locale.ROOT),v=m.group(2)!=null?m.group(2).replaceAll("\\\\(.)","$1"):m.group(3).trim();
            if(key.equals("filename*")){try{String[] chunks=v.split("'",3);if(chunks.length==3){String charset=chunks[0];if(charset.equalsIgnoreCase("UTF-8")||charset.equalsIgnoreCase("ISO-8859-1"))extended=URLDecoder.decode(chunks[2].replace("+","%2B"),charset);}}catch(Exception ignored){}}
            else plain=v;
        }
        String result=extended!=null&&!extended.isEmpty()?extended:plain;if(result==null||result.trim().isEmpty())return fallback;
        result=result.replace('\\','/');result=result.substring(result.lastIndexOf('/')+1).replaceAll("[\\p{Cntrl}]","_").trim();return result.isEmpty()||result.equals(".")||result.equals("..")?fallback:result;
    }
}
