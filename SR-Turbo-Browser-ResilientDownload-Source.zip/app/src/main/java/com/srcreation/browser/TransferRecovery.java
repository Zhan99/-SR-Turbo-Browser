package com.srcreation.browser;
import java.io.*;
import java.net.*;
/** No retry of authorization, storage, HTTP throttling or explicit user cancellation. */
final class TransferRecovery {
    static String restore(String state,String stop){
        if("Paused".equals(state)||"Cancelled".equals(state)||"Completed".equals(state)||"Failed".equals(state))return state;
        if("Paused".equals(stop)||"Cancelled".equals(stop))return stop;
        if("Running".equals(state)||"Saving".equals(state)||"Stopping".equals(state)||"Queued".equals(state))return "Queued";
        return state;
    }
    static boolean retryable(IOException e){
        if(e instanceof DownloadEngine.Stop||e instanceof DownloadEngine.ServerBusy)return false;
        return DownloadEngine.retryable(e);
    }
    static long delay(int attempt){return Math.min(60000L, 3000L << Math.max(0,Math.min(5,attempt-1)));}
}
