package com.srcreation.browser;
import java.io.*;import java.nio.file.*;import java.util.*;
public class CompletedTransferTest {
 public static void main(String[] args)throws Exception{
 File dir=Files.createTempDirectory("sr-complete").toFile();byte[] data=new byte[400001];new Random(9).nextBytes(data);
 DownloadEngine.Listener l=new DownloadEngine.Listener(){public void metadata(DownloadEngine.Meta m){}public void progress(long b,long t){}};
 DownloadEngine e=new DownloadEngine("invalid:must-not-contact-network","","",dir,1,new DownloadEngine.Control(),l);
 try{Files.write(e.part(0).toPath(),data);e.markComplete(new DownloadEngine.Meta(data.length,"",1,false));
 DownloadEngine.Meta m=e.run(new DownloadEngine.Meta());ByteArrayOutputStream o=new ByteArrayOutputStream();e.assemble(m,o);if(!Arrays.equals(data,o.toByteArray()))throw new AssertionError("bytes changed");
 try(RandomAccessFile f=new RandomAccessFile(e.part(0),"rw")){f.setLength(data.length-1);}if(e.completed()!=null)throw new AssertionError("accepted truncated file");
 System.out.println("PASS completed transfer reuse without network; rejects truncated staged file");}finally{e.clear();dir.delete();}
 }
}
