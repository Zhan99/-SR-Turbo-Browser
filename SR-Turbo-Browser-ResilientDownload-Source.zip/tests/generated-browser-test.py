"""Real Chromium DOM/Blob regression, with a simulated Android message bridge.
Run locally: python tests/generated-browser-test.py (requires Playwright + Chromium).
"""
import base64, json, threading, pathlib, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
JS=(ROOT/'app/src/main/assets/sr-generated-download.js').read_text()
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body=b'<!doctype html><html><body>Generated file test</body></html>'
        self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(body)
    def log_message(self,*a): pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
registry={};events=[]
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=shutil.which('chromium') or None,headless=True,args=['--no-sandbox'])
        page=browser.new_page()
        def receive(source,raw):
            frame=source['frame'];m=json.loads(raw)
            if m['op']=='register': registry[m['url']]=frame
            elif m['op']=='forget': registry.pop(m['url'],None)
            else: events.append((frame,m))
        page.expose_binding('__nativeReceive',receive)
        page.add_init_script('window.SrGeneratedFiles={postMessage:s=>{window.__nativeReceive(s);}};\n'+JS)
        page.goto(f'http://127.0.0.1:{server.server_port}/')
        def wait_event(op):
            for _ in range(200):
                for i,(fr,m) in enumerate(events):
                    if m['op']==op:return events.pop(i)
                page.wait_for_timeout(25)
            raise AssertionError('Missing event: '+op+' '+str(events))
        def deliver(fr,msg):fr.evaluate('(msg)=>window.SrGeneratedFiles.onmessage({data:JSON.stringify(msg)})',msg)
        def read(fr,b):
            content=bytearray()
            while len(content)<b['size']:
                deliver(fr,{'op':'next','id':b['id'],'offset':len(content)})
                owner,m=wait_event('chunk');assert owner==fr and m['id']==b['id'] and m['offset']==len(content)
                content+=base64.b64decode(m['data'])
            deliver(fr,{'op':'end','id':b['id']});return bytes(content)
        def create(fr,mime):return fr.evaluate('''mime=>{let b=new Uint8Array(150123);for(let i=0;i<b.length;i++)b[i]=i%251;const u=URL.createObjectURL(new Blob([b],{type:mime}));URL.revokeObjectURL(u);return u;}''',mime)
        expected=bytes(i%251 for i in range(150123))
        for host in ('127.0.0.1','localhost'):
            page.evaluate('''url=>{document.querySelector('iframe')?.remove();const f=document.createElement('iframe');f.src=url;document.body.append(f);}''',f'http://{host}:{server.server_port}/')
            page.wait_for_timeout(250);sub=page.frames[-1];sub.wait_for_load_state()
            url=create(sub,'application/pdf')
            page.evaluate('''u=>{const a=document.createElement('a');a.href=u;a.download='gemini.pdf';a.click();}''',url)
            requester,q=wait_event('resolve');assert requester==page.main_frame and registry[q['url']]==sub
            deliver(sub,{'op':'capture','url':q['url'],'id':q['id'],'name':q['name']})
            owner,b=wait_event('begin');assert owner==sub and b['name']=='gemini.pdf' and b['mime']=='application/pdf'
            assert read(owner,b)==expected
            print('PASS real Chromium '+('same-origin' if host=='127.0.0.1' else 'cross-origin')+' iframe, detached anchor, revoked PDF, byte exact')
        url=create(page.main_frame,'application/zip');deliver(page.main_frame,{'op':'capture','url':url,'id':'native-zip','name':'source.zip'});owner,b=wait_event('begin');assert read(owner,b)==expected
        print('PASS real Chromium native callback simulation, revoked ZIP, byte exact')
        browser.close()
finally:server.shutdown()
