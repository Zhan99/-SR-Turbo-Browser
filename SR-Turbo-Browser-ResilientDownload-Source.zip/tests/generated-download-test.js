const assert=require('assert/strict'),fs=require('fs'),vm=require('vm');
const script=fs.readFileSync(process.argv[2],'utf8');
let seq=0;const messages=[],creators=new Map();
function frame(label,protocol='https:'){
 const timers=[],nativeBlobs=new Map();let callback,nativeClicks=0;
 class Anchor{constructor(h,n){this.href=h;this.name=n;}hasAttribute(k){return k==='download'&&this.name!==null;}getAttribute(){return this.name;}click(){nativeClicks++;}}
 const U={createObjectURL(b){const u='blob:https://'+label+'.test/'+ ++seq;nativeBlobs.set(u,b);return u;},revokeObjectURL(u){nativeBlobs.delete(u);}};
 const bridge={postMessage(s){const m=JSON.parse(s);if(m.op==='register')creators.set(m.url,bridge);else if(m.op==='forget')creators.delete(m.url);else messages.push(m);}};
 const ctx={Blob,Uint8Array,btoa,URL:U,HTMLAnchorElement:Anchor,location:{protocol},crypto:require('crypto').webcrypto,document:{addEventListener(_,f){callback=f;}},SrGeneratedFiles:bridge,fetch:async u=>{if(!nativeBlobs.has(u))throw Error('revoked or wrong frame');const held=nativeBlobs.get(u);return{ok:true,blob:async()=>held};},setTimeout:(f,ms)=>timers.push({f,ms})};ctx.window=ctx;vm.runInNewContext(script,ctx);
 return {ctx,bridge,U,Anchor,timers,nativeBlobs,click:a=>{let prevented=false;callback({defaultPrevented:false,button:0,composedPath:()=>[a],preventDefault(){prevented=true;}});return prevented;},count:()=>nativeClicks};
}
const flush=()=>new Promise(r=>setImmediate(r));
const send=(bridge,obj)=>bridge.onmessage({data:JSON.stringify(obj)});
async function get(bridge,b){let offset=0,arr=[];while(offset<b.size){await send(bridge,{op:'next',id:b.id,offset});const c=messages.shift();assert.equal(c.op,'chunk');assert.equal(c.offset,offset);const bytes=Buffer.from(c.data,'base64');arr.push(bytes);offset+=bytes.length;}await send(bridge,{op:'end',id:b.id});return Buffer.concat(arr);}
(async()=>{
 const main=frame('main'),sub=frame('canvas','about:');const data=Buffer.alloc(150123);for(let i=0;i<data.length;i++)data[i]=i%251;
 let u=main.U.createObjectURL(new Blob([data],{type:'application/pdf'}));new main.Anchor(u,'test.pdf').click();main.U.revokeObjectURL(u);await flush();assert.equal(main.nativeBlobs.has(u),false);let b=messages.shift();assert.equal(b.op,'begin');assert.equal(b.name,'test.pdf');assert.deepEqual(await get(main.bridge,b),data);assert.equal(main.timers[0].ms,120000);main.timers.shift().f();assert.equal(creators.has(u),false);
 // Cross-frame export, including an inherited-origin about:blank iframe. Native route model.
 u=sub.U.createObjectURL(new Blob([data],{type:'application/pdf'}));sub.U.revokeObjectURL(u);new main.Anchor(u,'gemini.pdf').click();let q=messages.shift();assert.equal(q.op,'resolve');assert.equal(creators.get(q.url),sub.bridge);await send(creators.get(q.url),{op:'capture',id:q.id,url:q.url,name:q.name});await flush();b=messages.shift();assert.equal(b.id,q.id);assert.equal(b.name,'gemini.pdf');assert.deepEqual(await get(sub.bridge,b),data);
 // Native DownloadListener route: no download attribute / programmatic browser callback.
 u=sub.U.createObjectURL(new Blob([data],{type:'application/zip'}));sub.U.revokeObjectURL(u);await send(creators.get(u),{op:'capture',id:'native-request',url:u,name:'source.zip'});await flush();b=messages.shift();assert.equal(b.id,'native-request');assert.deepEqual(await get(sub.bridge,b),data);
 u=main.U.createObjectURL(new Blob([data],{type:'application/zip'}));assert.ok(main.click(new main.Anchor(u,'click.zip')));await flush();b=messages.shift();assert.deepEqual(await get(main.bridge,b),data);
 new main.Anchor('https://site.test/file.zip','file.zip').click();new main.Anchor('blob:https://site.test/plain',null).click();assert.equal(main.count(),2);
 // Simulate a Blob created outside the injected document (e.g. a worker).
 u='blob:https://main.test/worker';main.nativeBlobs.set(u,new Blob([data],{type:'application/pdf'}));
 new main.Anchor(u,'worker.pdf').click();q=messages.shift();main.nativeBlobs.delete(u);
 await send(main.bridge,{op:'capture',id:q.id,url:q.url,name:q.name});await flush();b=messages.shift();assert.equal(b.op,'begin');assert.deepEqual(await get(main.bridge,b),data);
 new main.Anchor('blob:https://site.test/missing','missing.pdf').click();q=messages.shift();assert.equal(q.op,'resolve');await send(main.bridge,{op:'capture',id:q.id,url:q.url,name:q.name});await flush();assert.equal(messages.shift().op,'notice');assert.equal(messages.length,0);
 console.log('Generated files: immediate revoke, creator-frame routing model, inherited-frame hook, native capture, multi-chunk PDF/ZIP byte integrity, early worker URL fetch, normal HTTP pass-through, missing file passed');
})().catch(e=>{console.error(e);process.exitCode=1;});
