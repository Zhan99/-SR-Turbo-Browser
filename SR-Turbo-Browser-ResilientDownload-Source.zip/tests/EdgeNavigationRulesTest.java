package com.srcreation.browser;
public class EdgeNavigationRulesTest {
    static int count;
    static void check(boolean ok){count++;if(!ok)throw new AssertionError("edge navigation rule "+count);}
    public static void main(String[] args){
        check(EdgeNavigationRules.mode(-1)==0);check(EdgeNavigationRules.mode(9)==0);
        check(!EdgeNavigationRules.enabled(0));check(EdgeNavigationRules.enabled(1));check(EdgeNavigationRules.enabled(2));
        check(EdgeNavigationRules.inward(1,30,2,18));check(!EdgeNavigationRules.inward(1,-30,2,18));
        check(EdgeNavigationRules.inward(2,-30,2,18));check(!EdgeNavigationRules.inward(2,30,2,18));
        check(!EdgeNavigationRules.inward(1,30,30,18));check(!EdgeNavigationRules.inward(1,17,0,18));check(!EdgeNavigationRules.inward(0,40,0,18));
        check(EdgeNavigationRules.tap(3,8,200,false));check(!EdgeNavigationRules.tap(9,8,200,false));check(!EdgeNavigationRules.tap(2,8,500,false));check(!EdgeNavigationRules.tap(2,8,200,true));
        check(EdgeNavigationRules.delay(0)==0);check(EdgeNavigationRules.delay(3)==3);check(EdgeNavigationRules.delay(5)==5);check(EdgeNavigationRules.delay(10)==10);check(EdgeNavigationRules.delay(1)==3);
        check(EdgeNavigationRules.contentMargin(false,0)==DisplaySpace.DOCK_HEIGHT);check(EdgeNavigationRules.contentMargin(true,0)==0);check(EdgeNavigationRules.contentMargin(false,1)==0);check(EdgeNavigationRules.contentMargin(false,2)==0);
        System.out.println("Edge navigation rules passed: "+count+" checks");
    }
}
