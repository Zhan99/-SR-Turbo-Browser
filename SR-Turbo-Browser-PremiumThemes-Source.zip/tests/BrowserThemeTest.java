package com.srcreation.browser;
import java.util.*;
public class BrowserThemeTest {
 static void check(boolean pass){if(!pass)throw new AssertionError();}
 static double lum(int c){double sum=0;double[] weights={.2126,.7152,.0722};for(int i=0;i<3;i++){double x=((c>>(16-8*i))&255)/255.0;sum+=weights[i]*(x<=.04045?x/12.92:Math.pow((x+.055)/1.055,2.4));}return sum;}
 static double contrast(int a,int b){double x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
 public static void main(String[] args){check(BrowserTheme.restore(null,false)==BrowserTheme.CLASSIC_LIGHT);check(BrowserTheme.restore(null,true)==BrowserTheme.CLASSIC_DARK);check(BrowserTheme.restore("bad",true)==BrowserTheme.CLASSIC_DARK);Set<String> scenes=new HashSet<>();for(BrowserTheme t:BrowserTheme.values()){check(BrowserTheme.restore(t.name(),!t.dark)==t);check(!t.wallpaper(false));check(t.wallpaper(true)==(t.scene!=null));if(t.scene!=null)check(scenes.add(t.scene));check(contrast(t.fg,t.card)>=4.5);check(contrast(t.muted,t.paper)>=4.5);check(contrast(t.accent,t.card)>=4.5);check(contrast(t.highlight,t.nav)>=4.5);check(contrast(0xffffffff,t.toolbar)>=4.5);}check(scenes.size()==6);System.out.println("Theme persistence, scenery flags and palette contrast passed (8 themes, 6 scenes)");}
}
