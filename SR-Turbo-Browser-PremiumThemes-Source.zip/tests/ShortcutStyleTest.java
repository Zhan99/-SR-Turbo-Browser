package com.srcreation.browser;

final class ShortcutStyleTest {
    static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
    public static void main(String[] args){
        check(ShortcutStyle.brand("https://www.google.com/search?q=x")==ShortcutStyle.Brand.GOOGLE,"Google");
        check(ShortcutStyle.brand("https://mail.google.com/mail/u/0/")==ShortcutStyle.Brand.GMAIL,"Gmail priority");
        check(ShortcutStyle.brand("https://m.youtube.com/watch?v=123")==ShortcutStyle.Brand.YOUTUBE,"YouTube mobile");
        check(ShortcutStyle.brand("https://youtu.be/123")==ShortcutStyle.Brand.YOUTUBE,"YouTube short link");
        check(ShortcutStyle.brand("https://m.facebook.com/")==ShortcutStyle.Brand.FACEBOOK,"Facebook");
        check(ShortcutStyle.brand("https://github.com/")==ShortcutStyle.Brand.GITHUB,"GitHub");
        check(ShortcutStyle.brand("https://bn.wikipedia.org/")==ShortcutStyle.Brand.WIKIPEDIA,"Wikipedia");
        check(ShortcutStyle.brand("https://youtube.com.example.org/")==ShortcutStyle.Brand.OTHER,"lookalike not branded");
        check(ShortcutStyle.brand("https://youtube.com@evil.org/")==ShortcutStyle.Brand.OTHER,"userinfo not branded");
        check(ShortcutStyle.brand("file://google.com/")==ShortcutStyle.Brand.OTHER,"not web link");
        check(ShortcutStyle.initial(" বাংলা ","").equals("ব"),"Bangla initial");
        check(ShortcutStyle.initial("", "https://example.com").equals("E"),"host fallback");
        check(ShortcutStyle.initial("😀", "").equals("😀"),"Unicode codepoint");
        check(ShortcutStyle.palette("https://example.com/a")==ShortcutStyle.palette("https://example.com/b"),"stable palette");
        check(ShortcutStyle.columns(280)==2 && ShortcutStyle.columns(360)==3 && ShortcutStyle.columns(600)==4 && ShortcutStyle.columns(800)==5,"responsive columns");
        System.out.println("ShortcutStyle: 15 checks passed");
    }
}
