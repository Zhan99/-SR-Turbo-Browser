package com.srcreation.browser;

/** Stable preference keys; scenic themes use local, original wallpaper artwork. */
enum BrowserTheme {
    CLASSIC_LIGHT("Classic Light", "Clean white · teal accents", null, false, 0xff101c30,0xff24364c,0xfff1f5f9,0xffffffff,0xff132238,0xff506477,0xff08776d,0xff57e4d4,0xffdce6ef,0xffd9f5ed),
    CLASSIC_DARK("Classic Dark", "Midnight blue · mint accents", null, true, 0xff101c30,0xff24364c,0xff152439,0xff24364c,0xffe7eff8,0xffafc2d7,0xff57e4d4,0xff57e4d4,0xff38506a,0xff164744),
    ALPINE("Alpine Dawn", "Snowy mountains · alpine lake", "alpine", true, 0xff17283f,0xff2a4059,0xff23364b,0xff263b52,0xfff2f7ff,0xffc1d6e9,0xff9ee7ff,0xff9ee7ff,0xff456078,0xff314e64),
    FOREST("Emerald Forest", "Misty evergreen woodland", "forest", true, 0xff102d28,0xff21483c,0xff193a32,0xff254c3f,0xffeffff7,0xffb9d8ca,0xffa6efba,0xffa6efba,0xff416858,0xff315b47),
    OCEAN("Ocean Escape", "Turquoise sea · tropical coast", "ocean", true, 0xff10334c,0xff204c63,0xff193e53,0xff244d62,0xffeffaff,0xffb6dbe9,0xff80eee7,0xff80eee7,0xff416c80,0xff2c606e),
    SUNSET("Golden Sunset", "Warm horizon · desert dunes", "sunset", true, 0xff382436,0xff573a48,0xff462d3d,0xff593b49,0xfffff3ea,0xffe4c7c9,0xffffc58b,0xffffc58b,0xff785762,0xff704a4d),
    AURORA("Aurora Night", "Northern lights · starry sky", "aurora", true, 0xff151b3e,0xff2a3159,0xff20254b,0xff30375e,0xfff1efff,0xffc7c9ea,0xffa5f4d8,0xffa5f4d8,0xff4e5880,0xff3b4c6d),
    BLOSSOM("Sakura Dream", "Pink blossoms · tranquil hills", "blossom", false, 0xff442c49,0xff62435e,0xfffff0f5,0xfffff9fc,0xff432c45,0xff795970,0xff914467,0xffffc7de,0xffe9cbdc,0xfff6dce9);
    final String title,description,scene; final boolean dark;
    final int nav,toolbar,paper,card,fg,muted,accent,highlight,line,active;
    BrowserTheme(String title,String description,String scene,boolean dark,int nav,int toolbar,int paper,int card,int fg,int muted,int accent,int highlight,int line,int active){this.title=title;this.description=description;this.scene=scene;this.dark=dark;this.nav=nav;this.toolbar=toolbar;this.paper=paper;this.card=card;this.fg=fg;this.muted=muted;this.accent=accent;this.highlight=highlight;this.line=line;this.active=active;}
    static BrowserTheme restore(String key,boolean oldDark){if(key!=null)try{return valueOf(key);}catch(IllegalArgumentException ignored){}return oldDark?CLASSIC_DARK:CLASSIC_LIGHT;}
    boolean wallpaper(boolean enabled){return enabled&&scene!=null;}
}
