package com.srcreation.browser;

import java.net.URI;
import java.util.Locale;

/** Offline shortcut identity. Match actual host, not the editable display name. */
final class ShortcutStyle {
    enum Brand { GOOGLE, YOUTUBE, FACEBOOK, GITHUB, GMAIL, WIKIPEDIA, OTHER }
    static Brand brand(String url) {
        String host=host(url);
        if (host.equals("mail.google.com")) return Brand.GMAIL;
        if (domain(host,"google.com")) return Brand.GOOGLE;
        if (domain(host,"youtube.com") || host.equals("youtu.be")) return Brand.YOUTUBE;
        if (domain(host,"facebook.com") || host.equals("fb.com")) return Brand.FACEBOOK;
        if (domain(host,"github.com")) return Brand.GITHUB;
        if (domain(host,"wikipedia.org")) return Brand.WIKIPEDIA;
        return Brand.OTHER;
    }
    static String host(String url) {
        try { URI u=new URI(url); String s=u.getScheme(); if (!"https".equalsIgnoreCase(s)&&!"http".equalsIgnoreCase(s)) return "";
            if(u.getRawUserInfo()!=null) return "";
            String h=u.getHost(); return h==null?"":h.toLowerCase(Locale.ROOT); }
        catch(Exception e){return "";}
    }
    static boolean domain(String host,String base){return host.equals(base)||host.endsWith("."+base);}
    static String initial(String title,String url){
        String s=title==null?"":title.trim();
        if(s.isEmpty())s=host(url);
        if(s.isEmpty())return "?";
        return new String(Character.toChars(s.codePointAt(0))).toUpperCase(Locale.ROOT);
    }
    static int palette(String url){return Math.floorMod(host(url).hashCode(),6);}
    static int columns(int widthDp){return widthDp>=720?5:widthDp>=520?4:widthDp<300?2:3;}
}
