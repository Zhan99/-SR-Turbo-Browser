package com.srcreation.browser;
public class DesktopModeTest {
    static void check(boolean condition,String detail){if(!condition)throw new AssertionError(detail);}
    public static void main(String[] args){
        String mobile="Mozilla/5.0 (Linux; Android 15; Pixel 9 Build/XYZ; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/145.0.7312.28 Mobile Safari/537.36";
        String desktop=DesktopMode.agent(mobile,true);
        check(desktop.contains("X11; Linux x86_64; wv"),"desktop platform with WebView marker");
        check(desktop.contains("Chrome/145.0.7312.28")&&!desktop.contains("Mobile")&&!desktop.contains("Android"),"real version; no mobile token");
        check(DesktopMode.agent(mobile,false).equals(mobile),"restore mobile identity");
        check(DesktopMode.agent("unknown",true).equals("unknown"),"unknown agent fallback");
        check(DesktopMode.effective(true,"https://example.com"),"ordinary URL");
        check(DesktopMode.effective(true,"about:blank"),"new tab inherits global mode");
        check(DesktopMode.effective(true,"https://www.google.com/search?q=hello"),"Google search desktop");
        check(!DesktopMode.effective(false,"https://example.com"),"global off");
        for(String url:new String[]{GoogleLinks.CHOOSE,GoogleLinks.GMAIL,GoogleLinks.MANAGE,GoogleLinks.ADD}){
            check(!DesktopMode.effective(true,url),"account identity exception");
            check(DesktopMode.label(true,false,url).contains("ACCOUNT EXCEPTION"),"exception visible");
        }
        check(DesktopMode.effective(true,"https://accounts.google.com.example.com/"),"exact account hostname only");
        check(DesktopMode.label(true,false,"https://example.com").contains("NEXT LOAD"),"pending desktop status");
        check(DesktopMode.label(false,true,"https://example.com").contains("NEXT LOAD"),"pending mobile status");
        check(DesktopMode.label(true,true,"https://example.com").equals("DESKTOP"),"active status");
        check(DesktopMode.label(false,false,"https://example.com").isEmpty(),"disabled status");
        check(DesktopMode.WIDE_VIEWPORT.contains("width=1280"),"wide viewport script");
        String page="https://example.com";
        for(boolean desktopEnabled:new boolean[]{false,true})for(boolean zoomEnabled:new boolean[]{false,true})for(boolean applied:new boolean[]{false,true}){
            check(DesktopMode.zoomControlsVisible(desktopEnabled,zoomEnabled,applied,page)==(desktopEnabled&&zoomEnabled&&applied),"zoom visibility combinations");
        }
        check(!DesktopMode.zoomControlsVisible(true,true,true,GoogleLinks.GMAIL),"no desktop controls on account exception");
        System.out.println("DesktopModeTest: all checks passed");
    }
}
