#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
javac --add-modules jdk.httpserver -d "$tmp" app/src/main/java/com/srcreation/browser/DownloadEngine.java app/src/main/java/com/srcreation/browser/TransferEta.java tests/EngineTest.java tests/TransferEtaTest.java app/src/main/java/com/srcreation/browser/PrivacyRules.java tests/PrivacyRulesTest.java
java --add-modules jdk.httpserver -cp "$tmp" com.srcreation.browser.EngineTest
java -cp "$tmp" com.srcreation.browser.TransferEtaTest

java -cp "$tmp" com.srcreation.browser.PrivacyRulesTest
javac -d "$tmp" app/src/main/java/com/srcreation/browser/GoogleLinks.java tests/GoogleLinksTest.java
java -cp "$tmp" com.srcreation.browser.GoogleLinksTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/DesktopMode.java tests/DesktopModeTest.java
java -cp "$tmp" com.srcreation.browser.DesktopModeTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/VideoLinks.java tests/VideoLinksTest.java
java -cp "$tmp" com.srcreation.browser.VideoLinksTest
if command -v node >/dev/null; then
    java -cp "$tmp" com.srcreation.browser.VideoLinksTest scan | tail -n +2 > "$tmp/video-scan.js"
    node tests/video-scan-test.js "$tmp/video-scan.js"
fi
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/YouTubeLinks.java tests/YouTubeLinksTest.java
java -cp "$tmp" com.srcreation.browser.YouTubeLinksTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/VideoEnginePolicy.java tests/VideoEnginePolicyTest.java
java -cp "$tmp" com.srcreation.browser.VideoEnginePolicyTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/EngineSeed.java tests/EngineSeedTest.java
java -cp "$tmp" com.srcreation.browser.EngineSeedTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/YouTubeBulk.java tests/YouTubeBulkTest.java
java -cp "$tmp" com.srcreation.browser.YouTubeBulkTest
if command -v node >/dev/null; then
    java -cp "$tmp" com.srcreation.browser.YouTubeBulkTest scan > "$tmp/youtube-bulk.js"
    node tests/youtube-bulk-scan-test.js "$tmp/youtube-bulk.js"
fi
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/HistoryTitles.java tests/HistoryTitlesTest.java
java -cp "$tmp" com.srcreation.browser.HistoryTitlesTest
# Parsing alone does not catch illegal redeclarations in nested method blocks.
javac -d "$tmp" tests/LocalScopeCheck.java
java -cp "$tmp" LocalScopeCheck app/src/main/java
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/UploadSelection.java tests/UploadSelectionTest.java
java -cp "$tmp" com.srcreation.browser.UploadSelectionTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/FacebookMobile.java tests/FacebookMobileTest.java
java -cp "$tmp" com.srcreation.browser.FacebookMobileTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/SiteVideoLinks.java tests/SiteVideoLinksTest.java
java -cp "$tmp" com.srcreation.browser.SiteVideoLinksTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/ShortcutStyle.java tests/ShortcutStyleTest.java
java -cp "$tmp" com.srcreation.browser.ShortcutStyleTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/SessionRules.java tests/SessionRulesTest.java
java -cp "$tmp" com.srcreation.browser.SessionRulesTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/BrowserTheme.java tests/BrowserThemeTest.java
java -cp "$tmp" com.srcreation.browser.BrowserThemeTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/AdRules.java tests/AdRulesTest.java
java -cp "$tmp" com.srcreation.browser.AdRulesTest
if command -v node >/dev/null; then
    java -cp "$tmp" com.srcreation.browser.AdRulesTest script | tail -n +2 > "$tmp/ad-scripts.js"
    node tests/ad-dom-test.js "$tmp/ad-scripts.js"
fi

javac -encoding UTF-8 -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/UltraVideoAds.java tests/UltraVideoAdsTest.java
if command -v node >/dev/null; then
    java -cp "$tmp" com.srcreation.browser.UltraVideoAdsTest > "$tmp/ultra-ads.js"
    node tests/ultra-ad-test.js "$tmp/ultra-ads.js"
fi

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/TransferRecovery.java tests/TransferRecoveryTest.java
java -cp "$tmp" com.srcreation.browser.TransferRecoveryTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/DownloadBadge.java tests/DownloadBadgeTest.java
java -cp "$tmp" com.srcreation.browser.DownloadBadgeTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/VideoSpeedPolicy.java tests/VideoSpeedPolicyTest.java
java -cp "$tmp" com.srcreation.browser.VideoSpeedPolicyTest

javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/MediaChoice.java tests/MediaChoiceTest.java app/src/main/java/com/srcreation/browser/FileDownloadLinks.java tests/FileDownloadLinksTest.java
java -cp "$tmp" com.srcreation.browser.MediaChoiceTest
java -cp "$tmp" com.srcreation.browser.FileDownloadLinksTest
