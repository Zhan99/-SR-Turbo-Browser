package com.srcreation.browser;

import java.net.URI;
import java.util.Locale;
import java.util.regex.*;

/** Resolve file views without guessing the boundary of branch names containing slashes. */
final class FileDownloadLinks {
    private static final Pattern BLOB=Pattern.compile("^/([^/]+)/([^/]+)/blob/(.+/.+)$");
    private static final Pattern RAW=Pattern.compile("^/([^/]+)/([^/]+)/raw/(.+/.+)$");
    static String normalize(String raw){
        if(raw==null)return null;
        try{
            URI u=new URI(raw.trim());String scheme=u.getScheme();
            if(scheme==null||u.getHost()==null||u.getRawUserInfo()!=null||(!scheme.equalsIgnoreCase("https")&&!scheme.equalsIgnoreCase("http")))return null;
            if(u.getHost().equalsIgnoreCase("github.com")&&(u.getPort()==-1||u.getPort()==443)){
                Matcher m=BLOB.matcher(u.getRawPath());
                if(m.matches())return "https://github.com/"+m.group(1)+"/"+m.group(2)+"/raw/"+m.group(3);
            }
            String value=u.toASCIIString();int hash=value.indexOf('#');return hash<0?value:value.substring(0,hash);
        }catch(Exception e){return null;}
    }
    static boolean githubRaw(String raw){try{URI u=new URI(raw);return "https".equalsIgnoreCase(u.getScheme())&&u.getRawUserInfo()==null&&u.getHost()!=null&&((u.getHost().equalsIgnoreCase("github.com")&&RAW.matcher(u.getRawPath()).matches())||u.getHost().equalsIgnoreCase("raw.githubusercontent.com"));}catch(Exception e){return false;}}
    static boolean attachment(String value){return value!=null&&value.trim().toLowerCase(Locale.ROOT).startsWith("attachment");}
    static boolean html(String mime){return mime!=null&&mime.split(";",2)[0].trim().equalsIgnoreCase("text/html");}
    static boolean htmlName(String name){return name!=null&&name.toLowerCase(Locale.ROOT).matches(".*\\.(html?|xhtml)$");}
    static boolean isInlineData(String url){return url!=null&&(url.startsWith("blob:")||url.startsWith("data:"));}
}
