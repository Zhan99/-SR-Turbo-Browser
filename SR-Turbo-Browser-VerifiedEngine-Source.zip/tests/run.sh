#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
javac --add-modules jdk.httpserver -d "$tmp" app/src/main/java/com/srcreation/browser/DownloadEngine.java app/src/main/java/com/srcreation/browser/TransferEta.java tests/EngineTest.java tests/TransferEtaTest.java app/src/main/java/com/srcreation/browser/PrivacyRules.java tests/PrivacyRulesTest.java
java --add-modules jdk.httpserver -cp "$tmp" com.srcreation.browser.EngineTest
java -cp "$tmp" com.srcreation.browser.TransferEtaTest

java -cp "$tmp" com.srcreation.browser.PrivacyRulesTest
javac -d "$tmp" app/src/main/java/com/srcreation/browser/GoogleLinks.java tests/GoogleLinksTest.java
java -cp "$tmp" com.srcreation.browser.GoogleLinksTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/DesktopMode.java tests/DesktopModeTest.java
java -cp "$tmp" com.srcreation.browser.DesktopModeTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/VideoLinks.java tests/VideoLinksTest.java
java -cp "$tmp" com.srcreation.browser.VideoLinksTest
if command -v node >/dev/null; then
    java -cp "$tmp" com.srcreation.browser.VideoLinksTest scan | tail -n +2 > "$tmp/video-scan.js"
    node tests/video-scan-test.js "$tmp/video-scan.js"
fi
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/YouTubeLinks.java tests/YouTubeLinksTest.java
java -cp "$tmp" com.srcreation.browser.YouTubeLinksTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/VideoEnginePolicy.java tests/VideoEnginePolicyTest.java
java -cp "$tmp" com.srcreation.browser.VideoEnginePolicyTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/com/srcreation/browser/EngineSeed.java tests/EngineSeedTest.java
java -cp "$tmp" com.srcreation.browser.EngineSeedTest
