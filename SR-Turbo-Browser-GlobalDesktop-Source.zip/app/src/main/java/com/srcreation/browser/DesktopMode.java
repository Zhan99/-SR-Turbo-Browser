package com.srcreation.browser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Desktop display policy; the underlying renderer is still Android WebView. */
final class DesktopMode {
    private static final Pattern CHROME = Pattern.compile("\\bChrome/([0-9]+(?:\\.[0-9]+){0,3})\\b");
    static boolean effective(boolean enabled, String url) {
        return enabled && !GoogleLinks.isAccountSite(url);
    }
    static String agent(String actual, boolean desktop) {
        if (!desktop || actual == null) return actual;
        Matcher m = CHROME.matcher(actual);
        if (!m.find()) return actual;
        // Keep the real Chromium version and explicit WebView marker, not a fabricated newer version.
        return "Mozilla/5.0 (X11; Linux x86_64; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + m.group(1) + " Safari/537.36";
    }
    static String label(boolean enabled, boolean applied, String url) {
        if (enabled && GoogleLinks.isAccountSite(url)) return "DESKTOP • ACCOUNT EXCEPTION";
        if (enabled != applied) return enabled ? "DESKTOP • NEXT LOAD" : "MOBILE • NEXT LOAD";
        return applied ? "DESKTOP" : "";
    }
    // Only modify the document's presentation, not scripts, credentials, or storage.
    static final String WIDE_VIEWPORT = "(function(){if(!document.head)return;var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}m.setAttribute('content','width=1280');})();";
    private DesktopMode() {}
}
