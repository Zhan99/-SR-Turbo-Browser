package com.srcreation.browser;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.ffmpeg.FFmpeg;
import kotlin.Unit;
import java.io.*;
import java.util.*;
import java.time.LocalDate;

/** Separate foreground worker; no browser cookies, no DRM or login bypass. */
public class YouTubeDownloadService extends Service {
    static final String START="youtube.start", UPDATE="youtube.update", CANCEL="youtube.cancel";
    static final String CHANNEL="youtube_transfers", PREF="youtube_transfer";
    static final int NOTIFICATION=22;
    static volatile boolean busy=false, cancelled=false;
    static volatile String state="Ready", detail="", resultUri="", resultName="", jobId="", engineVersion="";
    static volatile long bytes=-1,total=-1,rate=-1,eta=-1;
    final Handler main=new Handler(Looper.getMainLooper());
    PowerManager.WakeLock wake;
    volatile Thread worker;
    int latestStart;
    static boolean restored=false;
    static synchronized void restore(Context c){
        if(restored)return;restored=true;
        SharedPreferences p=c.getSharedPreferences(PREF,0);
        engineVersion=p.getString("engine_version","");state=p.getString("state","Ready");detail=p.getString("detail","");resultUri=p.getString("uri","");resultName=p.getString("name","");
        if(state.equals("Downloading")||state.equals("Preparing")||state.equals("Saving")||state.equals("Updating")){state="Interrupted";detail="Start again to retry.";}
    }
    static synchronized void clearFinished(Context c){restore(c);if(busy)return;state="Ready";detail="";resultUri="";resultName="";bytes=total=rate=eta=-1;c.getSharedPreferences(PREF,0).edit().clear().apply();}
    void persist(){getSharedPreferences(PREF,0).edit().putString("state",state).putString("detail",detail).putString("uri",resultUri).putString("name",resultName).putString("engine_version",engineVersion).apply();}
    @Override public void onCreate(){super.onCreate();restore(this);getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"YouTube downloads",NotificationManager.IMPORTANCE_LOW));wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"SRBrowser:YouTube");wake.setReferenceCounted(false);}
    static int percent(){return total>0&&bytes>=0?(int)Math.max(0,Math.min(100,100.0*bytes/total)):0;}
    static String time(long s){if(s<0)return "Calculating…";return s>=3600?String.format(Locale.US,"%dh %02dm %02ds",s/3600,s/60%60,s%60):String.format(Locale.US,"%dm %02ds",s/60,s%60);}
    Notification note(){
        PendingIntent open=PendingIntent.getActivity(this,22,new Intent(this,YouTubeDownloadsActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String text=state.equals("Downloading")?(rate>=0?DownloadsActivity.size(rate)+"/s · ":"")+"Stream ETA "+time(eta):detail.isEmpty()?state:detail;
        Notification.Builder n=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_download).setContentTitle("SR Turbo • YouTube • "+state).setContentText(text).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(busy);
        if(busy){n.setProgress(100,percent(),total<=0||!state.equals("Downloading"));if(!state.equals("Updating")){PendingIntent stop=PendingIntent.getService(this,23,new Intent(this,YouTubeDownloadService.class).setAction(CANCEL),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);n.addAction(new Notification.Action.Builder(null,"Cancel",stop).build());}}
        return n.build();
    }
    @Override public int onStartCommand(Intent i,int flags,int startId){
        latestStart=startId;startForeground(NOTIFICATION,note());
        String action=i==null?"":i.getAction();
        if(CANCEL.equals(action)){
            if(busy&&!state.equals("Updating")){cancelled=true;detail="Stopping…";}
            if(!busy){stopForeground(STOP_FOREGROUND_REMOVE);stopSelfResult(latestStart);}return START_NOT_STICKY;
        }
        if(busy)return START_NOT_STICKY;
        boolean update=UPDATE.equals(action);
        String url=START.equals(action)?YouTubeLinks.canonical(i.getStringExtra("url")):null;
        if(!update&&url==null){stopForeground(STOP_FOREGROUND_REMOVE);stopSelfResult(latestStart);return START_NOT_STICKY;}
        final int quality=update?720:YouTubeLinks.quality(i.getIntExtra("quality",720));
        busy=true;cancelled=false;jobId=UUID.randomUUID().toString();bytes=total=rate=eta=-1;state=update?"Updating":"Preparing";detail=update?"Checking official yt-dlp release…":"Initializing video engine…";
        if(!update){resultUri="";resultName="";}persist();wake.acquire(6*60*60*1000L);main.post(tick);
        worker=new Thread(()->runJob(url,quality,update),"youtube-download");worker.start();return START_NOT_STICKY;
    }
    final Runnable tick=new Runnable(){public void run(){if(!busy)return;if(cancelled&&!state.equals("Updating")){String id=jobId;new Thread(()->YoutubeDL.getInstance().destroyProcessById(id),"youtube-cancel").start();}getSystemService(NotificationManager.class).notify(NOTIFICATION,note());main.postDelayed(this,1000);}};
    void check() throws InterruptedIOException {if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("Cancelled");}
    String actualEngineVersion() throws Exception {
        // --version is local; it must report the real executable, not cached metadata.
        YoutubeDLRequest probe=new YoutubeDLRequest("https://www.youtube.com/");
        probe.addOption("--ignore-config").addOption("--version");
        String version=VideoEnginePolicy.version(YoutubeDL.getInstance().execute(probe,jobId,null).getOut());
        if(version.isEmpty())throw new IOException("Cannot verify installed yt-dlp version.");
        return version;
    }
    String ensureEngine(boolean force) throws Exception {
        SharedPreferences checks=getSharedPreferences("youtube_engine_checks",0);
        String before="";
        try{before=actualEngineVersion();}catch(Exception e){check();}
        engineVersion=before;persist();
        long now=System.currentTimeMillis();
        if(!force&&!VideoEnginePolicy.needsCheck(before,LocalDate.now(),now,checks.getLong("last_check",0)))return "Engine verified: "+before;
        detail="Checking official stable yt-dlp release…";persist();
        try{
            // Use the Android library updater, not the old executable's self-updater.
            YoutubeDL.getInstance().updateYoutubeDL(getApplicationContext(),YoutubeDL.UpdateChannel._STABLE);
            check();engineVersion=actualEngineVersion();persist();
            if(VideoEnginePolicy.outdated(engineVersion,LocalDate.now()))throw new IOException("Installed engine is still outdated: "+engineVersion);
            checks.edit().putLong("last_check",System.currentTimeMillis()).apply();
            return "Engine verified: "+engineVersion;
        }catch(Exception e){
            check();checks.edit().remove("last_check").apply();
            // If update failed, do not trust a partial installation or old executable.
            try{engineVersion=actualEngineVersion();}catch(Exception ignored){engineVersion="";}
            check();persist();
            if(force||VideoEnginePolicy.outdated(engineVersion,LocalDate.now()))throw new IOException("Engine update/verification failed. Check internet access to GitHub and use Update video engine again. "+Objects.toString(e.getMessage(),""),e);
            return "Update check unavailable; using verified installed engine "+engineVersion;
        }
    }
    void runJob(String url,int quality,boolean update){File dir=null;Uri pending=null;String outcome="Failed",message="";
        try{
            YoutubeDL.getInstance().init(getApplicationContext());FFmpeg.getInstance().init(getApplicationContext());check();
            String engineMessage=ensureEngine(update);check();
            if(update){outcome="Ready";message=engineMessage;}
            else{
                dir=new File(getFilesDir(),"youtube-jobs/"+jobId);if(!dir.mkdirs())throw new IOException("Cannot create temporary directory");
                YoutubeDLRequest request=new YoutubeDLRequest(url);
                request.addOption("--no-playlist").addOption("--ignore-config").addOption("--newline").addOption("--no-colors").addOption("--no-overwrites").addOption("--restrict-filenames").addOption("--trim-filenames",120).addOption("--match-filter","!is_live").addOption("--socket-timeout",20).addOption("--retries",3).addOption("--fragment-retries",3).addOption("--concurrent-fragments",8).addOption("--format",YouTubeLinks.format(quality)).addOption("--merge-output-format","mp4").addOption("--progress").addOption("--progress-template",YouTubeLinks.PROGRESS).addOption("-o",new File(dir,"%(title)s_%(id)s.%(ext)s").getAbsolutePath());
                state="Downloading";detail=engineMessage+" • Resolving video…";persist();check();
                YoutubeDL.getInstance().execute(request,jobId,(progress,seconds,line)->{
                    long[] p=YouTubeLinks.progress(line);if(p!=null){bytes=p[0];total=p[1];rate=p[2];eta=p[3];detail="Current video/audio stream";}
                    else if(line!=null&&(line.startsWith("[Merger]")||line.startsWith("[Fixup"))){rate=eta=-1;detail="Merging video and audio…";}
                    return Unit.INSTANCE;
                });check();
                File[] files=dir.listFiles(f->f.isFile()&&f.getName().endsWith(".mp4")&&f.length()>0);
                if(files==null||files.length!=1)throw new IOException("Expected one complete MP4; no file was published.");
                File file=files[0];state="Saving";detail="Saving MP4 to Downloads…";rate=eta=-1;persist();
                ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,DownloadService.safeName(file.getName()));v.put(MediaStore.Downloads.MIME_TYPE,"video/mp4");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/SR Turbo/YouTube");v.put(MediaStore.Downloads.IS_PENDING,1);
                pending=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(pending==null)throw new IOException("Cannot create Downloads file");
                try(InputStream in=new FileInputStream(file);OutputStream out=getContentResolver().openOutputStream(pending)){
                    if(out==null)throw new IOException("Cannot open Downloads file");byte[] buf=new byte[256*1024];int n;while((n=in.read(buf))!=-1){check();out.write(buf,0,n);}
                }
                check();ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);if(getContentResolver().update(pending,done,null,null)!=1)throw new IOException("Cannot publish MP4");
                resultUri=pending.toString();resultName=file.getName();pending=null;bytes=total=file.length();outcome="Completed";message="Saved to Download/SR Turbo/YouTube";
            }
        }catch(Exception e){outcome=cancelled?"Cancelled":"Failed";String m=Objects.toString(e.getMessage(),e.getClass().getSimpleName());boolean mediaFailure=state.equals("Downloading");if(mediaFailure&&VideoEnginePolicy.forbidden(m))getSharedPreferences("youtube_engine_checks",0).edit().remove("last_check").apply();String explained=mediaFailure?VideoEnginePolicy.error(m):m;message=cancelled?"Download cancelled. Start again to retry.":explained.substring(0,Math.min(1200,explained.length()));}
        finally{
            if(pending!=null)try{getContentResolver().delete(pending,null,null);}catch(Exception ignored){}
            if(dir!=null){File[] all=dir.listFiles();if(all!=null)for(File f:all)f.delete();dir.delete();}
            final String finalState=outcome,finalMessage=message;
            main.post(()->{state=finalState;detail=finalMessage;rate=eta=-1;if(!finalState.equals("Completed")){bytes=total=-1;}busy=false;persist();main.removeCallbacks(tick);if(wake.isHeld())wake.release();stopForeground(STOP_FOREGROUND_REMOVE);getSystemService(NotificationManager.class).notify(NOTIFICATION,note());stopSelfResult(latestStart);});
        }
    }
    @Override public void onDestroy(){main.removeCallbacks(tick);if(busy){cancelled=true;if(worker!=null)worker.interrupt();String id=jobId;new Thread(()->YoutubeDL.getInstance().destroyProcessById(id)).start();}if(wake!=null&&wake.isHeld())wake.release();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
