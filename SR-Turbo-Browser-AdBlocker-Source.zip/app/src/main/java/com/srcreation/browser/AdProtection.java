package com.srcreation.browser;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

final class AdProtection {
    static final String SOURCE="https://raw.githubusercontent.com/AdAway/adaway.github.io/master/hosts.txt";
    static final long DAY=86400000L;
    final SharedPreferences prefs;final boolean privateMode;
    volatile boolean ads,yt,skip,tracking,popups,auto;
    volatile Set<String> allow,extra;
    volatile String status="Built-in filters ready";
    final AtomicBoolean updating=new AtomicBoolean();
    AdProtection(Context context,boolean incognito){privateMode=incognito;prefs=context.getSharedPreferences("ad_protection",0);ads=prefs.getBoolean("ads",true);yt=prefs.getBoolean("yt",true);skip=prefs.getBoolean("skip",true);tracking=prefs.getBoolean("tracking",true);popups=prefs.getBoolean("popups",true);auto=prefs.getBoolean("auto",true);allow=incognito?Collections.emptySet():Collections.unmodifiableSet(new HashSet<>(prefs.getStringSet("allow",Collections.emptySet())));try{extra=AdRules.parseHosts(prefs.getString("hosts",""));}catch(RuntimeException e){extra=Collections.emptySet();}if(!extra.isEmpty())status="Updated hosts: "+extra.size();}
    boolean enabled(String url){return AdRules.enabled(url,allow);}
    boolean any(String url){return enabled(url)&&(tracking||popups||(AdRules.youtube(AdRules.host(url))?(yt||skip):ads));}
    void set(String key,boolean v){switch(key){case "ads":ads=v;break;case "yt":yt=v;break;case "skip":skip=v;break;case "tracking":tracking=v;break;case "popups":popups=v;break;case "auto":auto=v;break;default:return;}if(!privateMode)prefs.edit().putBoolean(key,v).apply();}
    void allowSite(String url,boolean disabled){String h=AdRules.host(url);if(h.isEmpty())return;Set<String> next=new HashSet<>(allow);if(disabled)next.add(h);else next.remove(h);allow=Collections.unmodifiableSet(next);if(!privateMode)prefs.edit().putStringSet("allow",next).apply();}
    boolean block(String page,String resource,boolean main){return AdRules.block(page,resource,main,ads,yt,tracking,allow,extra);}
    void update(boolean manual,Runnable done){if(privateMode||(!manual&&(!auto||!ads||System.currentTimeMillis()-prefs.getLong("updated",0)<DAY)))return;if(!updating.compareAndSet(false,true))return;status="Updating filter list…";new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(SOURCE).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(15000);if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(bytes.size()+n>2000000)throw new IOException("List too large");bytes.write(b,0,n);}}String text=new String(bytes.toByteArray(),StandardCharsets.UTF_8);Set<String> parsed=AdRules.parseHosts(text);if(parsed.size()<100)throw new IOException("Invalid or incomplete filter list");if(!prefs.edit().putString("hosts",text).putLong("updated",System.currentTimeMillis()).commit())throw new IOException("Cannot save filters");extra=parsed;status="Updated hosts: "+parsed.size();}catch(Exception e){status="Update failed • previous filters retained";}finally{if(c!=null)c.disconnect();updating.set(false);if(done!=null)done.run();}},"sr-ad-filter").start();}
}
