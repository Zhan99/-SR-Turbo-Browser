(function(){
 if(window.__srPageTranslationV1)return;
 const excluded='script,style,noscript,template,textarea,input,select,option,code,pre,svg,canvas,[contenteditable]:not([contenteditable="false"]),[translate="no"],.notranslate,[aria-hidden="true"]';
 let token='',nodes=[];
 function restore(){for(const row of nodes){if(row.node.isConnected&&row.applied!==null&&row.node.nodeValue===row.applied)row.node.nodeValue=row.original;}nodes=[];token='';}
 function scan(id){restore();token=id;let texts=[],chars=0,limited=false,sample='';if(!document.body)return {texts,sample,limited};
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while((n=walker.nextNode())){const p=n.parentElement,original=n.nodeValue||'',text=original.trim();if(!p||!text||!/[\p{L}]/u.test(text)||p.closest(excluded)||p.getClientRects().length===0)continue;const css=getComputedStyle(p);if(css.visibility==='hidden'||css.visibility==='collapse'||css.display==='none')continue;
 if(text.length>4000){limited=true;continue;}if(texts.length>=1000||chars+text.length>100000){limited=true;break;}nodes.push({node:n,original,applied:null});texts.push(text);chars+=text.length;if(sample.length<1800)sample+=' '+text;}
 return {texts,sample:sample.slice(0,1800),limited};}
 function apply(id,items){if(id!==token)return 0;let changed=0;for(const item of items){const row=nodes[item[0]];if(!row||!row.node.isConnected||row.node.nodeValue!==row.original||typeof item[1]!=='string')continue;const prefix=row.original.match(/^\s*/)[0],suffix=row.original.match(/\s*$/)[0];row.applied=prefix+item[1]+suffix;row.node.nodeValue=row.applied;changed++;}return changed;}
 window.__srPageTranslationV1={scan,apply,restore};
})();
