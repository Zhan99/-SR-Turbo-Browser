/* Capture only explicit generated-file download anchors, including detached ones.
 * A Blob reference is held synchronously before the site revokes its URL.
 * All data moves from the originating frame to the browser, never to another site. */
(() => {
  'use strict';
  const bridge = window.SrGeneratedFiles;
  if (!bridge || !/^https?:$/.test(location.protocol)) return;
  const MAX = 128 * 1024 * 1024, CHUNK = 64 * 1024;
  const blobs = new Map(), jobs = new Map();
  let retainedBytes=0;
  const drop=u=>{const b=blobs.get(u);if(b){retainedBytes-=b.size;blobs.delete(u);}};
  const create = URL.createObjectURL, revoke = URL.revokeObjectURL;
  const nativeClick = HTMLAnchorElement.prototype.click;
  const originalFetch = window.fetch.bind(window);
  const send = v => bridge.postMessage(JSON.stringify(v));
  URL.createObjectURL = function(obj) {
    const u = create.call(this, obj);
    if (obj instanceof Blob && obj.size <= MAX) {
      blobs.set(u, obj);retainedBytes+=obj.size;
      // Bound bookkeeping; active transfers keep their own reference.
      while (blobs.size > 64 || retainedBytes > MAX) drop(blobs.keys().next().value);
    }
    return u;
  };
  URL.revokeObjectURL = function(u) {
    const key=String(u);setTimeout(()=>drop(key),15000); // retain briefly for native DownloadListener fallback
    return revoke.call(this, u);
  };
  Object.defineProperty(window,"__srGeneratedBlob",{value:u=>blobs.get(u),configurable:false});
  async function start(a) {
    const u = a.href, name = (a.getAttribute('download') || '').slice(0, 200);
    const id = (globalThis.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2));
    // Evaluate this synchronously, before await or the caller's revokeObjectURL.
    const saved = blobs.get(u);
    if (jobs.size >= 2) { send({op:'notice', error:'Another generated file is being saved.'}); return; }
    const job = {blob:null,offset:0,busy:false}; jobs.set(id,job);
    try {
      const b = saved || await originalFetch(u).then(r=>{if(!r.ok)throw Error('File unavailable');return r.blob();});
      if (b.size > MAX) throw Error('Generated file exceeds 128 MB');
      if (!jobs.has(id)) return;
      job.blob=b;
      send({op:'begin', id, name, mime:b.type, size:b.size});
    } catch(e) { jobs.delete(id); send({op:'notice',name,error:'Generated file unavailable. Open the original page and export again.'}); }
  }
  function handles(a) {
    return a instanceof HTMLAnchorElement && a.hasAttribute('download') && /^(blob:|data:)/i.test(a.href);
  }
  HTMLAnchorElement.prototype.click = function() {
    if (handles(this)) { start(this); return; }
    return nativeClick.apply(this, arguments);
  };
  document.addEventListener('click', e => {
    if (e.defaultPrevented || e.button !== 0) return;
    const a = e.composedPath().find(handles);
    if (a) { e.preventDefault(); start(a); }
  }, true);
  bridge.onmessage = async e => {
    let q; try {q=JSON.parse(e.data);}catch(_){return;}
    const j=jobs.get(q.id); if(!j) return;
    if(q.op==='end') {jobs.delete(q.id);return;}
    if(q.op!=='next'||!j.blob||j.busy||q.offset!==j.offset) return;
    j.busy=true;
    try {
      const end=Math.min(j.blob.size,j.offset+CHUNK);
      const bytes=new Uint8Array(await j.blob.slice(j.offset,end).arrayBuffer());
      let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));
      const offset=j.offset;j.offset=end;j.busy=false;
      send({op:'chunk',id:q.id,offset,data:btoa(raw)});
    } catch(_) {jobs.delete(q.id);send({op:'abort',id:q.id});}
  };
})();
