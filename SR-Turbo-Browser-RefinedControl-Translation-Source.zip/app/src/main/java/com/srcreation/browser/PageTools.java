package com.srcreation.browser;

import java.net.URI;
import java.net.URLEncoder;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

/** User-initiated website translation and opt-in viewport accessibility. */
final class PageTools {
    static final String[] CODES={"bn","en","hi","ar","ur","zh-CN","es","fr","de","ja","ko","ru","pt","id","ms","tr"};
    static final String[] LANGUAGES={"বাংলা (Bangla)","English","Hindi","Arabic","Urdu","Chinese (Simplified)","Spanish","French","German","Japanese","Korean","Russian","Portuguese","Indonesian","Malay","Turkish"};
    static int languageIndex(String code){for(int i=0;i<CODES.length;i++)if(CODES[i].equals(code))return i;return 0;}
    static String language(String code){return CODES[languageIndex(code)];}
    static boolean canTranslate(String value){
        try{URI u=URI.create(value);String h=u.getHost();if(h==null||u.getRawUserInfo()!=null||!("http".equalsIgnoreCase(u.getScheme())||"https".equalsIgnoreCase(u.getScheme())))return false;
            h=h.toLowerCase(Locale.ROOT);if(h.endsWith("."))h=h.substring(0,h.length()-1);
            if(!h.contains(".")||h.contains(":")||h.matches("[0-9.]+")||h.endsWith(".local")||h.endsWith(".localhost")||h.endsWith(".internal")||h.endsWith(".test")||h.endsWith(".home.arpa")||GoogleLinks.isAccountSite(value))return false;
            return !h.equals("translate.google.com")&&!h.endsWith(".translate.goog")&&!h.equals("accounts.google.com")&&!h.equals("myaccount.google.com")&&!h.equals("mail.google.com");
        }catch(RuntimeException e){return false;}
    }
    static String translateUrl(String page,String target){if(!canTranslate(page))throw new IllegalArgumentException("Public website URL required");String original=page.split("#",2)[0];return "https://translate.google.com/translate?sl=auto&tl="+language(target)+"&u="+encode(original);}
    private static String encode(String value){try{return URLEncoder.encode(value,"UTF-8");}catch(UnsupportedEncodingException impossible){throw new AssertionError(impossible);}}
    static String translatorHome(String target){return "https://translate.google.com/?sl=auto&tl="+language(target)+"&op=translate";}
    static int textSize(int value){return Math.max(50,Math.min(200,value));}
    // Only presentation metadata. Preserve desktop width, initial scale and other attributes.
    static String viewport(boolean enabled){return "(function(){var m=document.querySelector('meta[name=viewport]'),s=window.__srZoomViewport;if(!"+enabled+"){if(s&&s.node===m&&m&&m.getAttribute('content')===s.applied)m.setAttribute('content',s.original);delete window.__srZoomViewport;return;}if(!m)return;var original=m.getAttribute('content')||'';if(s&&s.node===m&&s.applied===original)return;var parts=original.split(/[,;]/).map(function(x){return x.trim();}).filter(function(x){return x&&!/^(user-scalable|minimum-scale|maximum-scale)\\s*=/i.test(x);});parts.push('user-scalable=yes','minimum-scale=0.1','maximum-scale=5');var next=parts.join(', ');window.__srZoomViewport={node:m,original:original,applied:next};m.setAttribute('content',next);})()";}
    private PageTools(){}
}
