package com.srcreation.browser;

import android.app.AlertDialog;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import org.json.*;
import java.util.*;
import java.io.*;

/** Translates readable HTML text in place with Google's on-device translation models. */
final class PageTranslation {
    private final BrowserActivity a;
    private final Map<BrowserActivity.Tab,Run> jobs=new IdentityHashMap<>();
    private final Map<BrowserActivity.Tab,String> states=new IdentityHashMap<>();
    private LinearLayout bar; private TextView language,status,original;
    private String script;
    private boolean closed;
    PageTranslation(BrowserActivity activity){a=activity;}
    static final class Run {
        final String id=UUID.randomUUID().toString(),url,target; final int generation;
        final BrowserActivity.Tab tab; final ArrayList<String> texts=new ArrayList<>();
        Translator translator; LanguageIdentifier identifier; boolean limited;int done,failed,applied;
        Run(BrowserActivity.Tab t,String target){tab=t;url=t.url;generation=t.adGeneration;this.target=target;}
        void release(){if(identifier!=null){identifier.close();identifier=null;}if(translator!=null){translator.close();translator=null;}}
    }
    void build(LinearLayout top){bar=Ui.row(a);bar.setPadding(Ui.dp(a,6),Ui.dp(a,3),Ui.dp(a,6),Ui.dp(a,4));language=Ui.button(a,"",Color.WHITE,a.palette().toolbar,this::choose);language.setTextSize(12);language.setContentDescription("Select translation language and translate current page");bar.addView(language,new LinearLayout.LayoutParams(-2,Ui.dp(a,42)));status=Ui.text(a,"",11,Color.WHITE,false);status.setMaxLines(2);status.setPadding(Ui.dp(a,8),0,Ui.dp(a,4),0);bar.addView(status,new LinearLayout.LayoutParams(0,-2,1));original=Ui.button(a,"Original",Color.WHITE,a.palette().toolbar,()->restore(a.active()));original.setTextSize(12);bar.addView(original,new LinearLayout.LayoutParams(-2,Ui.dp(a,42)));top.addView(bar);refresh();}
    void refresh(){if(bar==null)return;BrowserActivity.Tab t=a.active();boolean on=a.translationEnabled;bar.setVisibility(on?View.VISIBLE:View.GONE);if(!on)return;bar.setBackgroundColor(a.palette().nav);language.setBackground(Ui.surface(a,a.palette().toolbar,12,0x33ffffff));original.setBackground(Ui.surface(a,a.palette().toolbar,12,0x33ffffff));language.setText("G  "+PageTools.LANGUAGES[PageTools.languageIndex(a.translateLanguage)]+"  ▾");status.setText("Powered by Google Translate"+(t!=null&&states.containsKey(t)?"\n"+states.get(t):""));boolean valid=t!=null&&BrowserActivity.http(t.url)&&!t.pendingRestore;language.setEnabled(valid);language.setAlpha(valid?1:.55f);original.setVisibility(t!=null&&states.containsKey(t)?View.VISIBLE:View.GONE);}
    void enabled(boolean on){if(!on){for(BrowserActivity.Tab t:new ArrayList<>(a.tabs))restore(t);}refresh();}
    void choose(){BrowserActivity.Tab t=a.active();if(t==null||!BrowserActivity.http(t.url)){a.toast("Open a webpage first");return;}
        new AlertDialog.Builder(a).setTitle("Translate current page").setSingleChoiceItems(PageTools.LANGUAGES,PageTools.languageIndex(a.translateLanguage),(d,i)->{d.dismiss();if(a.active()!=t)return;a.translateLanguage=PageTools.CODES[i];a.pref("translate_language",a.translateLanguage);start(t);}).setNegativeButton("Cancel",null).show();}
    boolean live(Run r){return !closed&&a.translationEnabled&&a.tabs.contains(r.tab)&&jobs.get(r.tab)==r&&r.generation==r.tab.adGeneration&&Objects.equals(r.url,r.tab.url)&&!a.isFinishing()&&!a.isDestroyed();}
    void set(Run r,String message){if(live(r)){states.put(r.tab,message);if(a.active()==r.tab)refresh();}}
    void forget(BrowserActivity.Tab t){Run r=jobs.remove(t);if(r!=null)r.release();states.remove(t);if(a.active()==t)refresh();}
    void restore(BrowserActivity.Tab t){if(t==null)return;forget(t);if(!t.pendingRestore&&a.tabs.contains(t))t.web.evaluateJavascript("if(window.__srPageTranslationV1)window.__srPageTranslationV1.restore()",null);}
    void close(){closed=true;for(Run r:jobs.values())r.release();jobs.clear();states.clear();}
    String script() throws IOException{if(script==null){try(InputStream in=a.getAssets().open("sr-page-translation.js")){ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)buf.write(b,0,n);script=buf.toString("UTF-8");}}return script;}
    void start(BrowserActivity.Tab t){if(!a.translationEnabled||t.pendingRestore||!BrowserActivity.http(t.url))return;forget(t);Run r=new Run(t,a.translateLanguage);jobs.put(t,r);set(r,"Reading page…");try{String js=script()+"\n;window.__srPageTranslationV1.scan("+JSONObject.quote(r.id)+")";t.web.evaluateJavascript(js,result->{if(!live(r))return;try{JSONObject data=new JSONObject(result);JSONArray texts=data.getJSONArray("texts");for(int i=0;i<texts.length();i++)r.texts.add(texts.getString(i));r.limited=data.optBoolean("limited");if(r.texts.isEmpty()){finish(r,"No readable page text");return;}String sample=data.optString("sample");r.identifier=LanguageIdentification.getClient();r.identifier.identifyLanguage(sample).addOnSuccessListener(source->{if(!live(r))return;if(r.identifier!=null){r.identifier.close();r.identifier=null;}prepare(r,source);}).addOnFailureListener(err->fail(r,"Language detection failed"));}catch(Exception e){fail(r,"Could not read page text");}});}catch(Exception e){fail(r,"Could not load translator");}}
    void prepare(Run r,String detected){String source=TranslateLanguage.fromLanguageTag(detected),target=TranslateLanguage.fromLanguageTag(r.target.equals("zh-CN")?"zh":r.target);if(source==null||target==null){finish(r,"Language not detected/supported");return;}if(source.equals(target)){finish(r,"Page already in selected language");return;}try{r.translator=Translation.getClient(new TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build());set(r,"Preparing language model…");r.translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()).addOnSuccessListener(unused->{if(live(r))next(r);}).addOnFailureListener(err->fail(r,"Model download failed • retry"));}catch(Exception e){fail(r,"Translation unavailable");}}
    void next(Run r){if(!live(r))return;if(r.done>=r.texts.size()){finish(r,(r.failed==0&&!r.limited?"Translated":"Partial translation")+" · "+r.applied+" text blocks");return;}final int start=r.done,end=Math.min(start+8,r.texts.size());List<Task<String>> tasks=new ArrayList<>();try{for(int i=start;i<end;i++)tasks.add(r.translator.translate(r.texts.get(i)));Tasks.whenAllComplete(tasks).addOnCompleteListener(completed->{if(!live(r))return;JSONArray values=new JSONArray();for(int i=0;i<tasks.size();i++){Task<String> task=tasks.get(i);if(task.isSuccessful()&&task.getResult()!=null){JSONArray pair=new JSONArray();pair.put(start+i);pair.put(task.getResult());values.put(pair);}else r.failed++;}String js="window.__srPageTranslationV1?window.__srPageTranslationV1.apply("+JSONObject.quote(r.id)+","+values.toString()+"):0";r.tab.web.evaluateJavascript(js,count->{if(!live(r))return;int applied=0;try{applied=Integer.parseInt(count);}catch(Exception ignored){}r.applied+=applied;r.failed+=Math.max(0,values.length()-applied);r.done=end;set(r,"Translating "+(100*r.done/r.texts.size())+"%");next(r);});});}catch(Exception e){fail(r,"Translation interrupted • retry");}}
    void finish(Run r,String message){if(!live(r))return;set(r,message);jobs.remove(r.tab);r.release();}
    void fail(Run r,String message){finish(r,message);}
}
