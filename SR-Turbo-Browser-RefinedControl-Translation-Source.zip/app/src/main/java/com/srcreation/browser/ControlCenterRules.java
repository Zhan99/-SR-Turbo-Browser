package com.srcreation.browser;
import java.util.Locale;
final class ControlCenterRules {
    private ControlCenterRules() {}
    static boolean matches(String query,String section,String row){
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        String hay=((section==null?"":section)+" "+(row==null?"":row)).toLowerCase(Locale.ROOT);
        for(String word:q.split("\\s+"))if(!hay.contains(word))return false;
        return true;
    }
    static int delay(int index){return Math.min(7,Math.max(0,index))*24;}
    static String transferLabel(DownloadBadge meter){return meter.count==0?"Idle":meter.label();}
}
