package com.srcreation.browser;
final class MediaChoice {
    static final int AUDIO=-1;
    static final int[] VALUES={360,480,720,1080,AUDIO};
    static final String[] LABELS={"360p (MP4)","480p (MP4)","720p HD (MP4)","1080p Full HD (MP4)","MP3 Audio Only"};
    static int normalize(int value){return value==AUDIO?AUDIO:YouTubeLinks.quality(value);}
    static boolean audio(int value){return value==AUDIO;}
    static String extension(int value){return audio(value)?"mp3":"mp4";}
    static String mime(int value){return audio(value)?"audio/mpeg":"video/mp4";}
    static String format(String url,int value){return audio(value)?"bestaudio/best":SiteVideoLinks.format(url,value);}
    static String resultMime(String name){return name!=null&&name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp3")?"audio/mpeg":"video/mp4";}
}
