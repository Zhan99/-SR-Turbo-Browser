package com.srcreation.browser;

import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.*;
import android.view.animation.*;
import android.widget.*;

/** A single collection of controls, with native, function-specific visual effects. */
final class ControlCenterUi {
    final BrowserActivity a; final Dialog dialog; final boolean animate;
    ScrollView scrollView;
    ControlCenterUi(BrowserActivity activity,Dialog d,boolean animations){a=activity;dialog=d;animate=animations&&android.animation.ValueAnimator.areAnimatorsEnabled();}
    int dp(float x){return Ui.dp(a,x);}
    int scrollPosition(){return scrollView==null?0:scrollView.getScrollY();}
    void header(LinearLayout shell,boolean settings){
        LinearLayout head=Ui.row(a);Ui.pad(head,a,10);head.setBackground(Ui.gradient(a,a.palette().nav,a.palette().toolbar,20));
        LinearLayout text=Ui.column(a);TextView small=Ui.text(a,"SR TURBO",10,a.palette().highlight,true);small.setLetterSpacing(.20f);text.addView(small);text.addView(Ui.text(a,settings?"Settings":"Control center",24,Color.WHITE,true));head.addView(text,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=Ui.button(a,"×",Color.WHITE,0x22ffffff,dialog::dismiss);close.setTextSize(24);close.setContentDescription("Close control center");head.addView(close,new LinearLayout.LayoutParams(dp(48),dp(48)));shell.addView(head);
    }
    static void paintToggle(BrowserActivity a,LinearLayout row,Switch sw,boolean on){
        Ui.ripple(row,a,on?a.activeFill():a.card(),17,on?a.accent():a.line());
        sw.setThumbTintList(ColorStateList.valueOf(on?a.accent():0xff91a1b2));sw.setTrackTintList(ColorStateList.valueOf(on?0xff74bdb0:0xffb6c0cc));
        View first=row.getChildAt(0);if(first instanceof TextView){TextView icon=(TextView)first;icon.setBackground(Ui.bg(on?a.card():a.paper(),12,a));if(icon.getCompoundDrawables()[1]!=null)icon.getCompoundDrawables()[1].setTint(on?a.accent():a.muted());else icon.setTextColor(on?a.accent():a.muted());}
    }
    void toggleEffect(LinearLayout row,boolean on){if(!animate)return;View icon=row.getChildAt(0);icon.animate().cancel();icon.setScaleX(.78f);icon.setScaleY(.78f);icon.setRotation(on?-12:12);icon.animate().scaleX(1).scaleY(1).rotation(0).setDuration(280).setInterpolator(new OvershootInterpolator(1.6f)).start();}
    void style(LinearLayout row,int effect){
        if(row.getChildCount()==0)return;View icon=row.getChildAt(0);int[] hues={0xff178985,0xff557dc5,0xff9b6ab8,0xffc17b39,0xff3b9170};int c=hues[effect%hues.length];icon.setBackground(Ui.gradient(a,DisplaySpace.alpha(c,18),DisplaySpace.alpha(c,38),13));
        if(!animate)return;
        row.setOnTouchListener((v,e)->{int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN){v.animate().cancel();v.animate().scaleX(.975f).scaleY(.975f).setDuration(95).start();icon.animate().cancel();if(effect==0)icon.animate().rotation(-12).setDuration(100).start();else if(effect==1)icon.animate().translationX(dp(3)).setDuration(100).start();else if(effect==2)icon.animate().scaleX(1.16f).scaleY(1.16f).setDuration(100).start();else if(effect==3)icon.animate().translationY(-dp(4)).setDuration(100).start();else icon.animate().rotation(12).scaleX(1.10f).scaleY(1.10f).setDuration(100).start();}else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){v.animate().scaleX(1).scaleY(1).setDuration(160).start();icon.animate().rotation(0).translationX(0).translationY(0).scaleX(1).scaleY(1).setDuration(240).setInterpolator(new OvershootInterpolator()).start();}return false;});
    }
    void show(LinearLayout shell,LinearLayout body,ScrollView scroll,int firstRow,String query,int scrollPosition,boolean restoring){
        scrollView=scroll;int group=0;for(int i=0;i<body.getChildCount();i++){View child=body.getChildAt(i);if(child instanceof TextView){group++;child.setPadding(dp(8),dp(19),dp(4),dp(8));}else if(child instanceof LinearLayout)style((LinearLayout)child,(group+i)%5);}
        shell.setFocusableInTouchMode(true);shell.requestFocus();dialog.setContentView(shell);dialog.setOwnerActivity(a);dialog.setOnDismissListener(d->{if(a.controlDialog==dialog){a.controlDialog=null;a.currentControlUi=null;}});dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setDimAmount(.40f);w.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);android.util.DisplayMetrics dm=a.getResources().getDisplayMetrics();w.setLayout(Math.min(dm.widthPixels-dp(16),dp(500)),Math.min(dm.heightPixels-dp(36),dp(850)));WindowManager.LayoutParams p=w.getAttributes();p.y=dp(8);w.setAttributes(p);}
        if(restoring)scroll.post(()->scroll.scrollTo(0,scrollPosition));
        if(animate&&!restoring){shell.setAlpha(0);shell.setTranslationY(-dp(14));shell.setScaleX(.98f);shell.setScaleY(.98f);shell.animate().alpha(1).translationY(0).scaleX(1).scaleY(1).setDuration(230).setInterpolator(new DecelerateInterpolator()).start();for(int i=0;i<Math.min(9,body.getChildCount());i++){View v=body.getChildAt(i);v.setAlpha(.45f);v.setTranslationX(dp(i%2==0?8:-8));v.animate().alpha(1).translationX(0).setStartDelay(ControlCenterRules.delay(i)).setDuration(200).start();}}
    }
}
