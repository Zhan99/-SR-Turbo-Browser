package com.srcreation.browser;
/** Live byte-weighted regular transfers; video-only uses current stream progress. */
final class DownloadBadge {
    int count; double bytes,total; boolean unknown,video;
    void add(String state,long done,long size){
        if(!("Queued".equals(state)||"Running".equals(state)||"Saving".equals(state)||"Stopping".equals(state)))return;
        count++; if(size<=0||done<0){unknown=true;return;} total+=size;bytes+=Math.min(done,size);
    }
    void video(String state,long done,long size){count=1;video=true;if(!"Downloading".equals(state)||size<=0||done<0){unknown=true;return;}total=size;bytes=Math.min(done,size);}
    String label(){return count==0?"":unknown||total<=0?"…":((int)Math.max(0,Math.min(100,100*bytes/total)))+"%";}
    String description(){return (video?"Current video/audio stream: ":count+" active regular transfer(s): ")+(unknown||total<=0?"calculating progress":label());}
}
