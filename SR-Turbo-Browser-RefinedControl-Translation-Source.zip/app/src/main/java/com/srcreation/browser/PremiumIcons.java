package com.srcreation.browser;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.view.Gravity;
final class PremiumIcons {
 static void inline(TextView v,int res,String label,int color,int size){
 Drawable d=v.getContext().getDrawable(res).mutate();d.setTint(color);int px=Ui.dp(v.getContext(),size);d.setBounds(0,0,px,px);
 v.setText(label);v.setTextColor(color);v.setGravity(Gravity.CENTER);v.setCompoundDrawablePadding(Ui.dp(v.getContext(),1));
 if(label.isEmpty())v.setCompoundDrawables(null,d,null,null);else v.setCompoundDrawables(d,null,null,null);
 }
 // Two-tone navigation glyphs keep their dark outline on bright pages; no tint or chip is required.
 static void navigation(TextView v,String key,int size){int res;String label="";
 switch(key){case "‹":res=R.drawable.glass_back;break;case "›":res=R.drawable.glass_forward;break;case "⌂":res=R.drawable.glass_home;break;case "+":res=R.drawable.glass_add;break;default:res=R.drawable.glass_tabs;label=key;}
 Drawable glyph=v.getContext().getDrawable(res).mutate();int px=Ui.dp(v.getContext(),size);Drawable d=glyph;
 if(!label.isEmpty()){
 final String count=label;
 d=new Drawable(){final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
 @Override public void draw(android.graphics.Canvas canvas){android.graphics.Rect b=getBounds();glyph.setBounds(b);glyph.draw(canvas);int save=canvas.save();canvas.translate(b.left,b.top);canvas.scale(b.width()/24f,b.height()/24f);paint.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD));paint.setTextSize(9.5f);paint.setTextAlign(android.graphics.Paint.Align.CENTER);paint.setStrokeWidth(1.8f);paint.setStyle(android.graphics.Paint.Style.STROKE);paint.setColor(0xff111d2c);canvas.drawText(count,10,15.9f,paint);paint.setStyle(android.graphics.Paint.Style.FILL);paint.setColor(android.graphics.Color.WHITE);canvas.drawText(count,10,15.9f,paint);canvas.restoreToCount(save);}
 @Override public void setAlpha(int alpha){glyph.setAlpha(alpha);invalidateSelf();}
 @Override public void setColorFilter(android.graphics.ColorFilter filter){glyph.setColorFilter(filter);invalidateSelf();}
 @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
 };
 }
 d.setBounds(0,0,px,px);v.setText("");v.setGravity(Gravity.CENTER);v.setCompoundDrawablePadding(0);v.setCompoundDrawables(null,d,null,null);
 }
 static void apply(TextView v,String key,int color,int size){int res;switch(key){case "‹":res=R.drawable.premium_back;break;case "›":res=R.drawable.premium_forward;break;case "⌂":res=R.drawable.premium_home;break;case "+":res=R.drawable.premium_add;break;case "↓":res=R.drawable.premium_download;break;case "↻":res=R.drawable.premium_reload;break;case "⬡":res=R.drawable.premium_shield;break;case "⚡":res=R.drawable.premium_bolt;break;case "▶":res=R.drawable.premium_play;break;case "▦":res=R.drawable.premium_grid;break;case "⌕":res=R.drawable.premium_search;break;case "◷":res=R.drawable.premium_history;break;case "☆":res=R.drawable.premium_star;break;case "★":res=R.drawable.premium_star;break;case "▣":res=R.drawable.premium_screen;break;case "▯":res=R.drawable.premium_mobile;break;case "✦":res=R.drawable.premium_theme;break;case "↗":res=R.drawable.premium_share;break;case "⚙":res=R.drawable.premium_settings;break;case "⇩":res=R.drawable.premium_download;break;case "↧":res=R.drawable.premium_download;break;case "▤":res=R.drawable.premium_screen;break;default:return;}
 Drawable d=v.getContext().getDrawable(res).mutate();d.setTint(color);int px=Ui.dp(v.getContext(),size);d.setBounds(0,0,px,px);v.setText("");v.setGravity(Gravity.CENTER);v.setCompoundDrawables(null,d,null,null);v.setContentDescription(key);
 }
}
