package com.srcreation.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.*;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.webkit.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Origin-scoped, write-only generated-file transport. No file reads or native commands exposed. */
final class GeneratedDownloads {
    private static final long MAX=128L*1024*1024;
    private static final int CHUNK=64*1024;
    private final Activity activity; private final WebView web; private final java.util.function.Consumer<String> rawFallback;
    private final Handler main=new Handler(Looper.getMainLooper());
    private long lastTouch=-1; private Job job;
    private static int activeJobs=0; // UI thread, across all tabs
    private static final int MAX_JOBS=2;
    private static final class Job {
        final String id,origin,name,mime;final long size;final JavaScriptReplyProxy reply;
        long offset;File file;OutputStream out;boolean accepted;
        Job(String i,String o,String n,String m,long s,JavaScriptReplyProxy r){id=i;origin=o;name=n;mime=m;size=s;reply=r;}
    }
    private GeneratedDownloads(Activity a,WebView w,java.util.function.Consumer<String> fallback){activity=a;web=w;rawFallback=fallback;}
    static GeneratedDownloads install(Activity a,WebView w,java.util.function.Consumer<String> fallback){
        if(!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)||!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER))return null;
        GeneratedDownloads handler=new GeneratedDownloads(a,w,fallback);
        try(InputStream in=a.getAssets().open("sr-generated-download.js");ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);
            Set<String> origins=Collections.singleton("*"); // reject opaque/non-HTTP origins in callback
            WebViewCompat.addWebMessageListener(w,"SrGeneratedFiles",origins,(view,message,sourceOrigin,isMainFrame,reply)->{try{handler.receive(message.getData(),sourceOrigin,isMainFrame,reply);}catch(RuntimeException ignored){}});
            try{WebViewCompat.addDocumentStartJavaScript(w,new String(bytes.toByteArray(),StandardCharsets.UTF_8),origins);}catch(RuntimeException e){WebViewCompat.removeWebMessageListener(w,"SrGeneratedFiles");throw e;}
            w.setOnTouchListener((v,event)->{if(event.getActionMasked()==MotionEvent.ACTION_UP)handler.lastTouch=SystemClock.elapsedRealtime();return false;});
            return handler;
        }catch(Exception e){return null;}
    }
    private boolean visible(){return !activity.isFinishing()&&!activity.isDestroyed()&&web.isShown()&&activity.hasWindowFocus();}
    private void toast(String s){Toast.makeText(activity.getApplicationContext(),s,Toast.LENGTH_LONG).show();}
    private void send(JavaScriptReplyProxy reply,String op,String id,long offset){try{reply.postMessage(new JSONObject().put("op",op).put("id",id).put("offset",offset).toString());}catch(Exception ignored){}}
    private final Runnable timeout=()->cancel("Generated file interrupted. Export it again.");
    private void arm(){main.removeCallbacks(timeout);main.postDelayed(timeout,60000);}
    private void receive(String raw,Uri source,boolean mainFrame,JavaScriptReplyProxy reply){
        if(raw==null||raw.length()>100000||source==null||source.getHost()==null||!("https".equals(source.getScheme())||"http".equals(source.getScheme())))return;
        try{
            JSONObject msg=new JSONObject(raw);String op=msg.optString("op"),id=msg.optString("id"),origin=source.toString();
            if("notice".equals(op)){if(visible()&&recentTouch()){
                String rawUrl=FileDownloadLinks.githubFileView(web.getUrl()),requested=msg.optString("name");
                if(mainFrame&&"github.com".equalsIgnoreCase(source.getHost())&&rawUrl!=null&&!requested.isEmpty()&&FileDownloadLinks.githubBlobFallback(rawUrl,requested)){lastTouch=-1;rawFallback.accept(rawUrl);}
                else toast("Generated file unavailable. Export again on the original page.");
            }return;}
            if(!id.matches("[A-Za-z0-9-]{1,80}"))return;
            if("begin".equals(op)){
                long size=msg.optLong("size",-1);
                if(job!=null||activeJobs>=MAX_JOBS||!visible()||size<0||size>MAX){send(reply,"end",id,0);return;}
                String mime=InlineDownload.cleanMime(msg.optString("mime"));
                String name=InlineDownload.generatedName(msg.optString("name"),mime);
                Job next=new Job(id,origin,name,mime,size,reply);job=next;activeJobs++;arm();
                if(mainFrame&&recentTouch()){lastTouch=-1;accept(next);}
                else new AlertDialog.Builder(activity).setTitle("Save generated file?").setMessage(name+"\nFrom: "+source.getHost()+"\n"+DownloadsActivity.size(size)).setPositiveButton("Save",(d,i)->accept(next)).setNegativeButton("Cancel",(d,i)->{if(job==next)cancel(null);}).setOnCancelListener(d->{if(job==next)cancel(null);}).show();
                return;
            }
            Job j=job;
            if(j==null||!j.accepted||!j.id.equals(id)||!j.origin.equals(origin)||j.reply!=reply)return;
            if("abort".equals(op)){cancel("Generated file read failed. Export again.");return;}
            if(!"chunk".equals(op)||msg.optLong("offset",-1)!=j.offset)return;
            byte[] bytes=Base64.decode(msg.getString("data"),Base64.DEFAULT);
            if(bytes.length!=Math.min((long)CHUNK,j.size-j.offset))throw new IOException("Invalid generated file chunk");
            j.out.write(bytes);j.offset+=bytes.length;
            if(j.offset==j.size)finish(j);else{arm();send(j.reply,"next",j.id,j.offset);}
        }catch(Exception e){if(job!=null&&job.reply==reply)cancel("Cannot save generated file. Export again.");}
    }
    private boolean recentTouch(){return lastTouch>=0&&SystemClock.elapsedRealtime()-lastTouch<60000;}
    private void accept(Job j){if(job!=j)return;try{j.file=File.createTempFile("sr-generated-",".part",activity.getCacheDir());j.out=new BufferedOutputStream(new FileOutputStream(j.file));j.accepted=true;toast("Saving: "+j.name);if(j.size==0)finish(j);else{arm();send(j.reply,"next",j.id,0);}}catch(IOException e){cancel("Cannot create temporary file");}}
    private void finish(Job j){try{j.out.close();j.out=null;}catch(IOException e){cancel("Cannot finish generated file");return;}release(j);InlineDownload.publish(activity.getApplicationContext(),j.file,j.name,j.mime,j.size);}
    private void release(Job j){main.removeCallbacks(timeout);job=null;activeJobs--;send(j.reply,"end",j.id,j.offset);}
    void cancel(String reason){Job j=job;if(j==null)return;release(j);try{if(j.out!=null)j.out.close();}catch(IOException ignored){}if(j.file!=null)j.file.delete();if(reason!=null){DownloadService.recordInlineFailure(activity.getApplicationContext(),j.name,j.mime,reason);toast(reason);}}
}
