package com.srcreation.browser;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Shared speed policy for every authorized video page, including bulk downloads. */
final class VideoSpeedPolicy {
    private VideoSpeedPolicy() {}
    static int connections(int configured) { return Math.max(1, Math.min(32, configured)); }
    static boolean turbo(int configured) { return connections(configured)>8; }
    static int fragments(int configured, boolean compatibility) { return compatibility?Math.min(8,connections(configured)):connections(configured); }
    static Map<String,String> options(int configured, boolean youtube, boolean compatibility) {
        Map<String,String> opts=new LinkedHashMap<>();
        opts.put("--concurrent-fragments",Integer.toString(fragments(configured,compatibility)));
        opts.put("--buffer-size","256K");
        // Do not publish incomplete video when a fragment fails.
        opts.put("--abort-on-unavailable-fragments",null);
        if(turbo(configured)&&!compatibility){
            // Native HTTP uses sequential chunks, not simultaneous connections.
            opts.put("--http-chunk-size","8M");
            // Keep the quality, language and codec preferences ahead of transport preference.
            opts.put("--format-sort","lang,quality,res,fps,hdr:12,vcodec,channels,acodec,proto:"+(youtube?"http_dash_segments":"m3u8"));
            // yt-dlp's documented conversion of eligible YouTube HTTP formats to DASH fragments.
            if(youtube)opts.put("--extractor-args","youtube:formats=dashy");
        }
        return opts;
    }
    static boolean compatibilityRetry(int configured,String error){
        if(!turbo(configured)||error==null)return false;
        String s=error.toLowerCase(Locale.ROOT);
        // Do not retry a rejected, throttled or protected resource with a different transport.
        if(s.matches("(?s).*(\\b(401|403|429|503)\\b|forbidden|unauthorized|drm|private video|sign in|login required|rate limit|too many requests|cancelled|canceled).*"))return false;
        return s.contains("requested format is not available")||s.contains("no video formats found")||s.contains("http error 416")||s.contains("range not satisfiable")||s.contains("invalid content-range");
    }
    static String label(int configured,boolean compatibility){
        return (compatibility?"Compatibility":turbo(configured)?"Turbo":"Standard")+" • up to "+fragments(configured,compatibility)+" parallel fragments";
    }
}
