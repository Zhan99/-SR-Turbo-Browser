const assert=require('assert/strict');const fs=require('fs');const vm=require('vm');
let callback, nativeClicks=0, blobs=new Map(), msgs=[], seq=0; const timers=[];
class Anchor {constructor(h,n){this.href=h;this.name=n;}hasAttribute(k){return k==='download'&&this.name!==null;}getAttribute(k){return this.name;}click(){nativeClicks++;}}
const U={createObjectURL(b){const u='blob:https://site.test/'+ ++seq;blobs.set(u,b);return u;},revokeObjectURL(u){blobs.delete(u);}};
const bridge={postMessage(s){msgs.push(JSON.parse(s));}};
const ctx={Blob,Uint8Array,btoa,URL:U,HTMLAnchorElement:Anchor,location:{protocol:'https:'},crypto:require('crypto').webcrypto,document:{addEventListener(_,f){callback=f;}},SrGeneratedFiles:bridge,fetch:async u=>{if(!blobs.has(u))throw Error('revoked');return {ok:true,blob:async()=>blobs.get(u)};},setTimeout:f=>timers.push(f)};ctx.window=ctx;
vm.runInNewContext(fs.readFileSync(process.argv[2],'utf8'),ctx);
const flush=()=>new Promise(r=>setImmediate(r));
async function get(b){let offset=0,arr=[];while(offset<b.size){await bridge.onmessage({data:JSON.stringify({op:'next',id:b.id,offset})});const chunk=msgs.shift();assert.equal(chunk.op,'chunk');assert.equal(chunk.offset,offset);const part=Buffer.from(chunk.data,'base64');arr.push(part);offset+=part.length;}await bridge.onmessage({data:JSON.stringify({op:'end',id:b.id})});return Buffer.concat(arr);}
(async()=>{const data=Buffer.alloc(150123);for(let i=0;i<data.length;i++)data[i]=i%251;
let u=U.createObjectURL(new Blob([data],{type:'application/pdf'}));new Anchor(u,'test.pdf').click();U.revokeObjectURL(u);assert.equal(blobs.has(u),false);let b=msgs.shift();assert.equal(b.op,'begin');assert.equal(b.name,'test.pdf');assert.equal(b.mime,'application/pdf');assert.deepEqual(await get(b),data);assert.ok(ctx.__srGeneratedBlob(u));timers.shift()();assert.equal(ctx.__srGeneratedBlob(u),undefined);
u=U.createObjectURL(new Blob([data],{type:'application/zip'}));const a=new Anchor(u,'source.zip');let prevented=false;callback({defaultPrevented:false,button:0,composedPath:()=>[a],preventDefault(){prevented=true;}});assert.ok(prevented);U.revokeObjectURL(u);b=msgs.shift();assert.equal(b.name,'source.zip');assert.deepEqual(await get(b),data);
new Anchor('https://site.test/file.zip','file.zip').click();assert.equal(nativeClicks,1);new Anchor('blob:https://site.test/plain',null).click();assert.equal(nativeClicks,2);
new Anchor('blob:https://site.test/missing','missing.pdf').click();await flush();assert.equal(msgs.shift().op,'notice');assert.equal(msgs.length,0);console.log('Generated files: detached anchor, immediate revoke, multi-chunk binary integrity, click interception, normal HTTP pass-through and missing blob passed');})().catch(e=>{console.error(e);process.exitCode=1;});
