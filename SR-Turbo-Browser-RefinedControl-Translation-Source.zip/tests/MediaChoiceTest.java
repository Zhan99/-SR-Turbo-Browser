package com.srcreation.browser;
public class MediaChoiceTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] a){String yt="https://www.youtube.com/watch?v=abcdefghijk",fb="https://www.facebook.com/reel/123";check(MediaChoice.VALUES.length==5&&MediaChoice.LABELS.length==5);for(int n:new int[]{360,480,720,1080}){check(MediaChoice.normalize(n)==n);check(MediaChoice.format(yt,n).contains("height<="+n));check(MediaChoice.extension(n).equals("mp4"));}check(MediaChoice.normalize(-1)==-1);check(MediaChoice.format(yt,-1).equals("bestaudio/best"));check(MediaChoice.format(fb,-1).equals("bestaudio/best"));check(MediaChoice.mime(-1).equals("audio/mpeg"));check(MediaChoice.resultMime("a.MP3").equals("audio/mpeg"));check(MediaChoice.resultMime("a.mp4").equals("video/mp4"));check(MediaChoice.normalize(0)==720);System.out.println("MP3 / MP4 selection, format and MIME tests passed");}
}
