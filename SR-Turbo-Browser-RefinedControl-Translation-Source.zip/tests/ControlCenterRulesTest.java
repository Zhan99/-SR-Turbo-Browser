package com.srcreation.browser;
final class ControlCenterRulesTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args){
        check(ControlCenterRules.matches("", "DISPLAY", "Page zoom"));
        check(ControlCenterRules.matches("  ZOOM ", "DISPLAY", "Page zoom"));
        check(ControlCenterRules.matches("display zoom", "DISPLAY", "Page zoom"));
        check(!ControlCenterRules.matches("display audio", "DISPLAY", "Page zoom"));
        check(ControlCenterRules.matches("privacy", "APPEARANCE & PRIVACY", "Advanced ad blocker"));
        check(!ControlCenterRules.matches("xyz", null, null));
        check(ControlCenterRules.delay(-1)==0);check(ControlCenterRules.delay(3)==72);check(ControlCenterRules.delay(500)==168);
        DownloadBadge d=new DownloadBadge();check(ControlCenterRules.transferLabel(d).equals("Idle"));d.add("Running",50,100);check(ControlCenterRules.transferLabel(d).equals("50%"));d.add("Running",0,-1);check(ControlCenterRules.transferLabel(d).equals("…"));
        System.out.println("Control center search, animation delay and live transfer label: 12 checks passed");
    }
}
