package com.srcreation.browser;
public class DownloadBadgeTest {
 static void eq(String a,String b){if(!a.equals(b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){DownloadBadge b=new DownloadBadge();eq(b.label(),"");b.add("Completed",100,100);b.add("Paused",50,100);b.add("Failed",10,100);eq(b.label(),"");b.add("Running",40,100);eq(b.label(),"40%");b.add("Running",20,200);eq(b.label(),"20%");b.add("Queued",0,-1);eq(b.label(),"…");b=new DownloadBadge();b.add("Saving",100,100);eq(b.label(),"100%");b=new DownloadBadge();b.video("Downloading",25,100);eq(b.label(),"25%");b=new DownloadBadge();b.video("Preparing",0,-1);eq(b.label(),"…");b=new DownloadBadge();b.video("Saving",100,100);eq(b.label(),"…");b=new DownloadBadge();b.add("Running",Long.MAX_VALUE,Long.MAX_VALUE);b.add("Running",Long.MAX_VALUE,Long.MAX_VALUE);eq(b.label(),"100%");System.out.println("Download badge: idle, terminal, weighted, unknown, saving, stream, large byte totals passed");}
}
