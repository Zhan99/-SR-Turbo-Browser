package com.srcreation.browser;
public final class DisplaySpaceTest {
    static void eq(int expected,int actual){if(expected!=actual)throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        eq(0,DisplaySpace.top(true,24,0));
        eq(0,DisplaySpace.top(true,48,0));
        eq(24,DisplaySpace.top(false,24,0));
        eq(32,DisplaySpace.top(true,24,32));
        eq(32,DisplaySpace.top(false,24,32));
        eq(24,DisplaySpace.bottom(24,0,0));
        eq(300,DisplaySpace.bottom(24,300,0));
        eq(32,DisplaySpace.bottom(24,0,32));
        eq(0x21123456,DisplaySpace.glass(0xff123456));
        eq(0,DisplaySpace.opacity(-5));eq(100,DisplaySpace.opacity(110));
        eq(0,DisplaySpace.barFill(0xff123456,true,0)>>>24);
        eq(0,DisplaySpace.chipFill(0xffffffff,true,0)>>>24);
        eq(0,DisplaySpace.border(0)>>>24);
        eq(128,DisplaySpace.barFill(0xff123456,true,50)>>>24);
        eq(255,DisplaySpace.barFill(0xff123456,true,100)>>>24);
        eq(255,DisplaySpace.barFill(0xff123456,false,0)>>>24);
        eq(33,DisplaySpace.barFill(0xff123456,true,13)>>>24);
        for(int n=0;n<100;n++){if((DisplaySpace.alpha(0xff123456,n)>>>24)>(DisplaySpace.alpha(0xff123456,n+1)>>>24))throw new AssertionError("opacity must be monotonic");}
        eq(45,DisplaySpace.DOCK_HEIGHT);
        int[] centre=DisplaySpace.toolbar(true,360,0,170,190,4,104,128);
        eq(0,centre[0]);eq(162,centre[3]);
        int[] left=DisplaySpace.toolbar(true,360,0,0,25,4,104,128);eq(29,left[1]);
        int[] right=DisplaySpace.toolbar(true,360,0,335,360,4,104,128);eq(29,right[2]);
        eq(DisplaySpace.FALLBACK,DisplaySpace.toolbar(true,360,0,90,260,4,104,128)[0]);
        eq(0,DisplaySpace.toolbar(false,360,0,170,190,4,104,128)[3]);
        System.out.println("Display space and opacity: all checks passed");
    }
}
