package com.srcreation.browser;
import java.util.Map;
final class VideoSpeedPolicyTest {
    static int n;
    static void check(boolean value){n++;if(!value)throw new AssertionError("Video speed test "+n);}
    public static void main(String[] args){
        Map<String,String> yt=VideoSpeedPolicy.options(32,true,false);
        check(yt.get("--concurrent-fragments").equals("32"));
        check(yt.get("--extractor-args").equals("youtube:formats=dashy"));
        check(yt.get("--format-sort").endsWith("proto:http_dash_segments"));
        check(yt.get("--http-chunk-size").equals("8M"));
        check(yt.get("--buffer-size").equals("256K"));
        check(yt.containsKey("--abort-on-unavailable-fragments"));
        Map<String,String> other=VideoSpeedPolicy.options(32,false,false);
        check(other.get("--concurrent-fragments").equals("32"));
        check(!other.containsKey("--extractor-args"));
        check(other.get("--format-sort").endsWith("proto:m3u8"));
        Map<String,String> fallback=VideoSpeedPolicy.options(32,true,true);
        check(fallback.get("--concurrent-fragments").equals("8"));
        check(!fallback.containsKey("--extractor-args")&&!fallback.containsKey("--format-sort")&&!fallback.containsKey("--http-chunk-size"));
        check(VideoSpeedPolicy.options(8,true,false).equals(fallback));
        check(VideoSpeedPolicy.fragments(1,true)==1);
        check(VideoSpeedPolicy.fragments(0,false)==1);
        check(VideoSpeedPolicy.fragments(100,false)==32);
        check(VideoSpeedPolicy.fragments(16,false)==16);
        check(VideoSpeedPolicy.compatibilityRetry(32,"Requested format is not available"));
        check(VideoSpeedPolicy.compatibilityRetry(32,"HTTP Error 416"));
        check(!VideoSpeedPolicy.compatibilityRetry(8,"HTTP Error 416"));
        for(String err:new String[]{"403 Forbidden","HTTP 429","HTTP 503","HTTP 401","DRM", "Sign in", "Cancelled"})check(!VideoSpeedPolicy.compatibilityRetry(32,err+": requested format is not available" ));
        check(!VideoSpeedPolicy.compatibilityRetry(32,"unknown failure"));
        check(!VideoSpeedPolicy.compatibilityRetry(32,null));
        check(VideoSpeedPolicy.label(32,false).contains("32"));
        System.out.println("Video speed policy: "+n+" checks passed");
    }
}
