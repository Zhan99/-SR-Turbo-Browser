package com.srcreation.browser;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
public class PageToolsTest {
    static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args){if(args.length>0){System.out.println(PageTools.viewport(true));System.out.println(PageTools.viewport(false));return;}
        check(PageTools.CODES.length==PageTools.LANGUAGES.length);check(PageTools.language("unknown").equals("bn"));check(PageTools.language("zh-CN").equals("zh-CN"));
        String u="https://example.org/article?x=1&y=2#section";check(PageTools.canTranslate(u));String out=PageTools.translateUrl(u,"en");check(out.startsWith("https://translate.google.com/translate?sl=auto&tl=en&u="));check(URLDecoder.decode(out.split("&u=",2)[1],StandardCharsets.UTF_8).equals("https://example.org/article?x=1&y=2"));
        for(String bad:new String[]{"about:blank","file:///tmp/a","https://u:p@example.org/","https://127.0.0.1/","http://localhost/","http://test.local/","https://accounts.google.com/","https://mail.google.com/","https://translate.google.com/","https://example-org.translate.goog/"})check(!PageTools.canTranslate(bad));
        check(PageTools.textSize(0)==50);check(PageTools.textSize(123)==123);check(PageTools.textSize(300)==200);check(PageTools.translatorHome("bn").contains("tl=bn"));System.out.println("PageToolsTest: translation URL, language and zoom rules passed");}
}
