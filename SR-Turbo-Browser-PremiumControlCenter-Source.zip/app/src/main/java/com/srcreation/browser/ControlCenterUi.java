package com.srcreation.browser;

import android.app.Dialog;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;

/** A lightweight, theme-aware dashboard using Android native views only. */
final class ControlCenterUi {
    final BrowserActivity a;
    final Dialog dialog;
    final boolean animate;
    final Handler handler=new Handler(Looper.getMainLooper());
    LinearLayout dashboard;
    TextView tabMetric, transferMetric, protectionMetric, pageStatus, noResults;
    EditText searchBox; ScrollView scrollView;
    String query(){return searchBox==null?"":searchBox.getText().toString();}
    int scrollPosition(){return scrollView==null?0:scrollView.getScrollY();}
    final Runnable tick=new Runnable(){public void run(){if(!dialog.isShowing()||a.isDestroyed()||a.isFinishing())return;update();handler.postDelayed(this,750);}};
    ControlCenterUi(BrowserActivity activity,Dialog d,boolean animations){a=activity;dialog=d;animate=animations&&android.animation.ValueAnimator.areAnimatorsEnabled();}
    int dp(float x){return Ui.dp(a,x);}
    TextView label(String text,int size,int color,boolean bold){return Ui.text(a,text,size,color,bold);}
    void header(LinearLayout shell,boolean settings){
        LinearLayout head=Ui.row(a);head.setPadding(dp(4),dp(2),dp(2),dp(12));
        LinearLayout title=Ui.column(a);TextView brand=label("SR TURBO  •  "+(a.privateMode()?"PRIVATE":"BROWSER"),10,a.accent(),true);brand.setLetterSpacing(.16f);title.addView(brand);title.addView(label(settings?"Settings":"Control center",25,a.fg(),true));head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView close=Ui.button(a,"×",a.fg(),a.card(),dialog::dismiss);close.setTextSize(22);close.setContentDescription("Close control center");head.addView(close,new LinearLayout.LayoutParams(dp(48),dp(48)));press(close);shell.addView(head);
    }
    void buildDashboard(LinearLayout body,boolean settings){
        dashboard=Ui.column(a);Ui.pad(dashboard,a,14);dashboard.setBackground(Ui.gradient(a,a.palette().nav,a.palette().toolbar,24));
        LinearLayout header=Ui.row(a);TextView live=label("●  LIVE OVERVIEW",10,a.palette().highlight,true);live.setLetterSpacing(.09f);header.addView(live,new LinearLayout.LayoutParams(0,-2,1));header.addView(label(a.displayMode.title,11,Color.WHITE,true));dashboard.addView(header);
        pageStatus=label("",15,Color.WHITE,true);pageStatus.setSingleLine(true);pageStatus.setEllipsize(TextUtils.TruncateAt.END);pageStatus.setPadding(0,dp(9),0,dp(12));dashboard.addView(pageStatus);
        LinearLayout metrics=Ui.row(a);tabMetric=metric(metrics,"TABS");transferMetric=metric(metrics,"TRANSFER");protectionMetric=metric(metrics,"PROTECTION");dashboard.addView(metrics);body.addView(dashboard);
        if(!settings){
            LinearLayout row1=Ui.row(a);quick(row1,R.drawable.premium_grid,"Tabs",a::tabSwitcher);quick(row1,R.drawable.premium_download,"Downloads",a::downloads);quick(row1,R.drawable.premium_globe,"Translate",a::translatePage);body.addView(row1);
            LinearLayout row2=Ui.row(a);quick(row2,R.drawable.premium_search,"Zoom",a::pageZoomDialog);quick(row2,R.drawable.premium_shield,"Protection",a::adSettings);quick(row2,R.drawable.premium_settings,"Settings",a::settings);body.addView(row2);
        }
        update();
    }
    TextView metric(LinearLayout host,String title){LinearLayout cell=Ui.column(a);cell.setGravity(Gravity.CENTER);cell.setPadding(dp(3),dp(9),dp(3),dp(9));cell.setBackground(Ui.bg(0x22ffffff,14,a));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(2),0,dp(2),0);host.addView(cell,p);TextView value=label("—",17,Color.WHITE,true);value.setSingleLine(true);cell.addView(value);TextView caption=label(title,9,0xffe1ebf5,true);caption.setSingleLine(true);cell.addView(caption);return value;}
    void quick(LinearLayout host,int icon,String title,Runnable action){TextView b=label(title,12,a.fg(),true);android.graphics.drawable.Drawable glyph=a.getDrawable(icon).mutate();glyph.setTint(a.accent());glyph.setBounds(0,0,dp(24),dp(24));b.setCompoundDrawables(null,glyph,null,null);b.setCompoundDrawablePadding(dp(6));b.setGravity(Gravity.CENTER);b.setPadding(dp(2),dp(8),dp(2),dp(8));Ui.ripple(b,a,a.card(),18,a.line());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(70),1);p.setMargins(dp(3),dp(7),dp(3),0);host.addView(b,p);b.setFocusable(true);b.setOnClickListener(v->{dialog.dismiss();action.run();});press(b);}
    void update(){if(pageStatus==null)return;BrowserActivity.Tab t=a.active();pageStatus.setText(t==null||BrowserActivity.HOME.equals(t.url)?"Home  •  "+(a.turbo()?"Turbo on":"Standard speed"):t.title+"  •  "+(t.percent<100?t.percent+"%":"Ready"));tabMetric.setText(a.tabs.size()+"/20");boolean protectedPage=t!=null&&a.adProtection!=null&&a.adProtection.any(t.url);protectionMetric.setText(protectedPage?"ON":"OFF");if(a.privateMode()){transferMetric.setText("Private");return;}DownloadBadge meter=new DownloadBadge();synchronized(DownloadService.class){DownloadService.load(a);for(DownloadService.Task task:DownloadService.tasks.values())meter.add(task.state,task.bytes,task.total);}if(meter.count==0&&YouTubeDownloadService.busy)meter.video(YouTubeDownloadService.state,YouTubeDownloadService.bytes,YouTubeDownloadService.total);transferMetric.setText(ControlCenterRules.transferLabel(meter));}
    void search(LinearLayout shell,LinearLayout body,ScrollView scroll,int firstRow){
        LinearLayout bar=Ui.row(a);bar.setBackground(Ui.surface(a,a.card(),16,a.line()));bar.setPadding(dp(10),0,dp(4),0);TextView icon=label("",16,a.accent(),true);PremiumIcons.apply(icon,"⌕",a.accent(),20);bar.addView(icon,new LinearLayout.LayoutParams(dp(24),dp(44)));searchBox=new EditText(a);searchBox.setSingleLine(true);searchBox.setTextSize(14);searchBox.setTextColor(a.fg());searchBox.setHintTextColor(a.muted());searchBox.setHint("Find a control…");searchBox.setContentDescription("Search control center");searchBox.setBackgroundColor(Color.TRANSPARENT);bar.addView(searchBox,new LinearLayout.LayoutParams(0,dp(48),1));TextView clear=Ui.button(a,"×",a.muted(),a.card(),()->searchBox.setText(""));clear.setContentDescription("Clear search");bar.addView(clear,new LinearLayout.LayoutParams(dp(44),dp(44)));shell.addView(bar,1);noResults=label("No matching controls",15,a.muted(),true);Ui.pad(noResults,a,16);noResults.setGravity(Gravity.CENTER);body.addView(noResults);noResults.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){filter(body,firstRow,s.toString());scroll.scrollTo(0,0);}public void afterTextChanged(Editable e){}});
    }
    void filter(LinearLayout body,int first,String query){
        for(int i=0;i<first;i++)body.getChildAt(i).setVisibility(query.trim().isEmpty()?View.VISIBLE:View.GONE);
        View heading=null;String section="";int visible=0;
        for(int i=first;i<body.getChildCount()-1;i++){View child=body.getChildAt(i);if(child instanceof TextView){heading=child;section=((TextView)child).getText().toString();heading.setVisibility(View.GONE);continue;}Object tag=child.getTag();boolean show=ControlCenterRules.matches(query,section,tag==null?"":tag.toString());child.setVisibility(show?View.VISIBLE:View.GONE);if(show){visible++;if(heading!=null)heading.setVisibility(View.VISIBLE);}}
        noResults.setVisibility(visible==0?View.VISIBLE:View.GONE);
    }
    void press(View v){if(!animate)return;v.setOnTouchListener((view,event)->{int action=event.getActionMasked();if(action==MotionEvent.ACTION_DOWN)view.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start();else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)view.animate().scaleX(1).scaleY(1).setDuration(140).start();return false;});}
    void show(LinearLayout shell,LinearLayout body,ScrollView scroll,int firstRow,String query,int scrollPosition,boolean restoring){
        scrollView=scroll;
        search(shell,body,scroll,firstRow);for(int i=firstRow;i<body.getChildCount();i++)if(body.getChildAt(i) instanceof LinearLayout)press(body.getChildAt(i));
        shell.setFocusableInTouchMode(true);shell.requestFocus();dialog.setContentView(shell);dialog.setOwnerActivity(a);dialog.setOnDismissListener(d->{handler.removeCallbacks(tick);if(a.controlDialog==dialog){a.controlDialog=null;a.currentControlUi=null;}});dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setDimAmount(.46f);w.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);android.util.DisplayMetrics dm=a.getResources().getDisplayMetrics();w.setLayout(Math.min(dm.widthPixels-dp(16),dp(500)),Math.min(dm.heightPixels-dp(64),dp(850)));w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);WindowManager.LayoutParams p=w.getAttributes();p.y=dp(8);w.setAttributes(p);}
        if(restoring){searchBox.setText(query);scroll.post(()->scroll.scrollTo(0,scrollPosition));}
        if(animate&&!restoring){shell.setAlpha(0f);shell.setTranslationY(-dp(18));shell.setScaleX(.97f);shell.setScaleY(.97f);shell.animate().alpha(1f).translationY(0).scaleX(1).scaleY(1).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();for(int i=0;i<Math.min(firstRow+3,body.getChildCount()-1);i++){View child=body.getChildAt(i);child.setAlpha(0f);child.setTranslationY(dp(9));child.animate().alpha(1f).translationY(0).setStartDelay(ControlCenterRules.delay(i)).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();}}
        handler.post(tick);
    }
}
