package com.srcreation.browser;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;

/** A dedicated in-app screen; returning to browser does not stop the service. */
public class YouTubeDownloadsActivity extends Activity {
    final Handler handler=new Handler(Looper.getMainLooper());
    EditText url;Spinner quality;CheckBox permission;TextView state,detail,speed,eta,percent,start,update,cancel,open;ProgressBar bar;boolean dark;
    int fg(){return dark?0xffe7eff8:Ui.INK;}int paper(){return dark?0xff152439:Ui.PAPER;}int card(){return dark?0xff24364c:0xffffffff;}int muted(){return dark?0xffafc2d7:Ui.MUTED;}
    final int[] heights={360,480,720,1080};
    @Override public void onCreate(Bundle b){super.onCreate(b);YouTubeDownloadService.restore(this);dark=getSharedPreferences("browser",0).getBoolean("dark",false);
        LinearLayout root=Ui.column(this);root.setBackgroundColor(paper());LinearLayout header=Ui.row(this);Ui.pad(header,this,12);header.setBackgroundColor(Ui.NAV);header.addView(Ui.button(this,"‹",0xffffffff,Ui.NAV,this::finish));LinearLayout titles=Ui.column(this);titles.addView(Ui.text(this,"YouTube downloads",22,0xffffffff,true));titles.addView(Ui.text(this,"SR TURBO  /  VIDEO CENTER",11,Ui.MINT,true));header.addView(titles);root.addView(header);
        ScrollView sc=new ScrollView(this);LinearLayout panel=Ui.column(this);Ui.pad(panel,this,16);sc.addView(panel);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        panel.addView(Ui.text(this,"Save an authorized video",18,fg(),true));panel.addView(Ui.text(this,"Use only where YouTube and applicable rights holders permit downloading. No login cookies, DRM bypass, private or live videos.",13,muted(),false));
        url=new EditText(this);url.setSingleLine(true);url.setTextColor(fg());url.setHintTextColor(muted());url.setHint("YouTube video / Shorts link");url.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);url.setText(getIntent().getStringExtra("url"));panel.addView(url,new LinearLayout.LayoutParams(-1,-2));
        quality=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"Up to 360p","Up to 480p","Up to 720p (HD)","Up to 1080p (Full HD)"});adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);quality.setAdapter(adapter);quality.setSelection(2);panel.addView(quality,new LinearLayout.LayoutParams(-1,Ui.dp(this,48)));
        permission=new CheckBox(this);permission.setText("I have permission to download this video.");permission.setTextColor(fg());panel.addView(permission);
        start=Ui.button(this,"↓  Download MP4",Ui.NAV,Ui.MINT,()->{String link=YouTubeLinks.canonical(url.getText().toString());if(link==null){toast("Enter a valid single YouTube video URL");return;}if(!permission.isChecked()){toast("Confirm download permission first");return;}startJob(new Intent(this,YouTubeDownloadService.class).setAction(YouTubeDownloadService.START).putExtra("url",link).putExtra("quality",heights[quality.getSelectedItemPosition()]));});panel.addView(start);
        update=Ui.button(this,"↻  Update video engine",fg(),card(),()->new AlertDialog.Builder(this).setTitle("Update yt-dlp?").setMessage("Fetch the official stable engine release from GitHub. Use this if YouTube changes break downloads.").setNegativeButton("Cancel",null).setPositiveButton("Update",(d,i)->startJob(new Intent(this,YouTubeDownloadService.class).setAction(YouTubeDownloadService.UPDATE))).show());panel.addView(update);
        LinearLayout box=Ui.column(this);Ui.pad(box,this,16);box.setBackground(Ui.bg(card(),18,this));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=Ui.dp(this,16);panel.addView(box,bp);
        state=Ui.text(this,"Ready",18,fg(),true);box.addView(state);detail=Ui.text(this,"",13,muted(),false);box.addView(detail);percent=Ui.text(this,"",14,fg(),true);box.addView(percent);bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);box.addView(bar,new LinearLayout.LayoutParams(-1,Ui.dp(this,20)));speed=Ui.text(this,"",20,fg(),true);box.addView(speed);eta=Ui.text(this,"",15,fg(),true);box.addView(eta);box.addView(Ui.text(this,"Progress and ETA refer to the current video or audio stream, not merging or file saving.",12,muted(),false));
        cancel=Ui.button(this,"Cancel download",fg(),paper(),()->{try{startService(new Intent(this,YouTubeDownloadService.class).setAction(YouTubeDownloadService.CANCEL));}catch(Exception e){toast(e.getMessage());}});box.addView(cancel);
        open=Ui.button(this,"Open last saved video",Ui.NAV,Ui.MINT,()->{try{Uri u=Uri.parse(YouTubeDownloadService.resultUri);Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(u,"video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setClipData(ClipData.newRawUri("Video",u));startActivity(Intent.createChooser(i,"Open video"));}catch(Exception e){toast("File missing or no video player available");}});box.addView(open);
        panel.addView(Ui.text(this,"Saved files: Download/SR Turbo/YouTube. You may return to the browser while a transfer runs. One YouTube job at a time.",13,muted(),false));setContentView(root);refresh();
    }
    void startJob(Intent i){if(YouTubeDownloadService.busy)return;try{startForegroundService(i);start.setEnabled(false);update.setEnabled(false);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},32);}catch(Exception e){toast("Cannot start: "+e.getMessage());}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    final Runnable poll=new Runnable(){public void run(){refresh();handler.postDelayed(this,500);}};
    void refresh(){boolean busy=YouTubeDownloadService.busy;String s=YouTubeDownloadService.state;long b=YouTubeDownloadService.bytes,t=YouTubeDownloadService.total,r=YouTubeDownloadService.rate,e=YouTubeDownloadService.eta;state.setText(s.toUpperCase(java.util.Locale.ROOT));detail.setText(YouTubeDownloadService.detail);boolean downloading=s.equals("Downloading");percent.setText(downloading?(t>0?DownloadsActivity.size(b)+" / "+DownloadsActivity.size(t)+" • "+YouTubeDownloadService.percent()+"%":"Waiting for stream size…"):s.equals("Completed")?"100% · "+YouTubeDownloadService.resultName:"");bar.setIndeterminate(busy&&(!downloading||t<=0));bar.setProgress(s.equals("Completed")?100:YouTubeDownloadService.percent());speed.setText(downloading&&r>=0?DownloadsActivity.size(r)+"/s":"—");eta.setText(downloading?"Stream time left: "+YouTubeDownloadService.time(e):"");start.setEnabled(!busy);update.setEnabled(!busy);url.setEnabled(!busy);quality.setEnabled(!busy);permission.setEnabled(!busy);cancel.setVisibility(busy&&!s.equals("Updating")?View.VISIBLE:View.GONE);cancel.setEnabled(!YouTubeDownloadService.cancelled);open.setVisibility(YouTubeDownloadService.resultUri.isEmpty()?View.GONE:View.VISIBLE);}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(poll);handler.post(poll);}
    @Override protected void onPause(){handler.removeCallbacks(poll);super.onPause();}
}
