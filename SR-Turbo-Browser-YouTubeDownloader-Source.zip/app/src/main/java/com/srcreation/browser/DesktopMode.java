package com.srcreation.browser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Desktop display policy; the underlying renderer is still Android WebView. */
final class DesktopMode {
    enum Profile {
        MOBILE("Mobile mode", "MOBILE"),
        ORIGINAL("Desktop mode (original)", "DESKTOP"),
        NORMAL("Normal desktop mode", "NORMAL DESKTOP");
        final String title, badge;
        Profile(String title, String badge) { this.title=title; this.badge=badge; }
    }
    static Profile restore(String saved, boolean legacyDesktop) {
        if (saved != null) try { return Profile.valueOf(saved); } catch (IllegalArgumentException ignored) {}
        return legacyDesktop ? Profile.ORIGINAL : Profile.MOBILE;
    }
    static Profile effective(Profile selected, String url) {
        return GoogleLinks.isAccountSite(url) ? Profile.MOBILE : selected;
    }
    static boolean overview(Profile applied, boolean originalAutoZoom) {
        return applied == Profile.MOBILE || (applied == Profile.ORIGINAL && originalAutoZoom);
    }
    static boolean forceWideViewport(Profile applied, boolean overview, String url) {
        return applied == Profile.ORIGINAL && !overview && !GoogleLinks.isAccountSite(url);
    }
    static String label(Profile selected, Profile applied, boolean appliedOverview, boolean originalAutoZoom, String url) {
        if (selected != Profile.MOBILE && GoogleLinks.isAccountSite(url)) return selected.badge + " • ACCOUNT EXCEPTION";
        if (selected != applied || overview(selected,originalAutoZoom) != appliedOverview) return selected.badge + " • NEXT LOAD";
        return applied.badge;
    }
    private static final Pattern CHROME = Pattern.compile("\\bChrome/([0-9]+(?:\\.[0-9]+){0,3})\\b");
    static boolean effective(boolean enabled, String url) {
        return enabled && !GoogleLinks.isAccountSite(url);
    }
    /** Original WebView auto-fit: wide viewport plus load-with-overview mode. Mobile behavior is unchanged. */
    static boolean useOverview(boolean desktopApplied, boolean desktopAutoZoom) {
        return !desktopApplied || desktopAutoZoom;
    }
    static String agent(String actual, boolean desktop) {
        if (!desktop || actual == null) return actual;
        Matcher m = CHROME.matcher(actual);
        if (!m.find()) return actual;
        // Keep the real Chromium version and explicit WebView marker, not a fabricated newer version.
        return "Mozilla/5.0 (X11; Linux x86_64; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + m.group(1) + " Safari/537.36";
    }
    static String label(boolean enabled, boolean applied, String url) {
        if (enabled && GoogleLinks.isAccountSite(url)) return "DESKTOP • ACCOUNT EXCEPTION";
        if (enabled != applied) return enabled ? "DESKTOP • NEXT LOAD" : "MOBILE • NEXT LOAD";
        return applied ? "DESKTOP" : "";
    }
    // Only modify the document's presentation, not scripts, credentials, or storage.
    static final String WIDE_VIEWPORT = "(function(){if(!document.head)return;var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}m.setAttribute('content','width=1280');})();";
    private DesktopMode() {}
}
