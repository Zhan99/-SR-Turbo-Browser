package com.srcreation.browser;

import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import org.json.*;
import java.io.*;
import java.util.UUID;

/** User-requested blob/data files. No JavaScript-to-native bridge is exposed to websites. */
final class InlineDownload {
    static final long MAX=64L*1024*1024;
    static final int CHUNK=128*1024;
    final Context context; final WebView web; final Handler main=new Handler(Looper.getMainLooper());
    final String url,page,key="__sr_file_"+UUID.randomUUID().toString().replace("-",""),disposition,hint;
    File temp; OutputStream out; long size=-1,offset=0,deadline; String mime; boolean ended=false;
    static void start(Context c,WebView w,String u,String d,String m){
        if(!FileDownloadLinks.isInlineData(u)||u.length()>8L*1024*1024){Toast.makeText(c,"Generated file is too large",Toast.LENGTH_LONG).show();return;}
        new InlineDownload(c,w,u,d,m).begin();
    }
    InlineDownload(Context c,WebView w,String u,String d,String m){context=c.getApplicationContext();web=w;url=u;page=w.getUrl();disposition=d;hint=m;}
    void toast(String text){main.post(()->Toast.makeText(context,text,Toast.LENGTH_LONG).show());}
    boolean live(){try{return !ended&&page!=null&&page.equals(web.getUrl())&&web.isAttachedToWindow();}catch(Exception e){return false;}}
    final Runnable watchdog=new Runnable(){public void run(){if(ended)return;try{if(!live()||SystemClock.elapsedRealtime()>deadline){fail("Generated file expired or page closed. Try again.");return;}}catch(Exception e){fail("Generated file page closed");return;}main.postDelayed(this,1000);}};
    void begin(){
        if(!live()){fail("Keep the originating page open to save this file");return;}
        try{temp=File.createTempFile("sr-inline-",".part",context.getCacheDir());out=new FileOutputStream(temp);}catch(IOException e){fail("Cannot create temporary file");return;}
        deadline=SystemClock.elapsedRealtime()+30000;
        if(url.startsWith("data:")){try{int comma=url.indexOf(',');if(comma<5)throw new IOException("Invalid data URL");String meta=url.substring(5,comma);mime=meta.split(";",2)[0];byte[] body=decodeData(url.substring(comma+1));if(meta.toLowerCase(java.util.Locale.ROOT).endsWith(";base64"))body=Base64.decode(body,Base64.DEFAULT);size=body.length;out.write(body);offset=size;finish();}catch(Exception e){fail("Cannot save data file: "+e.getMessage());}return;}
        main.postDelayed(watchdog,1000);
        String k=JSONObject.quote(key),u=JSONObject.quote(url);
        String js="(function(){const k="+k+";const s={state:'wait'};window[k]=s;Promise.resolve(window.__srGeneratedBlob?window.__srGeneratedBlob("+u+"):null).then(b=>b||fetch("+u+").then(r=>{if(!r.ok)throw Error('File unavailable');return r.blob();}).catch(()=>new Promise((resolve,reject)=>{const x=new XMLHttpRequest();x.open('GET',"+u+");x.responseType='blob';x.onload=()=>x.status>=200&&x.status<300?resolve(x.response):reject(Error('Generated file unavailable'));x.onerror=()=>reject(Error('Generated file unavailable'));x.send();}))).then(b=>{if(b.size>"+MAX+")throw Error('Generated file exceeds 64 MB');s.blob=b;s.size=b.size;s.type=b.type;s.state='ready';}).catch(e=>{s.state='error';s.error=String(e);});return true;})()";
        try{web.evaluateJavascript(js,v->poll());toast("Preparing generated file… keep this page open");}catch(Exception e){fail("Cannot read generated file");}
    }
    void poll(){
        if(!live()||SystemClock.elapsedRealtime()>deadline){fail("Generated file expired or page closed. Try again.");return;}
        String k=JSONObject.quote(key);
        try{web.evaluateJavascript("(function(){const s=window["+k+"];return JSON.stringify(s?{state:s.state,size:s.size,type:s.type,data:s.data,error:s.error}:{state:'error',error:'File expired'});})()",v->{
            if(ended)return;
            try{Object raw=new JSONTokener(v).nextValue();if(!(raw instanceof String))throw new IOException("No file result");JSONObject j=new JSONObject((String)raw);String state=j.optString("state");
                if(state.equals("error")){fail(j.optString("error","Generated file unavailable"));return;}
                if(state.equals("ready")){size=j.getLong("size");if(size<0||size>MAX)throw new IOException("Generated file exceeds 64 MB");mime=j.optString("type","");if(size==0){finish();return;}next();return;}
                if(state.equals("chunk")){byte[] bytes=Base64.decode(j.getString("data"),Base64.DEFAULT);if(bytes.length!=Math.min((long)CHUNK,size-offset))throw new IOException("Invalid generated file chunk");out.write(bytes);offset+=bytes.length;if(offset==size)finish();else next();return;}
                main.postDelayed(this::poll,100);
            }catch(Exception e){fail("Cannot save generated file: "+e.getMessage());}
        });}catch(Exception e){fail("Generated file page closed");}
    }
    void next(){
        if(!live()){fail("Generated file page closed");return;}deadline=SystemClock.elapsedRealtime()+30000;String k=JSONObject.quote(key);
        try{web.evaluateJavascript("(function(){const s=window["+k+"];if(!s||!s.blob)return false;s.state='wait';s.data=null;const r=new FileReader();r.onload=()=>{s.data=String(r.result).split(',')[1];s.state='chunk';};r.onerror=()=>{s.state='error';s.error='File read failed';};r.readAsDataURL(s.blob.slice("+offset+","+Math.min(size,offset+CHUNK)+"));return true;})()",v->{if("true".equals(v))poll();else fail("Generated file expired");});}catch(Exception e){fail("Cannot read generated file chunk");}
    }
    static byte[] decodeData(String text) throws IOException {ByteArrayOutputStream b=new ByteArrayOutputStream();for(int i=0;i<text.length();){char ch=text.charAt(i);if(ch=='%'){if(i+2>=text.length())throw new IOException("Invalid percent encoding");int hi=Character.digit(text.charAt(i+1),16),lo=Character.digit(text.charAt(i+2),16);if(hi<0||lo<0)throw new IOException("Invalid percent encoding");b.write(hi*16+lo);i+=3;}else{int cp=text.codePointAt(i);byte[] bytes=new String(Character.toChars(cp)).getBytes(java.nio.charset.StandardCharsets.UTF_8);b.write(bytes);i+=Character.charCount(cp);}}return b.toByteArray();}
    void cleanup(){main.removeCallbacks(watchdog);try{if(page!=null&&page.equals(web.getUrl()))web.evaluateJavascript("delete window["+JSONObject.quote(key)+"]",null);}catch(Exception ignored){}try{if(out!=null)out.close();}catch(IOException ignored){}out=null;}
    void fail(String message){if(ended)return;ended=true;cleanup();if(temp!=null)temp.delete();toast(message);if(!message.contains("page closed")){String type=cleanMime(hint);String name=generatedName(disposition==null?null:URLUtil.guessFileName("https://file.invalid/download",disposition,type),type);DownloadService.recordInlineFailure(context,name,type,message);}}
    static String cleanMime(String type){String t=type==null?"":type.split(";",2)[0].trim();return t.matches("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+")?t:"application/octet-stream";}
    static String generatedName(String requested,String type){String ext=MimeTypeMap.getSingleton().getExtensionFromMimeType(type);if(requested==null||requested.trim().isEmpty())requested="download"+(ext==null?".bin":"."+ext);return DownloadService.safeName(requested);}
    void finish(){if(ended)return;ended=true;cleanup();String finalType=cleanMime(mime==null||mime.isEmpty()?hint:mime);String name=generatedName(disposition!=null&&!disposition.isEmpty()?URLUtil.guessFileName("https://file.invalid/download",disposition,finalType):null,finalType);publish(context,temp,name,finalType,size);}
    static void publish(Context context,File temp,String name,String finalType,long size){
        new Thread(()->{try{DownloadService.enqueueGenerated(context,temp,name,finalType,size);notifyResult(context,"Queued: "+name);}catch(Exception e){DownloadService.recordInlineFailure(context,name,finalType,"Cannot queue generated file: "+e.getMessage());notifyResult(context,"Cannot queue generated file: "+e.getMessage());}finally{if(temp.exists())temp.delete();}},"sr-inline-save").start();
    }
    static void notifyResult(Context context,String text){new Handler(Looper.getMainLooper()).post(()->Toast.makeText(context,text,Toast.LENGTH_LONG).show());}
}
