package com.srcreation.browser;

/** Stable preference keys; scenic themes use local, original wallpaper artwork. */
enum BrowserTheme {
    CLASSIC_LIGHT("Classic Light", "Clean white · teal accents", null, false, 0xff101c30,0xff24364c,0xfff1f5f9,0xffffffff,0xff132238,0xff506477,0xff08776d,0xff57e4d4,0xffdce6ef,0xffd9f5ed),
    CLASSIC_DARK("Classic Dark", "Midnight blue · mint accents", null, true, 0xff101c30,0xff24364c,0xff152439,0xff24364c,0xffe7eff8,0xffafc2d7,0xff57e4d4,0xff57e4d4,0xff38506a,0xff164744),
    ALPINE("Alpine Dawn", "Snowy mountains · alpine lake", "alpine", true, 0xff17283f,0xff2a4059,0xff23364b,0xff263b52,0xfff2f7ff,0xffc1d6e9,0xff9ee7ff,0xff9ee7ff,0xff456078,0xff314e64),
    FOREST("Emerald Forest", "Misty evergreen woodland", "forest", true, 0xff102d28,0xff21483c,0xff193a32,0xff254c3f,0xffeffff7,0xffb9d8ca,0xffa6efba,0xffa6efba,0xff416858,0xff315b47),
    OCEAN("Ocean Escape", "Turquoise sea · tropical coast", "ocean", true, 0xff10334c,0xff204c63,0xff193e53,0xff244d62,0xffeffaff,0xffb6dbe9,0xff80eee7,0xff80eee7,0xff416c80,0xff2c606e),
    SUNSET("Golden Sunset", "Warm horizon · desert dunes", "sunset", true, 0xff382436,0xff573a48,0xff462d3d,0xff593b49,0xfffff3ea,0xffe4c7c9,0xffffc58b,0xffffc58b,0xff785762,0xff704a4d),
    AURORA("Aurora Night", "Northern lights · starry sky", "aurora", true, 0xff151b3e,0xff2a3159,0xff20254b,0xff30375e,0xfff1efff,0xffc7c9ea,0xffa5f4d8,0xffa5f4d8,0xff4e5880,0xff3b4c6d),
    BLOSSOM("Sakura Dream", "Pink blossoms · tranquil hills", "blossom", false, 0xff442c49,0xff62435e,0xfffff0f5,0xfffff9fc,0xff432c45,0xff795970,0xff914467,0xffffc7de,0xffe9cbdc,0xfff6dce9),
    PEARL("Pearl Platinum", "Porcelain white · silver blue", null, false, 0xff24394e,0xff38516a,0xfff4f7fb,0xffffffff,0xff182b40,0xff485c70,0xff205987,0xffbfe4ff,0xffd2dfeb,0xffe1effa),
    CHAMPAGNE("Champagne Gold", "Ivory · warm metallic accents", null, false, 0xff493723,0xff5d4832,0xfffffaf0,0xfffffdf8,0xff382a1a,0xff6b5842,0xff805619,0xffffdba1,0xffe6d7be,0xfff6e9cd),
    MINT("Mint Frost", "Cool white · botanical green", null, false, 0xff17483e,0xff23594d,0xffeffbf7,0xffffffff,0xff173c34,0xff426258,0xff146b55,0xffa9f3d6,0xffcde6db,0xffd9f3e8),
    LAVENDER("Lavender Silk", "Soft violet · pearl surfaces", null, false, 0xff40345e,0xff564775,0xfff8f5ff,0xffffffff,0xff30274b,0xff605577,0xff6245a0,0xffe1d2ff,0xffe1d9f2,0xffeee6ff),
    SKY("Sky Crystal", "Ice blue · bright clean cards", null, false, 0xff17486b,0xff245b7d,0xffeff8ff,0xffffffff,0xff17364b,0xff426278,0xff165e8c,0xffb9eaff,0xffd0e6f5,0xffdcf0fc),
    ROSE("Rose Quartz", "Blush white · rose accents", null, false, 0xff653a4b,0xff74465a,0xfffff5f7,0xfffffdfd,0xff462b37,0xff745364,0xff963b64,0xffffcde3,0xffecd3dd,0xfff8e3ec),
    WATERFALL("Crystal Falls", "Cascading waterfall · lush valley", "waterfall", false, 0xff153f40,0xff285958,0xffeffaf8,0xffffffff,0xff163c3b,0xff416361,0xff126b65,0xffb5f5e9,0xffcde8e4,0xffd9f4ec),
    MEADOW("Wildflower Meadow", "Sunlit flowers · rolling hills", "meadow", false, 0xff3b492b,0xff4f603a,0xfff8faed,0xffffffff,0xff28391d,0xff52623c,0xff506b25,0xffe5f4b6,0xffdce6c6,0xffeaf3d2),
    RIVER("River Serenity", "Winding river · misty mountains", "river", false, 0xff1c4058,0xff31586d,0xfff0f8fb,0xffffffff,0xff17384a,0xff466576,0xff1c6282,0xffc3edff,0xffd4e7f0,0xffe0f2fa),
    MOONLAKE("Moonlit Lake", "Moonlight · quiet woodland", "moonlake", true, 0xff171e3c,0xff293552,0xff1e2945,0xff2c3b58,0xffeef3ff,0xffc0cde9,0xffbcd9ff,0xffbcd9ff,0xff4d6080,0xff3d5478);
    final String title,description,scene; final boolean dark;
    final int nav,toolbar,paper,card,fg,muted,accent,highlight,line,active;
    BrowserTheme(String title,String description,String scene,boolean dark,int nav,int toolbar,int paper,int card,int fg,int muted,int accent,int highlight,int line,int active){this.title=title;this.description=description;this.scene=scene;this.dark=dark;this.nav=nav;this.toolbar=toolbar;this.paper=paper;this.card=card;this.fg=fg;this.muted=muted;this.accent=accent;this.highlight=highlight;this.line=line;this.active=active;}
    static BrowserTheme restore(String key,boolean oldDark){if(key!=null)try{return valueOf(key);}catch(IllegalArgumentException ignored){}return oldDark?CLASSIC_DARK:CLASSIC_LIGHT;}
    boolean wallpaper(boolean enabled){return enabled&&scene!=null;}
}
