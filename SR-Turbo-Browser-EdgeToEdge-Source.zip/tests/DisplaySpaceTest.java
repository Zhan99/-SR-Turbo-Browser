package com.srcreation.browser;
public final class DisplaySpaceTest {
    static void eq(int expected,int actual){if(expected!=actual)throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        eq(0,DisplaySpace.top(true,24,0));
        eq(0,DisplaySpace.top(true,48,0));
        eq(24,DisplaySpace.top(false,24,0));
        eq(32,DisplaySpace.top(true,24,32));
        eq(32,DisplaySpace.top(false,24,32));
        eq(24,DisplaySpace.bottom(24,0,0));
        eq(300,DisplaySpace.bottom(24,300,0));
        eq(32,DisplaySpace.bottom(24,0,32));
        eq(0x22123456,DisplaySpace.glass(0xff123456));
        eq(45,DisplaySpace.DOCK_HEIGHT);
        int[] centre=DisplaySpace.toolbar(true,360,0,170,190,4,104,128);
        eq(0,centre[0]);eq(162,centre[3]);
        int[] left=DisplaySpace.toolbar(true,360,0,0,25,4,104,128);eq(29,left[1]);
        int[] right=DisplaySpace.toolbar(true,360,0,335,360,4,104,128);eq(29,right[2]);
        eq(DisplaySpace.FALLBACK,DisplaySpace.toolbar(true,360,0,90,260,4,104,128)[0]);
        eq(0,DisplaySpace.toolbar(false,360,0,170,190,4,104,128)[3]);
        System.out.println("Display space: 16 checks passed");
    }
}
