package com.srcreation.browser;
final class DisplaySpace {
    static final int BAR_HEIGHT=42,BAR_MARGIN=3,DOCK_HEIGHT=BAR_HEIGHT+BAR_MARGIN;
    static int top(boolean hidden,int status,int cutout){return Math.max(Math.max(0,cutout),hidden?0:Math.max(0,status));}
    static int bottom(int nav,int keyboard,int cutout){return Math.max(0,Math.max(cutout,Math.max(nav,keyboard)));}
    static final int FALLBACK=1;
    // Result: fallback flag, horizontal padding, explicit address width (0 = weighted).
    static int[] toolbar(boolean hidden,int width,int origin,int holeLeft,int holeRight,int pad,int minAddress,int actions){
        int[] normal={0,pad,pad,0};
        if(!hidden||holeRight<=holeLeft)return normal;
        int l=holeLeft-origin,r=holeRight-origin;
        if(r<=0||l>=width)return normal;
        if(r+pad+minAddress+actions+pad<=width&&l<minAddress+pad)return new int[]{0,Math.max(pad,r+pad),pad,0};
        if(l-pad>=minAddress+actions+pad)return new int[]{0,pad,Math.max(pad,width-l+pad),0};
        if(l-2*pad>=minAddress&&width-r-2*pad>=actions)return new int[]{0,pad,pad,l-2*pad};
        return new int[]{FALLBACK,pad,pad,0};
    }
    static int glass(int color){return (color&0x00ffffff)|0x22000000;}
}
